import work_jcst.write_xml
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
import xml
import work_jcst.readReport
from gensim import corpora,models

url01_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_bug.xml'
url01_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
url01_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_feature.xml'

url02_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\textualIndexReport_bug.xml'
url02_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\textualIndexReport_none.xml'
url02_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\textualIndexReport_feature.xml'

url03_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\textualIndexReport_bug.xml'
url03_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\textualIndexReport_none.xml'
url03_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\textualIndexReport_feature.xml'

url04_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\textualIndexReport_bug.xml'
url04_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\textualIndexReport_none.xml'
url04_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\textualIndexReport_feature.xml'

url05_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\textualIndexReport_bug.xml'
url05_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\textualIndexReport_none.xml'
url05_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\textualIndexReport_feature.xml'

url06_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\textualIndexReport_bug.xml'
url06_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\textualIndexReport_none.xml'
url06_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\textualIndexReport_feature.xml'

url07_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\textualIndexReport_bug.xml'
url07_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\textualIndexReport_none.xml'
url07_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\textualIndexReport_feature.xml'

url08_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\textualIndexReport_bug.xml'
url08_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\textualIndexReport_none.xml'


url09_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\textualIndexReport_bug.xml'
url09_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\textualIndexReport_none.xml'


url10_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\textualIndexReport_bug.xml'
url10_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\textualIndexReport_none.xml'


url11_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\textualIndexReport_bug.xml'
url11_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\textualIndexReport_none.xml'


url12_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\textualIndexReport_bug.xml'
url12_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\textualIndexReport_none.xml'


url13_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\textualIndexReport_bug.xml'
url13_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\textualIndexReport_none.xml'


url14_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\textualIndexReport_bug.xml'
url14_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\textualIndexReport_none.xml'


url15_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_bug.xml'
url15_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_none.xml'


url16_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_bug.xml'
url16_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_none.xml'


url17_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\textualIndexReport_bug.xml'
url17_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\textualIndexReport_none.xml'


#textualIndexReport_feature=work_jcst.readReport.readReport_none(url01_textualIndexReport_feature)
#textualIndexReport_bug=work_jcst.readReport.readReport_none(url08_textualIndexReport_bug)
textualIndexReport_none=work_jcst.readReport.readReport_none(url14_textualIndexReport_none)
textualIndexReport_feature=work_jcst.readReport.readReport_none(url14_textualIndexReport_bug)

dictionary = corpora.Dictionary(textualIndexReport_feature)
cnm=dict(dictionary)
dictionary1=sorted(cnm.items(),key=lambda item:item[0])
url01="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\report_bug_dict.xml"
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\report_bug_dict.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\report_bug_dict.xml"
url042="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\report_bug_dict.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\report_bug_dict.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\report_bug_dict.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\report_bug_dict.xml"
url08="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\report_bug_dict.xml"
url09="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\report_bug_dict.xml"
url10="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\report_bug_dict.xml"
url11="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\report_bug_dict.xml"
url12="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\report_bug_dict.xml"
url13="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\report_bug_dict.xml"
url14="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\report_bug_dict.xml"
url15="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\report_bug_dict.xml"
url16="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\report_bug_dict.xml"
url17="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\report_bug_dict.xml"

url01="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\report_feature_dict.xml"
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\report_feature_dict.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\report_feature_dict.xml"
url04="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\report_feature_dict.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\report_feature_dict.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\report_feature_dict.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\report_feature_dict.xml"

print(dictionary1)
work_jcst.write_xml.write_xml(dictionary1,url14)


query_bows = [dictionary.doc2bow(text) for text in textualIndexReport_none]
print('len(query_bows):{0}'.format(len(query_bows)))
corpus = [dictionary.doc2bow(text) for text in textualIndexReport_feature]
tfidf = models.TfidfModel(corpus)

texts1=''
for sentence in textualIndexReport_feature:
    for word in sentence:
        texts1+=word+' '
#print(texts1)
all_reviews=texts1.split()
print('all_reviews')
print(all_reviews)
print('len(all_reviews)')
print(len(all_reviews))
all_reviews_vec=dictionary.doc2bow(all_reviews)
print('all_reviews_vec')
print(all_reviews_vec)
all_reviews_tfidf=tfidf[all_reviews_vec]

url01="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\allbugreportfidf.xml"
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\allbugreportfidf.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\allbugreportfidf.xml"
url042="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\allbugreportfidf.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\allbugreportfidf.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\allbugreportfidf.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\allbugreportfidf.xml"
url08="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\allbugreportfidf.xml"
url09="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\allbugreportfidf.xml"
url10="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\allbugreportfidf.xml"
url11="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\allbugreportfidf.xml"
url12="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\allbugreportfidf.xml"
url13="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\allbugreportfidf.xml"
url14="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\allbugreportfidf.xml"
url15="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\allbugreportfidf.xml"
url16="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\allbugreportfidf.xml"
url17="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\allbugreportfidf.xml"

url01="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\allfeaturereportfidf.xml"
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\allfeaturereportfidf.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\allfeaturereportfidf.xml"
url04="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\allfeaturereportfidf.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\allfeaturereportfidf.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\allfeaturereportfidf.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\allfeaturereportfidf.xml"

work_jcst.write_xml.write_xml(all_reviews_tfidf,url14)
print('all_reviews_tfidf{0}'.format(len(all_reviews_tfidf)))

# 在内存中创建一个空的文档
doc = xml.dom.minidom.Document()
# 创建一个根节点Managers对象
root = doc.createElement('Managers')
# 设置根节点的属性
root.setAttribute('company', 'microsoft')
root.setAttribute('address', 'heu')
# 将根节点添加到文档对象中
doc.appendChild(root)
count001=0
for i in range(len(query_bows)):
    query_tfidf = tfidf[query_bows[i]]

    nodeManager = doc.createElement('Manager')
    nodeManager.setAttribute('Number', str(i))
    for j in query_tfidf:
        nodeKey = doc.createElement('Key')
        # 给叶子节点name设置一个文本节点，用于显示文本内容
        nodeKey.appendChild(doc.createTextNode(str(j[0])))
        nodeValue = doc.createElement("Value")
        nodeValue.appendChild(doc.createTextNode(str(j[1])))
        # 将各叶子节点添加到父节点Manager中，
        # 最后将Manager添加到根节点Managers中
        nodeManager.appendChild(nodeKey)
        nodeManager.appendChild(nodeValue)
        root.appendChild(nodeManager)
    if query_tfidf==[]:
        root.appendChild(nodeManager)

url01_nbrt='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\nonebugreporttfidf.xml'
url02_nbrt="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\nonebugreporttfidf.xml"
url03_nbrt="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\nonebugreporttfidf.xml"
url04_nbrt2="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\nonebugreporttfidf.xml"
url05_nbrt="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\nonebugreporttfidf.xml"
url06_nbrt="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\nonebugreporttfidf.xml"
url07_nbrt="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\nonebugreporttfidf.xml"
url08_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\nonebugreporttfidf.xml"
url09_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\nonebugreporttfidf.xml"
url10_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\nonebugreporttfidf.xml"
url11_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\nonebugreporttfidf.xml"
url12_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\nonebugreporttfidf.xml"
url13_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\nonebugreporttfidf.xml"
url14_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\nonebugreporttfidf.xml"
url15_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\nonebugreporttfidf.xml"
url16_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\nonebugreporttfidf.xml"
url17_nbrt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\nonebugreporttfidf.xml"

url01_nbrt='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\nonefeaturereporttfidf.xml'
url02_nbrt="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\nonefeaturereporttfidf.xml"
url03_nbrt="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\nonefeaturereporttfidf.xml"
url04_nbrt="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\nonefeaturereporttfidf.xml"
url05_nbrt="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\nonefeaturereporttfidf.xml"
url06_nbrt="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\nonefeaturereporttfidf.xml"
url07_nbrt="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\nonefeaturereporttfidf.xml"

fp = open(url14_nbrt, 'w')
doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")


