
import math

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import work_jcst.readReport
import work_jcst.write_xml

url01_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
url02_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\textualIndexReport_none.xml'

textualIndexReport_none=work_jcst.readReport.readReport_none(url02_textualIndexReport_none)
print(textualIndexReport_none)
#url01_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_feature.xml'
#url02_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\textualIndexReport_feature.xml'
#textualIndexReport_feature=work_jcst.readReport.readReport_none(url02_textualIndexReport_feature)
#print(textualIndexReport_feature)
url01_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_bug.xml'
url02_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\textualIndexReport_bug.xml'
textualIndexReport_bug=work_jcst.readReport.readReport_none(url02_textualIndexReport_bug)
print(textualIndexReport_bug)
#url01_textualIndexReport_irrfeature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_irrfeature.xml'

#textualIndexReport_irrfeature=work_jcst.readReport.readReport_none(url01_textualIndexReport_irrfeature)
url01_bug_reports_none_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_none_processed.xml'
url02_bug_reports_none_processed='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\bug_reports_none_processed.xml'

url01_bug_reports_bug_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_bug_processed.xml'
url02_bug_reports_bug_processed='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\bug_reports_bug_processed.xml'

#url01_bug_reports_feature_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_feature_processed.xml'
#url02_bug_reports_feature_processed='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\bug_reports_feature_processed.xml'

#url01_bug_reports_irrfeature_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_irrfeature_processed.xml'


bug_reports_none_processed=work_jcst.readReport.read_rfp(url02_bug_reports_none_processed)
bug_reports_bug_processed=work_jcst.readReport.read_rfp(url02_bug_reports_bug_processed)
#bug_reports_feature_processed=work_jcst.readReport.read_rfp(url02_bug_reports_feature_processed)
#bug_reports_irrfeature_processed=work_jcst.readReport.read_rfp(url01_bug_reports_irrfeature_processed)
print(bug_reports_none_processed)
print(len(bug_reports_none_processed))
print(bug_reports_bug_processed)
print(len(bug_reports_bug_processed))
#print(bug_reports_feature_processed)
#print(len(bug_reports_feature_processed))
#计算一个词t的idf
def idf(t,corpus):
    N=len(corpus)
    Nd=0
    for list in corpus:
        for token in list:
            if t==token:
                Nd+=1
                break
    if Nd!=0:
        idf=math.log(N/Nd,10)
    else:
        idf=math.log(N,10)
    return idf
#TFD
def tf_d(t,document,corpus1,w1,w2,b1,b2):
    average_length1 = 0
    average_length2 = 0
    for document1 in corpus1:
        average_length1+=len(document1[0])
        average_length2+=len(document1[1])
    average_length1/=len(corpus1)
    average_length2/=len(corpus1)

    occurrences1 = 0
    occurrences2 = 0

    for token in document[0]:
        if t==token:
            print('1{0}'.format(token))
            occurrences1+=1
    for token1 in document[1]:
        if t==token1:
            print('2{0}'.format(token1))
            occurrences2+=1
    '''
    print('occurrence1:{0}'.format(occurrences1))
    print('occurrence2:{0}'.format(occurrences2))
    print('average_length1:{0}'.format(average_length1))
    print('average_length2:{0}'.format(average_length2))
    print('lensummary:{0}'.format(len(document[0])))
    print('lendescription:{0}'.format(len(document[1])))
    '''
    tf=w1*occurrences1/(1-b1+(b1*len(document[0])/average_length1))\
       +w2*occurrences2/(1-b2+(b2*len(document[1])/average_length2))
    print('occurrence2:{0}'.format(occurrences2))
    return tf
'''   
def tf_d(t,corpus1,w1,w2,b1,b2):
    average_length1 = 0
    average_length2 = 0
    for document in corpus1:
        average_length1+=len(document[1])
        average_length2+=len(document[2])
    average_length1/=len(corpus1)
    average_length2/=len(corpus1)
    list=[]
    for document in corpus1:
        occurrences1 = 0
        occurrences2 = 0
        for token in document[1]:
            if t==token:
                occurrences1+=1
        for token in document[2]:
            if t==token:
                occurrences2+=1

        tf=w1*occurrences1/(1-b1+(b1*len(document[1])/average_length1))
        +w2*occurrences2/(1-b2+(b2*len(document[2])/average_length2))
        list.append(tf)
    return list
'''
#TFQ
def tf_q(t,query,w1,w2):
    occurrences1 = 0
    occurrences2 = 0
    for token in query[0]:
        if t == token:
            occurrences1 += 1
    for token in query[1]:
        if t == token:
            occurrences2 += 1
    print('occurrence1:{0}'.format(occurrences1))
    print('occurrence2:{0}'.format(occurrences2))
    tf=w1*occurrences1+w2*occurrences2
    return tf
'''
def BM25Fext(document,query,corpus):
    bm25fext=0
    for t in query:
        for token in document:
            if t==token:
                bm25fext+=idf(t,corpus)*tf_d(t,corpus1,)
'''
def s2_bm25fext(textualIndexReport_none,textualIndexReport_bug,bug_reports_bug_processed,bug_reports_none_processed):
    s2_bug_list = []
    num01 = 0
    for query in textualIndexReport_none:
        num02 = 0
        s2_bm25fext = 0
        for document in textualIndexReport_bug:
            list1 = []
            for tokenq in query:
                for tokend in document:
                    if tokenq == tokend:
                        list1.append(tokenq)
            list1 = list(set(list1))
            bm25fext = 0
            for token in list1:
                be1 = idf(token, textualIndexReport_bug)
                be2_tfd = tf_d(token, bug_reports_bug_processed[num02], bug_reports_bug_processed, 3.221, 0.444, 0.393, 1)
                be2 = be2_tfd / (2 + be2_tfd)
                be3_tfq = tf_q(token, bug_reports_none_processed[num01], 3.01, 0.196)
                k3 = 0.224
                be3 = (k3 + 1) * be3_tfq / (k3 + be3_tfq)
                bm25fext += be1 * be2 * be3
            s2_bm25fext += bm25fext
            num02 += 1
        s2 = s2_bm25fext / num02
        s2_bug_list.append(s2)
        num01 += 1
    return s2_bug_list


def bm25fext(textualIndexReport_none,textualIndexReport_bug,bug_reports_bug_processed,bug_reports_none_processed):
    num01 = 0

    bm25fextlist = []
    for query in textualIndexReport_none:
        num02 = 0
        s2_bm25fext = 0

        for document in textualIndexReport_bug:
            list1 = []
            for tokenq in query:
                for tokend in document:
                    if tokenq == tokend:
                        list1.append(tokenq)
            list1 = list(set(list1))
            bm25fext = 0
            for token in list1:
                be1 = idf(token, textualIndexReport_bug)
                be2_tfd = tf_d(token, bug_reports_bug_processed[num02], bug_reports_bug_processed, 3, 1, 0.5, 1)
                be2 = be2_tfd / (2 + be2_tfd)
                be3_tfq = tf_q(token, bug_reports_none_processed[num01], 3, 1)
                k3 = 0.382
                be3 = (k3 + 1) * be3_tfq / (k3 + be3_tfq)
                bm25fext += be1 * be2 * be3

            bm25fextlist.append([num01,num02,bm25fext])
            num02 += 1
        num01 += 1

    return bm25fextlist
'''
def bm25ext01(d,q,textualIndexReport_bug, bug_reports_bug_processed,bug_reports_none_processed):
    list1=[]
    for tokenq in q:
        for tokend in d:
            if tokenq == tokend:
                list1.append(tokenq)
    list1 = list(set(list1))
    bm25fext = 0
    for token in list1:
        be1 = idf(token, textualIndexReport_bug)
        be2_tfd = tf_d(token, bug_reports_bug_processed[num02], bug_reports_bug_processed, 3, 1, 0.5, 1)
        be2 = be2_tfd / (2 + be2_tfd)
        be3_tfq = tf_q(token, bug_reports_none_processed[num01], 3, 1)
        k3 = 0.382
        be3 = (k3 + 1) * be3_tfq / (k3 + be3_tfq)
        bm25fext += be1 * be2 * be3

    num02 += 1

'''
'''
if __name__ == '__main__':

    s2_list=[]
    num01=0
    for query in textualIndexReport_none:
        num02=0
        s2_bm25fext=0
        print('query{0}: {1}'.format(num01,query))
        for document in textualIndexReport_feature:
            print('document{0}: {1}'.format(num02, document))
            list1=[]
            for tokenq in query:
                for tokend in document:
                    if tokenq==tokend:
                        list1.append(tokenq)

            list1=list(set(list1))
            bm25fext=0
            print('list1{0}: {1}'.format(num02, list1))
            for token in list1:
                be1=idf(token,textualIndexReport_feature)
                be2_tfd=tf_d(token,bug_reports_feature_processed[num02],bug_reports_feature_processed,3,1,0.5,1)
                print('be2_tfd{0}'.format(be2_tfd))
                be2=be2_tfd/(2+be2_tfd)
                be3_tfq=tf_q(token,bug_reports_none_processed[num01],3,1)
                k3=0.382
                print('be3_tfq{0}: {1}'.format(num02, be3_tfq))
                be3=(k3+1)*be3_tfq/(k3+be3_tfq)

                print('be{0}: {1}'.format(num02,[be1,be2,be3]))
                bm25fext+=be1*be2*be3
                print('bm25fext{0}: {1}'.format(num02, bm25fext))
            s2_bm25fext+=bm25fext

            print('s2_bm25fext{0}: {1}'.format(num02, s2_bm25fext))
            #print(s2_bm25fext)
            num02+=1
        s2=s2_bm25fext/num02
        print('s2:{0}'.format(s2))
        s2_list.append(s2)
        print('s2_list:{0}'.format(s2_list))
        num01+=1
    print(s2_list)
    print(len(s2_list))

    s2_bug_list=[]
    num01=0
    for query in textualIndexReport_none:
        num02=0
        s2_bm25fext=0
        #print('query{0}: {1}'.format(num01,query))
        for document in textualIndexReport_bug:
            #print('document{0}: {1}'.format(num02, document))
            list1=[]
            for tokenq in query:
                for tokend in document:
                    if tokenq==tokend:
                        list1.append(tokenq)

            list1=list(set(list1))
            bm25fext=0
            #print('list1{0}: {1}'.format(num02, list1))
            for token in list1:
                be1=idf(token,textualIndexReport_bug)
                be2_tfd=tf_d(token,bug_reports_bug_processed[num02],bug_reports_bug_processed,3,1,0.5,1)
                #print('be2_tfd{0}'.format(be2_tfd))
                be2=be2_tfd/(2+be2_tfd)
                be3_tfq=tf_q(token,bug_reports_none_processed[num01],3,1)
                k3=0.382
                #print('be3_tfq{0}: {1}'.format(num02, be3_tfq))
                be3=(k3+1)*be3_tfq/(k3+be3_tfq)

                #print('be{0}: {1}'.format(num02,[be1,be2,be3]))
                bm25fext+=be1*be2*be3
                #print('bm25fext{0}: {1}'.format(num02, bm25fext))
            s2_bm25fext+=bm25fext

            #print('s2_bm25fext{0}: {1}'.format(num02, s2_bm25fext))
            #print(s2_bm25fext)
            num02+=1
        s2=s2_bm25fext/num02
        #print('s2:{0}'.format(s2))
        s2_bug_list.append(s2)
        #print('s2_list:{0}'.format(s2_list))
        num01+=1

'''
if __name__ == '__main__':
    #list_feature=s2_bm25fext(textualIndexReport_none,textualIndexReport_feature,bug_reports_feature_processed,bug_reports_none_processed)
    list_bug = s2_bm25fext(textualIndexReport_none,textualIndexReport_bug,bug_reports_bug_processed,bug_reports_none_processed)
    #list_irrfeature=s2_bm25fext(textualIndexReport_none,textualIndexReport_irrfeature,bug_reports_irrfeature_processed,bug_reports_none_processed)

    #url01_write_s2_bm25fext_feature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_feature.xml'
    #url01_write_s2_bm25fext_bug='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_bug.xml'

    url01_write_s2_bm25fext_feature='E:\python_script\work_jcst\\bugReport\\tests\\s2_bm25fext_feature2.xml'
    url01_write_s2_bm25fext_bug='E:\python_script\work_jcst\\bugReport\\tests\\s2_bm25fext_bug2.xml'

    #url01_write_s2_bm25fext_irrfeature = 'E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_irrfeature.xml'
   # work_jcst.write_xml.write_xml2(list_feature,url01_write_s2_bm25fext_feature)
    work_jcst.write_xml.write_xml2(list_bug,url01_write_s2_bm25fext_bug)
   # work_jcst.write_xml.write_xml2(list_irrfeature, url01_write_s2_bm25fext_irrfeature)

    #list_bm25fext=bm25fext(textualIndexReport_none, textualIndexReport_irrfeature, bug_reports_irrfeature_processed, bug_reports_none_processed)
    #print(list_bm25fext)


