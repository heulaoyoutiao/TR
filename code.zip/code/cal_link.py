import work_jcst.readReport
from gensim import corpora,models,similarities
url9='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_bug_reviews.xml'

url10='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_feature_reviews.xml'

url_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\\\cgeo_cgeo\\textualIndexReport_bug.xml'

url_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\\cgeo_cgeo\\textualIndexReport_feature.xml'

reviews=work_jcst.readReport.readReport_none(url10)
reports = work_jcst.readReport.readReport_none(url_textualIndexReport_feature)


dictionary = corpora.Dictionary(reviews+reports)
corpus = [dictionary.doc2bow(text) for text in reviews]
tfidf = models.TfidfModel(corpus)
corpus_tfidf = tfidf[corpus]
index = similarities.MatrixSimilarity(corpus_tfidf)
query_bows = [dictionary.doc2bow(text) for text in reports]

f4=open('E:\python_script\work_jcst\\bugReport\\variate\\\cgeo_cgeo\\similar_feature.txt','w',encoding='utf-8')
for i in range(len(query_bows)):
    query_tfidf = tfidf[query_bows[i]]
    sims = index[query_tfidf]
    sort_sims = sorted(enumerate(sims), key=lambda item: -item[1])
    str4=''
    str4+="第{0}个bugReport的结果: ".format(i)

    for j in range(10):
        str4+=str(sort_sims[j])+' '
    str4+='\n'
    f4.write(str4)

f4.close()
