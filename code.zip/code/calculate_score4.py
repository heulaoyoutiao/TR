import work_jcst.readReport
import work_jcst.write_xml
import work_jcst.func_prf
from openpyxl import Workbook
#s1 SURF得到的bug类型的review与没标签的report
url01_bug_review='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s1_bug_review.xml'
#s2_bm25fext bug类型的report与没标签的
url01_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_bug.xml'

url02_bug_review='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s1_bug_review.xml'
url02_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s2_bm25fext_bug.xml'
url03_bug_review='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s1_bug_review.xml'
url03_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s2_bm25fext_bug.xml'
url04_bug_review='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s1_bug_review.xml'
url04_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s2_bm25fext_bug.xml'
url05_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s1_bug_review.xml'
url05_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s2_bm25fext_bug.xml'
url06_bug_review='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s1_bug_review.xml'
url06_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s2_bm25fext_bug.xml'
url07_bug_review='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s1_bug_review.xml'
url07_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s2_bm25fext_bug.xml'


#-------------------------------------------------------------
#s1 SURF得到的feature类型的review与没标签的report
url01_feature_review='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s1_feature_review.xml'
#s2_bm25fext feature类型的report与没标签的
url01_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_feature.xml'

url02_feature_review='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s1_feature_review.xml'
url02_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s2_bm25fext_feature.xml'
url03_feature_review='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s1_feature_review.xml'
url03_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s2_bm25fext_feature.xml'
url04_feature_review='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s1_feature_review.xml'
url04_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s2_bm25fext_feature.xml'
url05_feature_review='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s1_feature_review.xml'
url05_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s2_bm25fext_feature.xml'
url06_feature_review='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s1_feature_review.xml'
url06_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s2_bm25fext_feature.xml'
url07_feature_review='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s1_feature_review.xml'
url07_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s2_bm25fext_feature.xml'

def calculate1(url1,url2,p,url3):
    s1=work_jcst.readReport.readS(url1)
    s2=work_jcst.readReport.readS(url2)
    print('s1{0}'.format(s1))
    print('s2{0}'.format(s2))
    xmax1=s1[0]
    xmin1=s1[0]
    xmax2=s2[0]
    xmin2=s2[0]
    for s in s1:
        if s >= xmax1:
            xmax1 = s
        if s <= xmin1:
            xmin1 = s
    for s in s2:
        if s >= xmax2:
            xmax2 = s
        if s <= xmin2:
            xmin2 = s
    scores=[]
    for i in range(len(s1)):
        s1[i] = (s1[i] - xmin1) / (xmax1 - xmin1)
        s2[i]=(s2[i]-xmin2)/(xmax2-xmin2)
        scores.append(p*s1[i]+(1-p)*s2[i])
    print('s01{0}'.format(s1))
    print('s02{0}'.format(s2))
    print(xmax1,xmin1,xmax2,xmin2)
    work_jcst.write_xml.write_xml2(scores,url3)

    return scores

list_numbigerthanthreshold_bug=[[0 for i in range(9)] for j in range(9)]
list_numbigerthanthreshold_feature=[[0 for i in range(9)] for j in range(9)]
list_bt_bug=[[0 for i in range(9)] for j in range(9)]
list_bt_feature=[[0 for i in range(9)] for j in range(9)]

for i in range(1,10):
    urlScores1_bug01 = 'E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\scores4_bm25fext\\scores1_'
    urlScores1_bug02 = 'E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\scores4_bm25fext\\scores1_'
    urlScores1_bug03 = 'E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\scores4_bm25fext\\scores1_'
    urlScores1_bug04 = 'E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\scores4_bm25fext\\scores1_'
    urlScores1_bug05 = 'E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\scores1_'
    urlScores1_bug06 = 'E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\scores4_bm25fext\\scores1_'
    urlScores1_bug07 = 'E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\scores4_bm25fext\\scores1_'
    num01=i/10

    urlScores1_bug01+='{0}_bug.xml'.format(num01)
    urlScores1_bug02 += '{0}_bug.xml'.format(num01)
    urlScores1_bug03 += '{0}_bug.xml'.format(num01)
    urlScores1_bug04 += '{0}_bug.xml'.format(num01)
    urlScores1_bug05 += '{0}_bug.xml'.format(num01)
    urlScores1_bug06 += '{0}_bug.xml'.format(num01)
    urlScores1_bug07 += '{0}_bug.xml'.format(num01)
    scores1_bug=calculate1(url07_bug_review,url07_bug_none_sim,num01,urlScores1_bug07)
    print('{0}scores1_bug{1}'.format(num01,scores1_bug))


    urlScores1_feature01='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\scores4_bm25fext\\scores1_'
    urlScores1_feature02 = 'E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\scores4_bm25fext\\scores1_'
    urlScores1_feature03 = 'E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\scores4_bm25fext\\scores1_'
    urlScores1_feature04 = 'E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\scores4_bm25fext\\scores1_'
    urlScores1_feature05 = 'E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\scores1_'
    urlScores1_feature06 = 'E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\scores4_bm25fext\\scores1_'
    urlScores1_feature07 = 'E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\scores4_bm25fext\\scores1_'
    urlScores1_feature01+='{0}_feature.xml'.format(num01)
    urlScores1_feature02 += '{0}_feature.xml'.format(num01)
    urlScores1_feature03 += '{0}_feature.xml'.format(num01)
    urlScores1_feature04 += '{0}_feature.xml'.format(num01)
    urlScores1_feature05 += '{0}_feature.xml'.format(num01)
    urlScores1_feature06 += '{0}_feature.xml'.format(num01)
    urlScores1_feature07 += '{0}_feature.xml'.format(num01)
    scores1_feature=calculate1(url07_feature_review,url07_feature_none_sim,num01,urlScores1_feature07)
    print('{0}scores1_feature{1}'.format(num01,scores1_feature))
    for num02 in range(1,10):
        num03=num02/10
        sumbug=0
        m=0
        list01=[]
        for score in scores1_bug:
            if score > num03:
                sumbug+=1
                list01.append(m)
            m+=1
        list_numbigerthanthreshold_bug[i-1][num02-1]=sumbug
        list_bt_bug[i-1][num02-1]=list01

    for num02 in range(1,10):
        m=0
        num03=num02/10
        sumfeature=0
        list01=[]
        for score in scores1_feature:
            if score > num03:
                sumfeature+=1
                list01.append(m)
            m+=1
        list_numbigerthanthreshold_feature[i-1][num02-1]=sumfeature
        list_bt_feature[i-1][num02-1]=list01
print('list_numbigerthanthreshold_bug{0}'.format(list_numbigerthanthreshold_bug))
print(list_numbigerthanthreshold_feature)
print(list_bt_bug)
print(list_bt_feature)
url01='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AnimeNeko_Atarashii.xml'
url02='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AntennaPod_AntennaPod.xml'
url03='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\cgeo_cgeo.xml'
url04='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\moezbhatti_qksms.xml'
url05='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\talklittle_reddit-is-fun.xml'
url06='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\TwidereProject_Twidere-Android.xml'
url071='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'
url072='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android2.xml'
url073='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android3.xml'
#list01=work_jcst.readReport.read_kind_SURF(url06)
list01=work_jcst.readReport.read_3kind_SURF(url071,url072,url073)
l_b=list01[0]
l_f=list01[1]
print('l_b{0}'.format(l_b))
print('l_f{0}'.format(l_f))
list_tp=work_jcst.func_prf.c_intersection(list01,list_bt_bug,list_bt_feature)
list_tpb=list_tp[0]
list_tpf=list_tp[1]
print('list_tpb{0}'.format(list_tpb))
print('list_tpf{0}'.format(list_tpf))
#----------------------------------------------------------
list_precision=work_jcst.func_prf.c_precision(list_tp,list_numbigerthanthreshold_bug,list_numbigerthanthreshold_feature)
list_precision_b=list_precision[0]
list_precision_f=list_precision[1]
print(list_precision_b)
print(list_precision_f)

list_recall=work_jcst.func_prf.c_recall(list01,list_tp)
list_recall_b=list_recall[0]
list_recall_f=list_recall[1]
print('list_recall_b{0}'.format(list_recall_b))
print('list_recall_f{0}'.format(list_recall_f))

list_fmeasure=work_jcst.func_prf.c_fmeasure(list_precision,list_recall)
list_fmeasure_b=list_fmeasure[0]
list_fmeasure_f=list_fmeasure[1]
print(list_fmeasure_b)
print(len(list_fmeasure_b))
print(list_fmeasure_f)
print(len(list_fmeasure_f))

wb1=Workbook()
booksheet1=wb1.active
for i in range(9):
  booksheet1["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet1['%s%d'%(chr(ord('B')+i),j+1)].value=list_precision_b[i][j]

wb1.save("E:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\bm25precision_b7.xlsx")

wb1f=Workbook()
booksheet1f=wb1f.active
for i in range(9):
  booksheet1f["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet1f['%s%d'%(chr(ord('B')+i),j+1)].value=list_precision_f[i][j]

wb1f.save("E:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\bm25precision_f7.xlsx")
#------------------------------------------------------------------------
wb2=Workbook()
booksheet2=wb2.active
for i in range(9):
  booksheet2["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet2['%s%d'%(chr(ord('B')+i),j+1)].value=list_recall_b[i][j]

wb2.save("E:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\bm25recall_b7.xlsx")

wb2f=Workbook()
booksheet2f=wb2f.active
for i in range(9):
  booksheet2f["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet2f['%s%d'%(chr(ord('B')+i),j+1)].value=list_recall_f[i][j]

wb2f.save("E:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\bm25recall_f7.xlsx")

#-----------------------------------------------------------------------------------------
wb3=Workbook()
booksheet3=wb3.active
for i in range(9):
  booksheet3["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet3['%s%d'%(chr(ord('B')+i),j+1)].value=list_fmeasure_b[i][j]

wb3.save("E:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\bm25fmeasure_b7.xlsx")

wb3f=Workbook()
booksheet3f=wb3f.active
for i in range(9):
  booksheet3f["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet3f['%s%d'%(chr(ord('B')+i),j+1)].value=list_fmeasure_f[i][j]

wb3f.save("E:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\bm25fmeasure_f7.xlsx")