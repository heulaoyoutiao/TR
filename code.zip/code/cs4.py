import work_jcst.readReport
import work_jcst.write_xml
import work_jcst.func_prf
from openpyxl import Workbook
#s1 SURF得到的bug类型的review与没标签的report
url01_bug_review='F:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s1_bug_review.xml'
#s2_tfidf bug类型的report与没标签的
url01_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_bug.xml'
#url01_bug_none_sim='F:\python_script\work_jcst\\bugReport\\tests\\s2_bm25fext_bug.xml'
url02_bug_review='F:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s1_bug_review.xml'


url02_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s2_bm25fext_bug.xml'

url03_bug_review='F:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s1_bug_review.xml'
url03_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s2_bm25fext_bug.xml'
url04_bug_review='F:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s1_bug_review.xml'
url04_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s2_bm25fext_bug.xml'
url05_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s1_bug_review.xml'
url05_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s2_bm25fext_bug.xml'
url06_bug_review='F:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s1_bug_review.xml'
url06_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s2_bm25fext_bug.xml'
url07_bug_review='F:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s1_bug_review.xml'
url07_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s2_bm25fext_bug.xml'



url08_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\\s1_bug_review.xml'
url08_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\\s2_bm25fext_bug.xml'
url09_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\Automattic_simplenote-android\\s1_bug_review.xml'
url09_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\Automattic_simplenote-android\\s2_bm25fext_bug.xml'
#url09_bug_none_sim='F:\python_script\work_jcst\\bugReport\\tests\\s2_bm25fext_bug2.xml'

url10_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\chrislacy_TweetLanes\\s1_bug_review.xml'
url10_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\chrislacy_TweetLanes\\s2_bm25fext_bug.xml'
url11_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\k9mail_k-9\\s1_bug_review.xml'
url11_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\k9mail_k-9\\s2_bm25fext_bug.xml'
url12_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\OneBusAway_onebusaway-android\\s1_bug_review.xml'
url12_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\OneBusAway_onebusaway-android\\s2_bm25fext_bug.xml'
url13_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\owncloud_android\\s1_bug_review.xml'
url13_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\owncloud_android\\s2_bm25fext_bug.xml'
url14_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\sunlightlabs_congress-android\\s1_bug_review.xml'
url14_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\sunlightlabs_congress-android\\s2_bm25fext_bug.xml'
url15_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\\s1_bug_review.xml'
url15_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\\s2_bm25fext_bug.xml'
url16_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\\s1_bug_review.xml'
url16_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\\s2_bm25fext_bug.xml'
url17_bug_review='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\wordpress-mobile_WordPress-Android\\s1_bug_review.xml'
url17_bug_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\wordpress-mobile_WordPress-Android\\s2_bm25fext_bug.xml'


#-------------------------------------------------------------
#s1 SURF得到的feature类型的review与没标签的report
url01_feature_review='F:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s1_feature_review.xml'
#s2_tfidf feature类型的report与没标签的
url01_feature_none_sim='F:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_feature.xml'

url02_feature_review='F:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s1_feature_review.xml'
url02_feature_none_sim='F:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s2_bm25fext_feature.xml'
url03_feature_review='F:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s1_feature_review.xml'
url03_feature_none_sim='F:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s2_bm25fext_feature.xml'
url04_feature_review='F:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s1_feature_review.xml'
url04_feature_none_sim='F:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s2_bm25fext_feature.xml'
url05_feature_review='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s1_feature_review.xml'
url05_feature_none_sim='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s2_bm25fext_feature.xml'
url06_feature_review='F:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s1_feature_review.xml'
url06_feature_none_sim='F:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s2_bm25fext_feature.xml'
url07_feature_review='F:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s1_feature_review.xml'
url07_feature_none_sim='F:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s2_bm25fext_feature.xml'

'''
#读取数据
s1_bug_review=work_jcst.readReport.readS(url_bug_review)
print(s1_bug_review)
print(len(s1_bug_review))
xmax_s1_br=s1_bug_review[0]
xmin_s1_br=s1_bug_review[0]
for s1_01 in s1_bug_review:
    if s1_01>=xmax_s1_br:
        xmax_s1_br=s1_01
    if s1_01<=xmin_s1_br:
        xmin_s1_br=s1_01
print(xmax_s1_br)
print(xmin_s1_br)
#标准化
for i in range(len(s1_bug_review)):
    s1_bug_review[i]=(s1_bug_review[i]-xmin_s1_br)/(xmax_s1_br-xmin_s1_br)
print('** {0}'.format(s1_bug_review))

s2_bug_none_report=work_jcst.readReport.readS(url_bug_none_sim)
print(s2_bug_none_report)
print(len(s2_bug_none_report))
xmax_s2_bnr=s2_bug_none_report[0]
xmin_s2_bnr=s2_bug_none_report[0]
for s2_01 in s2_bug_none_report:
    if s2_01>=xmax_s2_bnr:
        xmax_s2_bnr=s2_01
    if s2_01<=xmin_s2_bnr:
        xmin_s2_bnr=s2_01
print(xmax_s2_bnr)
print(xmin_s2_bnr)

for i in range(len(s2_bug_none_report)):
    s2_bug_none_report[i]=(s2_bug_none_report[i]-xmin_s2_bnr)/(xmax_s2_bnr-xmin_s2_bnr)
print('** {0}'.format(s2_bug_none_report))

#参数0<=a<=1,a是s1的权重
a=0.2
scores1=[]
for num01 in range(len(s1_bug_review)):
    scores1.append(a*s1_bug_review[num01]+(1-a)*s2_bug_none_report[num01])
print('scores1{0}'.format(scores1))
'''
#计算score
#url1是review,url2是report,url3记录结果
def calculate1(url1,url2,p,url3):
    s1=work_jcst.readReport.readS(url1)
    s2=work_jcst.readReport.readS(url2)
    #print('s1{0}'.format(s1))
    #print('s2{0}'.format(s2))
    xmax1=s1[0]
    xmin1=s1[0]
    xmax2=s2[0]
    xmin2=s2[0]
    for s in s1:
        if s >= xmax1:
            xmax1 = s
        if s <= xmin1:
            xmin1 = s
    for s in s2:
        if s >= xmax2:
            xmax2 = s
        if s <= xmin2:
            xmin2 = s
    scores=[]
    for i in range(len(s1)):
        s1[i] = (s1[i] - xmin1) / (xmax1 - xmin1)
        s2[i]=(s2[i]-xmin2)/(xmax2-xmin2)
        scores.append(p*s1[i]+(1-p)*s2[i])
    #print('s01{0}'.format(s1))
    #print('s02{0}'.format(s2))
    #print(xmax1,xmin1,xmax2,xmin2)
    work_jcst.write_xml.write_xml2(scores,url3)

    return scores

list_numbigerthanthreshold_bug=[[0 for i in range(11)] for j in range(11)]
#list_numbigerthanthreshold_feature=[[0 for i in range(9)] for j in range(9)]
list_bt_bug=[[0 for i in range(11)] for j in range(11)]
#list_bt_feature=[[0 for i in range(9)] for j in range(9)]

for i in range(0,11):
    urlScores1_bug01 = 'F:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\scores4_bm25fext\\scores1_'
    urlScores1_bug02 = 'F:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\scores4_bm25fext\\scores1_'

    #urlScores1_bug02='F:\python_script\work_jcst\\bugReport\\tests\\scores1_'
    urlScores1_bug03 = 'F:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\scores4_bm25fext\\scores1_'
    urlScores1_bug04 = 'F:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\scores4_bm25fext\\scores1_'
    urlScores1_bug05 = 'F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\scores1_'
    urlScores1_bug06 = 'F:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\scores4_bm25fext\\scores1_'
    urlScores1_bug07 = 'F:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\scores4_bm25fext\\scores1_'

    urlScores1_bug08 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\scores4_bm25fext\\scores_'
    urlScores1_bug09 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\Automattic_simplenote-android\scores4_bm25fext\\scores_'
    urlScores1_bug10 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\chrislacy_TweetLanes\scores4_bm25fext\\scores_'
    urlScores1_bug11 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\k9mail_k-9\scores4_bm25fext\\scores_'
    urlScores1_bug12 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\OneBusAway_onebusaway-android\scores4_bm25fext\\scores_'
    urlScores1_bug13 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\owncloud_android\scores4_bm25fext\\scores_'
    urlScores1_bug14 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\sunlightlabs_congress-android\scores4_bm25fext\\scores_'
    urlScores1_bug15 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\scores4_bm25fext\\scores_'
    urlScores1_bug16 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\scores4_bm25fext\\scores_'
    urlScores1_bug17 = 'F:\python_script\work_jcst\\bugReport\\variate\_purebug\\wordpress-mobile_WordPress-Android\scores4_bm25fext\\scores_'

    num01=i/10

    urlScores1_bug01+='{0}_feature.xml'.format(num01)
    urlScores1_bug02 += '{0}_feature.xml'.format(num01)
    urlScores1_bug03 += '{0}_feature.xml'.format(num01)
    urlScores1_bug04 += '{0}_feature.xml'.format(num01)
    urlScores1_bug05 += '{0}_feature.xml'.format(num01)
    urlScores1_bug06 += '{0}_feature.xml'.format(num01)
    urlScores1_bug07 += '{0}_feature.xml'.format(num01)
    urlScores1_bug08 += '{0}_feature.xml'.format(num01)
    urlScores1_bug09 += '{0}_feature.xml'.format(num01)
    urlScores1_bug10 += '{0}_feature.xml'.format(num01)
    urlScores1_bug11 += '{0}_feature.xml'.format(num01)
    urlScores1_bug12 += '{0}_feature.xml'.format(num01)
    urlScores1_bug13 += '{0}_feature.xml'.format(num01)
    urlScores1_bug14 += '{0}_feature.xml'.format(num01)
    urlScores1_bug15 += '{0}_feature.xml'.format(num01)
    urlScores1_bug16 += '{0}_feature.xml'.format(num01)
    urlScores1_bug17 += '{0}_feature.xml'.format(num01)

    scores1_bug=calculate1(url17_bug_review,url17_bug_none_sim,num01,urlScores1_bug17)
    print('{0}scores1_bug{1}'.format(num01,scores1_bug))


    for num02 in range(0,11):
        num03=num02/10
        sumbug=0
        m=0
        list01=[]
        for score in scores1_bug:
            if score > num03:
                sumbug+=1
                list01.append(m)
            m+=1
        list_numbigerthanthreshold_bug[i][num02]=sumbug
        list_bt_bug[i][num02]=list01

print('list_numbigerthanthreshold_bug{0}'.format(list_numbigerthanthreshold_bug))
#print(list_numbigerthanthreshold_feature)
print(list_bt_bug)
#print(list_bt_feature)
url01='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AnimeNeko_Atarashii.xml'
url02='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AntennaPod_AntennaPod.xml'
url03='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\cgeo_cgeo.xml'
url04='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\moezbhatti_qksms.xml'
url05='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\talklittle_reddit-is-fun.xml'
url06='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\TwidereProject_Twidere-Android.xml'
url071='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'
url072='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'
url073='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'

url08='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\ankidroid_Anki-Android.xml'
url09='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\Automattic_simplenote-android.xml'
url10='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\chrislacy_TweetLanes.xml'
url11='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\k9mail_k-9.xml'
url12='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\OneBusAway_onebusaway-android.xml'
url13='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\owncloud_android.xml'
url14='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\sunlightlabs_congress-android.xml'
url15='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\the-blue-alliance_the-blue-alliance-android.xml'
url16='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\UweTrottmann_SeriesGuide.xml'
url17='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\wordpress-mobile_WordPress-Android.xml'

list01=work_jcst.readReport.read_kind_SURF(url17)
#list01=work_jcst.readReport.read_3kind_SURF(url071,url072,url073)
l_b=list01[0]
l_f=list01[1]
print('l_b{0}'.format(l_b))
print('l_f{0}'.format(l_f))
#list_tp=work_jcst.func_prf.c_intersection(list01,list_bt_bug,list_bt_feature)
list_tp=work_jcst.func_prf.c_intersection1(list01,list_bt_bug)
list_tpb=list_tp[0]
list_tpf=list_tp[1]
print('list_tpb{0}'.format(list_tpb))
print('list_tpf{0}'.format(list_tpf))
#----------------------------------------------------------
#list_precision=work_jcst.func_prf.c_precision(list_tp,list_numbigerthanthreshold_bug,list_numbigerthanthreshold_feature)
list_precision=work_jcst.func_prf.c_precision(list_tp,list_numbigerthanthreshold_bug,list_numbigerthanthreshold_bug)

list_precision_b=list_precision[0]
list_precision_f=list_precision[1]
print(list_precision_b)
print(list_precision_f)

list_recall=work_jcst.func_prf.c_recall(list01,list_tp)
list_recall_b=list_recall[0]
list_recall_f=list_recall[1]
print('list_recall_b{0}'.format(list_recall_b))
print('list_recall_f{0}'.format(list_recall_f))

list_fmeasure=work_jcst.func_prf.c_fmeasure(list_precision,list_recall)
list_fmeasure_b=list_fmeasure[0]
list_fmeasure_f=list_fmeasure[1]
print(list_fmeasure_b)
print(len(list_fmeasure_b))
print(list_fmeasure_f)
print(len(list_fmeasure_f))
#-------------------------------------------------------------------------
urlp01='F:\python_script\work_jcst\\bugReport\\variate\\AnimeNeko_Atarashii\scores4_bm25fext\\precision_b.xlsx'
urlr01='F:\python_script\work_jcst\\bugReport\\variate\\AnimeNeko_Atarashii\scores4_bm25fext\\recall_b.xlsx'
urlf01='F:\python_script\work_jcst\\bugReport\\variate\\AnimeNeko_Atarashii\scores4_bm25fext\\fmeasure_b.xlsx'
urlp02='F:\python_script\work_jcst\\bugReport\\variate\\AntennaPod_AntennaPod\scores4_bm25fext\\precision_b.xlsx'
urlr02='F:\python_script\work_jcst\\bugReport\\variate\\AntennaPod_AntennaPod\scores4_bm25fext\\recall_b.xlsx'
urlf02='F:\python_script\work_jcst\\bugReport\\variate\\AntennaPod_AntennaPod\scores4_bm25fext\\fmeasure_b.xlsx'
urlp03='F:\python_script\work_jcst\\bugReport\\variate\\cgeo_cgeo\scores4_bm25fext\\precision_b.xlsx'
urlr03='F:\python_script\work_jcst\\bugReport\\variate\\cgeo_cgeo\scores4_bm25fext\\recall_b.xlsx'
urlf03='F:\python_script\work_jcst\\bugReport\\variate\\cgeo_cgeo\scores4_bm25fext\\fmeasure_b.xlsx'
urlp04='F:\python_script\work_jcst\\bugReport\\variate\\moezbhatti_qksms\scores4_bm25fext\\precision_b.xlsx'
urlr04='F:\python_script\work_jcst\\bugReport\\variate\\moezbhatti_qksms\scores4_bm25fext\\recall_b.xlsx'
urlf04='F:\python_script\work_jcst\\bugReport\\variate\\moezbhatti_qksms\scores4_bm25fext\\fmeasure_b.xlsx'
urlp05='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\precision_b.xlsx'
urlr05='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\recall_b.xlsx'
urlf05='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\fmeasure_b.xlsx'
urlp06='F:\python_script\work_jcst\\bugReport\\variate\\TwidereProject_Twidere-Android\scores4_bm25fext\\precision_b.xlsx'
urlr06='F:\python_script\work_jcst\\bugReport\\variate\\TwidereProject_Twidere-Android\scores4_bm25fext\\recall_b.xlsx'
urlf06='F:\python_script\work_jcst\\bugReport\\variate\\TwidereProject_Twidere-Android\scores4_bm25fext\\fmeasure_b.xlsx'
urlp07='F:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\precision_b.xlsx'
urlr07='F:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\recall_b.xlsx'
urlf07='F:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\fmeasure_b.xlsx'

urlp_01='F:\python_script\work_jcst\\bugReport\\variate\\AnimeNeko_Atarashii\scores4_bm25fext\\precision_f.xlsx'
urlr_01='F:\python_script\work_jcst\\bugReport\\variate\\AnimeNeko_Atarashii\scores4_bm25fext\\recall_f.xlsx'
urlf_01='F:\python_script\work_jcst\\bugReport\\variate\\AnimeNeko_Atarashii\scores4_bm25fext\\fmeasure_f.xlsx'
urlp_02='F:\python_script\work_jcst\\bugReport\\variate\\AntennaPod_AntennaPod\scores4_bm25fext\\precision_f.xlsx'
urlr_02='F:\python_script\work_jcst\\bugReport\\variate\\AntennaPod_AntennaPod\scores4_bm25fext\\recall_f.xlsx'
urlf_02='F:\python_script\work_jcst\\bugReport\\variate\\AntennaPod_AntennaPod\scores4_bm25fext\\fmeasure_f.xlsx'
urlp_03='F:\python_script\work_jcst\\bugReport\\variate\\cgeo_cgeo\scores4_bm25fext\\precision_f.xlsx'
urlr_03='F:\python_script\work_jcst\\bugReport\\variate\\cgeo_cgeo\scores4_bm25fext\\recall_f.xlsx'
urlf_03='F:\python_script\work_jcst\\bugReport\\variate\\cgeo_cgeo\scores4_bm25fext\\fmeasure_f.xlsx'
urlp_04='F:\python_script\work_jcst\\bugReport\\variate\\moezbhatti_qksms\scores4_bm25fext\\precision_f.xlsx'
urlr_04='F:\python_script\work_jcst\\bugReport\\variate\\moezbhatti_qksms\scores4_bm25fext\\recall_f.xlsx'
urlf_04='F:\python_script\work_jcst\\bugReport\\variate\\moezbhatti_qksms\scores4_bm25fext\\fmeasure_f.xlsx'
urlp_05='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\precision_f.xlsx'
urlr_05='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\recall_f.xlsx'
urlf_05='F:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores4_bm25fext\\fmeasure_f.xlsx'
urlp_06='F:\python_script\work_jcst\\bugReport\\variate\\TwidereProject_Twidere-Android\scores4_bm25fext\\precision_f.xlsx'
urlr_06='F:\python_script\work_jcst\\bugReport\\variate\\TwidereProject_Twidere-Android\scores4_bm25fext\\recall_f.xlsx'
urlf_06='F:\python_script\work_jcst\\bugReport\\variate\\TwidereProject_Twidere-Android\scores4_bm25fext\\fmeasure_f.xlsx'
urlp_07='F:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\precision_f.xlsx'
urlr_07='F:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\recall_f.xlsx'
urlf_07='F:\python_script\work_jcst\\bugReport\\variate\\WhisperSystems_Signal-Android\scores4_bm25fext\\fmeasure_f.xlsx'

urlp08='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\scores4_bm25fext\\precision_b.xlsx'
urlr08='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\scores4_bm25fext\\recall_b.xlsx'
urlf08='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\scores4_bm25fext\\fmeasure_b.xlsx'
urlp09='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\Automattic_simplenote-android\scores4_bm25fext\\precision_b.xlsx'
urlr09='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\Automattic_simplenote-android\scores4_bm25fext\\recall_b.xlsx'
urlf09='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\Automattic_simplenote-android\scores4_bm25fext\\fmeasure_b.xlsx'
urlp10='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\chrislacy_TweetLanes\scores4_bm25fext\\precision_b.xlsx'
urlr10='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\chrislacy_TweetLanes\scores4_bm25fext\\recall_b.xlsx'
urlf10='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\chrislacy_TweetLanes\scores4_bm25fext\\fmeasure_b.xlsx'
urlp11='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\k9mail_k-9\scores4_bm25fext\\precision_b.xlsx'
urlr11='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\k9mail_k-9\scores4_bm25fext\\recall_b.xlsx'
urlf11='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\k9mail_k-9\scores4_bm25fext\\fmeasure_b.xlsx'
urlp12='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\OneBusAway_onebusaway-android\scores4_bm25fext\\precision_b.xlsx'
urlr12='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\OneBusAway_onebusaway-android\scores4_bm25fext\\recall_b.xlsx'
urlf12='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\OneBusAway_onebusaway-android\scores4_bm25fext\\fmeasure_b.xlsx'
urlp13='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\owncloud_android\scores4_bm25fext\\precision_b.xlsx'
urlr13='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\owncloud_android\scores4_bm25fext\\recall_b.xlsx'
urlf13='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\owncloud_android\scores4_bm25fext\\fmeasure_b.xlsx'
urlp14='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\sunlightlabs_congress-android\scores4_bm25fext\\precision_b.xlsx'
urlr14='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\sunlightlabs_congress-android\scores4_bm25fext\\recall_b.xlsx'
urlf14='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\sunlightlabs_congress-android\scores4_bm25fext\\fmeasure_b.xlsx'
urlp15='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\scores4_bm25fext\\precision_b.xlsx'
urlr15='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\scores4_bm25fext\\recall_b.xlsx'
urlf15='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\scores4_bm25fext\\fmeasure_b.xlsx'
urlp16='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\scores4_bm25fext\\precision_b.xlsx'
urlr16='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\scores4_bm25fext\\recall_b.xlsx'
urlf16='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\scores4_bm25fext\\fmeasure_b.xlsx'
urlp17='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\wordpress-mobile_WordPress-Android\scores4_bm25fext\\precision_b.xlsx'
urlr17='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\wordpress-mobile_WordPress-Android\scores4_bm25fext\\recall_b.xlsx'
urlf17='F:\python_script\work_jcst\\bugReport\\variate\\_purebug\\wordpress-mobile_WordPress-Android\scores4_bm25fext\\fmeasure_b.xlsx'

numalpha=11
numthreshold=11
wb1=Workbook()
booksheet1=wb1.active
for i in range(numalpha):
  booksheet1["A%d" % (i+1)].value = i/10
for i in range(numalpha):
    for j in range(numthreshold):
        booksheet1['%s%d'%(chr(ord('B')+i),j+1)].value=list_precision_b[i][j]

wb1.save(urlp17)

#------------------------------------------------------------------------
wb2=Workbook()
booksheet2=wb2.active
for i in range(numalpha):
  booksheet2["A%d" % (i+1)].value = (i)/10
for i in range(numalpha):
    for j in range(numthreshold):
        booksheet2['%s%d'%(chr(ord('B')+i),j+1)].value=list_recall_b[i][j]


wb2.save(urlr17)

#-----------------------------------------------------------------------------------------
wb3=Workbook()
booksheet3=wb3.active
for i in range(numalpha):
  booksheet3["A%d" % (i+1)].value = (i)/10
for i in range(numalpha):
    for j in range(numthreshold):
        booksheet3['%s%d'%(chr(ord('B')+i),j+1)].value=list_fmeasure_b[i][j]


wb3.save(urlf17)
