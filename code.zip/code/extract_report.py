import xml.dom.minidom

url01='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\AnimeNeko_Atarashii.xml'
url02='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\ankidroid_Anki-Android.xml'
url03='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\AntennaPod_AntennaPod.xml'
url04='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\Automattic_simplenote-android.xml'
url05='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\cgeo_cgeo.xml'
url06='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\chrislacy_TweetLanes.xml'
url07='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\k9mail_k-9.xml'
url08='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\moezbhatti_qksms.xml'
url09='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\OneBusAway_onebusaway-android.xml'
url10='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\owncloud_android.xml'
url11='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\sunlightlabs_congress-android.xml'
url12='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\talklittle_reddit-is-fun.xml'
url13='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\the-blue-alliance_the-blue-alliance-android.xml'
url14='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\TwidereProject_Twidere-Android.xml'
url15='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\UweTrottmann_SeriesGuide.xml'
url16='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\WhisperSystems_Signal-Android.xml'
url17='F:\python_script\work_jcst\\bugReport\\bugReport_Step01\\wordpress-mobile_WordPress-Android.xml'
dom=xml.dom.minidom.parse(url17)
root=dom.documentElement
allmanager=root.getElementsByTagName('Manager')
nodekey1=root.getElementsByTagName('labels')
nodevalue1=root.getElementsByTagName('description')
nodetitle=root.getElementsByTagName('title')
nodeBugId=root.getElementsByTagName('bugID')
nodeUrl=root.getElementsByTagName('url')

#在内存中创建一个空的文档
doc = xml.dom.minidom.Document()
#创建一个根节点Managers对象
root = doc.createElement('reports')
#设置根节点的属性

#将根节点添加到文档对象中
doc.appendChild(root)
j=0
data1=0
for i in range(len(allmanager)):
    #list01.append([nodekey1[i].firstChild.data,nodevalue1[i].firstChild.data])
    try:
        nodelabel=nodekey1[i].getElementsByTagName('label')

        flag_ifgoal=0
        for nodelabel01 in nodelabel:
            data1=nodelabel01.firstChild.data
            if str(data1)!= 'feature'and str(data1)!= 'None yet' and str(data1)!= '[Type] Bug':
                continue
            else:
                flag_ifgoal=1
                break
        #print(data1)
        data2=nodevalue1[i].firstChild.data
        data3=nodetitle[i].firstChild.data
        data4=nodeBugId[i].firstChild.data
        data5=nodeUrl[i].firstChild.data
        if flag_ifgoal == 0:
           nodeManager = doc.createElement('report')
           nodeManager.setAttribute('Number', str(j))
           nodeKey = doc.createElement('label')
           # 给叶子节点name设置一个文本节点，用于显示文本内容
           nodeKey.appendChild(doc.createTextNode('UnBF'))
           nodeValue = doc.createElement("description")
           nodeValue.appendChild(doc.createTextNode(data2))

           node_title=doc.createElement('summary')
 
           node_title.appendChild(doc.createTextNode(data3))

           node_Url=doc.createElement('url')
           node_Url.appendChild(doc.createTextNode(data5))
           node_BugId=doc.createElement('bugID')
           node_BugId.appendChild((doc.createTextNode(data4)))

           # 将各叶子节点添加到父节点Manager中，
           # 最后将Manager添加到根节点Managers中
           nodeManager.appendChild(node_title)
           nodeManager.appendChild(node_Url)
           nodeManager.appendChild(node_BugId)
           nodeManager.appendChild(nodeKey)
           nodeManager.appendChild(nodeValue)
           root.appendChild(nodeManager)
           j+=1
        else:
            continue
    except AttributeError:
        continue

url01_bug='F:\python_script\work_jcst\\test\AnimeNeko_Atarashii.xml'
url01_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\AnimeNeko_Atarashii.xml'
url01_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\AnimeNeko_Atarashii.xml'
url01_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\AnimeNeko_Atarashii.xml'

url02_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\ankidroid_Anki-Android.xml'
url02_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\ankidroid_Anki-Android.xml'
url02_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\ankidroid_Anki-Android.xml'
url02_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\ankidroid_Anki-Android.xml'

url03_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\AntennaPod_AntennaPod.xml'
url03_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\AntennaPod_AntennaPod.xml'
url03_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\AntennaPod_AntennaPod.xml'
url03_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\AntennaPod_AntennaPod.xml'

url04_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\Automattic_simplenote-android.xml'
url04_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\Automattic_simplenote-android.xml'
url04_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\Automattic_simplenote-android.xml'
url04_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\Automattic_simplenote-android.xml'

url05_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\cgeo_cgeo.xml'
url05_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\cgeo_cgeo.xml'
url05_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\cgeo_cgeo.xml'
url05_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\cgeo_cgeo.xml'

url06_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\chrislacy_TweetLanes.xml'
url06_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\chrislacy_TweetLanes.xml'
url06_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\chrislacy_TweetLanes.xml'
url06_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\chrislacy_TweetLanes.xml'

url07_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\k9mail_k-9.xml'
url07_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\k9mail_k-9.xml'
url07_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\k9mail_k-9.xml'
url07_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\k9mail_k-9.xml'

url08_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\moezbhatti_qksms.xml'
url08_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\moezbhatti_qksms.xml'
url08_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\moezbhatti_qksms.xml'
url08_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\moezbhatti_qksms.xml'

url09_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\OneBusAway_onebusaway-android.xml'
url09_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\OneBusAway_onebusaway-android.xml'
url09_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\OneBusAway_onebusaway-android.xml'
url09_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\OneBusAway_onebusaway-android.xml'

url10_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\owncloud_android.xml'
url10_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\owncloud_android.xml'
url10_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\owncloud_android.xml'
url10_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\owncloud_android.xml'

url11_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\sunlightlabs_congress-android.xml'
url11_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\sunlightlabs_congress-android.xml'
url11_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\sunlightlabs_congress-android.xml'
url11_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\sunlightlabs_congress-android.xml'

url12_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\talklittle_reddit-is-fun.xml'
url12_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\talklittle_reddit-is-fun.xml'
url12_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\talklittle_reddit-is-fun.xml'
url12_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\talklittle_reddit-is-fun.xml'

url13_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\the-blue-alliance_the-blue-alliance-android.xml'
url13_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\the-blue-alliance_the-blue-alliance-android.xml'
url13_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\the-blue-alliance_the-blue-alliance-android.xml'
url13_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\the-blue-alliance_the-blue-alliance-android.xml'

url14_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\TwidereProject_Twidere-Android.xml'
url14_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\TwidereProject_Twidere-Android.xml'
url14_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\TwidereProject_Twidere-Android.xml'
url14_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\TwidereProject_Twidere-Android.xml'

url15_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\UweTrottmann_SeriesGuide.xml'
url15_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\UweTrottmann_SeriesGuide.xml'
url15_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\UweTrottmann_SeriesGuide.xml'
url15_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\UweTrottmann_SeriesGuide.xml'

url16_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\WhisperSystems_Signal-Android.xml'
url16_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\WhisperSystems_Signal-Android.xml'
url16_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\WhisperSystems_Signal-Android.xml'
url16_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\WhisperSystems_Signal-Android.xml'

url17_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\wordpress-mobile_WordPress-Android.xml'
url17_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\wordpress-mobile_WordPress-Android.xml'
url17_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\wordpress-mobile_WordPress-Android.xml'
url17_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\wordpress-mobile_WordPress-Android.xml'

url01_irr_feature='E:\python_script\work_jcst\\bugReport\\bugReport_irr\\forFeature\AnimeNeko_Atarashii.xml'
url01_irr_bug='E:\python_script\work_jcst\\bugReport\\bugReport_irr\\forBug\AnimeNeko_Atarashii.xml'
url03_irr_feature='E:\python_script\work_jcst\\bugReport\\bugReport_irr\\forFeature\AntennaPod_AntennaPod.xml'

#fp = open(url16_feature, 'w',encoding="utf-8")
#fp = open(url03_irr_feature, 'w',encoding="utf-8")
#fp = open(url01_irr_bug, 'w',encoding="utf-8")
fp = open(url17_nonBF, 'w',encoding="utf-8")
#fp = open(url16_none, 'w',encoding="utf-8")
doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")