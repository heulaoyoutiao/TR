from gensim import corpora
import re

#vec: [(0, 1), (1, 1)]
# corpus: [(0, 1), (1, 1), (2, 1)]
# output: [(0, 0.70710678), (1, 0.70710678)]
def tf(vec):
    sum1 = 0
    for ele1 in vec:
        sum1 += ele1[1]

    listVec = [ (0,0) for i in range(len(vec))]
    for i, ele2 in enumerate(vec):
        listVec[i] = (ele2[0], ele2[1]/sum1)
    return listVec

def tf2(corpus):
    list1 = [ [0] for i in range(len(corpus))]
    for i, ele in enumerate(corpus):
        list1[i] = tf(ele)
    return list1

def complement(numSize,corpus):
    list1=[[(j,0)for j in range(numSize)]for i in range(len(corpus))]
    for i, ele1 in enumerate(corpus):
        for ele2 in ele1:
            list1[i][ele2[0]]=ele2
    return list1

#document frequency
def df(word,corpus):
    sum=0
    for ele in corpus:
        if word in ele:
            sum+=1
    return sum


#构造Lr方法需要的向量
def cv1(str1,corpus2):
    list=[]

    for corpus1 in corpus2:
        list1 = str1.split()
        list2 = [0 for m in range(len(list1))]
        a = " ".join(corpus1)
        for j, word1 in enumerate(list1):
            str2 = '{0}.*?'.format(word1)
            list3=re.findall(str2, a)
            if len(list3)>0:
                list2[j]=len(list3)/len(corpus1)*df(word1,corpus2)
                #print('count word {0}, j {1}'.format(corpus1.count(word1), j))
                #print('len() {0}, word {1}'.format(len(corpus1),word1))
                #print('list[j] {0}'.format(list2[j]))
        list.append(list2)
    return list



if __name__ == '__main__':
    texts = [['human', 'interface', 'computer'],
     ['survey', 'user', 'computer', 'system', 'response', 'time'],
     ['eps', 'user', 'interface', 'system'],
     ['system', 'human', 'system', 'eps'],
     ['user', 'response', 'time'],
     ['trees'],
     ['graph', 'trees'],
     ['graph', 'minors', 'trees'],
     ['graph', 'minors', 'survey']]



    str11='graph human computer survey'
    list02=cv1(str11,texts)
    print(list02)
