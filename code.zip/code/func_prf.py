import work_jcst.readReport
N=11
def c_intersection(list01,list_btb,list_btf):

    l_b=list01[0]
    l_f=list01[1]

  #  relevant_bug=len(list01[0])
   # relevant_feature=len(list01[1])
    list_tp_b01=[]
    for i in range(N):
        list_tp_b02=[]
        for j in range(N):
            sum01=0
            for token1 in list_btb[i][j]:
                for token2 in l_b:
                    if token1==token2:
                        sum01+=1
            list_tp_b02.append(sum01)
        list_tp_b01.append(list_tp_b02)

    list_tp_f01 = []
    for i in range(N):
        list_tp_f02 = []
        for j in range(N):
            sum01 = 0
            for token1 in list_btf[i][j]:
                for token2 in l_f:
                    if token1 == token2:
                        sum01 += 1
            list_tp_f02.append(sum01)
        list_tp_f01.append(list_tp_f02)
    return [list_tp_b01,list_tp_f01]

def c_intersection1(list01,list_btb):

    l_b=list01[0]

    list_tp_b01=[]
    for i in range(N):
        list_tp_b02=[]
        for j in range(N):
            sum01=0
            for token1 in list_btb[i][j]:
                for token2 in l_b:
                    if token1==token2:
                        sum01+=1
            list_tp_b02.append(sum01)
        list_tp_b01.append(list_tp_b02)

    return [list_tp_b01,0]
def c_intersection1f(list01,list_btb):

    l_b=list01[1]

    list_tp_b01=[]
    for i in range(N):
        list_tp_b02=[]
        for j in range(N):
            sum01=0
            for token1 in list_btb[i][j]:
                for token2 in l_b:
                    if token1==token2:
                        sum01+=1
            list_tp_b02.append(sum01)
        list_tp_b01.append(list_tp_b02)

    return [list_tp_b01,0]

def c_precision(list_tp,list_btb,list_btf):
    list01=[[0 for i in range(N)]for j in range(N)]
    list02=[[0 for i in range(N)]for j in range(N)]
    for i in range(N):
        for j in range(N):
            if list_btb[i][j]==0:
                list01[i][j]=0
            else:
                list01[i][j]=list_tp[0][i][j]/list_btb[i][j]
            if list_btf[i][j]==0:
                list02[i][j] = 0
            else:
                #list02[i][j] = list_tp[1][i][j] / list_btf[i][j]
                list02[i][j]=0
    return [list01,list02]

def c_recall(list_rel,list_tp):
    list01 = [[0 for i in range(N)] for j in range(N)]
    list02 = [[0 for i in range(N)] for j in range(N)]
    l_b=list_rel[0]
    l_f=list_rel[1]
    for i in range(N):
        for j in range(N):
            if len(l_b)==0:
                list01[i][j]=0
            else:
                list01[i][j] = list_tp[0][i][j] / len(l_b)
            if len(l_f)==0:
                list02[i][j]=0
            else:
                #list02[i][j] = list_tp[1][i][j] / len(l_f)
                list02[i][j]=0
    return [list01,list02]


def c_fmeasure(listp,listr):
    list01 = [[0 for i in range(N)] for j in range(N)]
    list02 = [[0 for i in range(N)] for j in range(N)]
    for i in range(N):
        for j in range(N):
            if (listp[0][i][j]+listr[0][i][j])==0:
                list01[i][j]=0
            else:
                list01[i][j]=2*listp[0][i][j]*listr[0][i][j] /(listp[0][i][j]+listr[0][i][j])
            if (listp[1][i][j]+listr[1][i][j])==0:
                list02[i][j]=0
            else:
                list02[i][j] =2*listp[1][i][j]*listr[1][i][j] /(listp[1][i][j]+listr[1][i][j])
    return [list01,list02]
