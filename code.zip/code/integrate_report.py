from xml.dom import minidom
import logging
import xml
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
sum=9999
def write_xml(doc1,url):
    #在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    #创建一个根节点Managers对象
    root = doc.createElement('Managers')
    #设置根节点的属性
    root.setAttribute('author', 'heulaoyoutiao')
    root.setAttribute('address', 'heu')
    #将根节点添加到文档对象中
    doc.appendChild(root)
    j=0
    for i in doc1 :
        nodeManager = doc.createElement('Manager')
        nodeManager.setAttribute('Number',str(j))
        nodeKey = doc.createElement('labels')
        #给叶子节点name设置一个文本节点，用于显示文本内容
        num02=0
        #nodelabels01=[0 for num03 in range(len(i[0]))]
        for instant01 in i[0]:


            nodelabel=doc.createElement('label')
            nodelabel.appendChild(doc.createTextNode(str(instant01)))
            nodeKey.appendChild(nodelabel)
            num02+=1
        #nodeKey.appendChild(doc.createTextNode(str(i[0])))

        nodeabc=doc.createElement('url')
        nodeabc.appendChild(doc.createTextNode(str(i[1])))

        nodetitlew=doc.createElement('title')
        nodetitlew.appendChild(doc.createTextNode(str(i[2])))

        nodeValue = doc.createElement("description")
        nodeValue.appendChild(doc.createTextNode(str(i[3])))

        nodebugID=doc.createElement('bugID')
        nodebugID.appendChild(doc.createTextNode(str(i[4])))
        #将各叶子节点添加到父节点Manager中，
        #最后将Manager添加到根节点Managers中
        nodeManager.appendChild(nodeKey)
        nodeManager.appendChild(nodebugID)
        nodeManager.appendChild(nodeabc)
        nodeManager.appendChild(nodeValue)
        nodeManager.appendChild(nodetitlew)

        root.appendChild(nodeManager)
        j+=1
    #开始写xml文档
    fp = open(url, 'w',encoding='utf-8')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
reviews_list1=[]
for i in range(sum):


    url01 = "E:\python_script\work_jcst\jcstDataSet\\bug report\\AnimeNeko_Atarashii"
    url02 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\\ankidroid_Anki-Android'
    url03 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\moezbhatti_qksms'
    url04 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\owncloud_android'
    url05 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\sunlightlabs_congress-android'
    url06 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\\talklittle_reddit-is-fun'
    url07 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\\the-blue-alliance_the-blue-alliance-android'

    url08='E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\AntennaPod_AntennaPod'
    url09 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\Automattic_simplenote-android'
    url10 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\cgeo_cgeo'
    url11 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\chrislacy_TweetLanes'
    url12 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\k9mail_k-9'
    url13 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\OneBusAway_onebusaway-android'
    url14 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\TwidereProject_Twidere-Android'
    url15 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\\UweTrottmann_SeriesGuide'
    url16 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\WhisperSystems_Signal-Android'
    url17 = 'E:\python_script\work_jcst\jcstDataSet\\bug report\BugReport_seke\wordpress-mobile_WordPress-Android'


    url1=url08+'\\Issue#{0}.xml'.format(i)

    print(url1)
    try:
        dom=minidom.parse(url1)
        root=dom.documentElement
        labels=[]
        nodelabels=root.getElementsByTagName('labels')
        nodelabel01=nodelabels[0].getElementsByTagName('label')
        num01=0
        for a in nodelabel01:
            labels.append(a.firstChild.data)
            num01+=1
        #nodelabel=nodelabels[0].getElementsByTagName('label')
        print(labels)
        nodedescription=root.getElementsByTagName('description')
        nodetitle=root.getElementsByTagName('title')
        nodeurl=root.getElementsByTagName('url')
        nodebugid=root.getElementsByTagName('bugID')
        reviews_list1.append([labels,nodeurl[0].firstChild.data,nodetitle[0].firstChild.data,nodedescription[0].firstChild.data,nodebugid[0].firstChild.data])

    except FileNotFoundError:
        continue
    except xml.parsers.expat.ExpatError:
        continue


url_write01="E:\python_script\work_jcst\\bugReport\\bugReport_Step01\\AnimeNeko_Atarashii.xml"
url_write02='E:\python_script\work_jcst\\bugReport\\bugReport_Step01\\ankidroid_Anki-Android.xml'
url_write03='E:\python_script\work_jcst\\bugReport\\bugReport_Step01\moezbhatti_qksms.xml'
url_write04='E:\python_script\work_jcst\\bugReport\\bugReport_Step01\owncloud_android.xml'
url_write05='E:\python_script\work_jcst\\bugReport\\bugReport_Step01\sunlightlabs_congress-android.xml'
url_write06='E:\python_script\work_jcst\\bugReport\\bugReport_Step01\\talklittle_reddit-is-fun.xml'
url_write07='E:\python_script\work_jcst\\bugReport\\bugReport_Step01\\the-blue-alliance_the-blue-alliance-android.xml'

url_write08 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\AntennaPod_AntennaPod.xml'
url_write09 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\Automattic_simplenote-android.xml'
url_write10 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\cgeo_cgeo.xml'
url_write11 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\chrislacy_TweetLanes.xml'
url_write12 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\k9mail_k-9.xml'
url_write13 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\OneBusAway_onebusaway-android.xml'
url_write14 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\TwidereProject_Twidere-Android.xml'
url_write15 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\\UweTrottmann_SeriesGuide.xml'
url_write16 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\WhisperSystems_Signal-Android.xml'
url_write17 = 'E:\python_script\work_jcst\\bugReport\\bugReport_Step01\wordpress-mobile_WordPress-Android.xml'


write_xml(reviews_list1,url_write08)

