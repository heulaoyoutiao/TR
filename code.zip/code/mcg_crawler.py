#这个文件最终获得了review中每个词在MCG上的相关词数据
import ssl
import urllib.request
from xml.dom import minidom
import xml.dom.minidom
import time
url01_rbd="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\report_bug_dict.xml"
url02_rbd="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\report_bug_dict.xml"
url03_rbd="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\report_bug_dict.xml"
url03_rbd1="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\report_bug_dict01.xml"
url03_rbd2="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\report_bug_dict02.xml"
url03_rbd3="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\report_bug_dict03.xml"

url04_rbd="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\report_bug_dict.xml"
url05_rbd="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\report_bug_dict.xml"
url06_rbd="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\report_bug_dict.xml"
url07_rbd="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\report_bug_dict.xml"
url07_rbd1="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\dict\\report_bug_dict1.xml"
url07_rbd2="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\dict\\report_bug_dict2.xml"


url08_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\report_bug_dict.xml"
url08_rbd1="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\report_bug_dict1.xml"
url08_rbd2="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\report_bug_dict2.xml"
url08_rbd3="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\report_bug_dict3.xml"
url08_rbd4="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\report_bug_dict4.xml"



url09_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\report_bug_dict.xml"
url10_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\report_bug_dict.xml"
url11_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\report_bug_dict.xml"
url12_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\report_bug_dict.xml"
url13_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\report_bug_dict.xml"
url14_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\report_bug_dict.xml"
url15_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\report_bug_dict.xml"
url16_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\report_bug_dict.xml"
url17_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\report_bug_dict.xml"

url01_rbd="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\report_feature_dict.xml"
url02_rbd="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\report_feature_dict.xml"

url03_rbd01="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\report_feature_dict01.xml"
url03_rbd02="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\report_feature_dict02.xml"
url03_rbd03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\report_feature_dict03.xml"
url03_rbd04="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\report_feature_dict04.xml"

url04_rbd="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\report_feature_dict.xml"
url05_rbd="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\report_feature_dict.xml"
url06_rbd="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\report_feature_dict.xml"
url07_rbd="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\report_feature_dict.xml"

dom=minidom.parse(url03_rbd04)
NUM=1151


root=dom.documentElement
allmanager=root.getElementsByTagName('Manager')
nodekey1=root.getElementsByTagName('Key')
nodevalue1=root.getElementsByTagName('Value')

reviews_list1=[]
#reviews=''
i=0
f1=open('review_dict1.txt','w',encoding='utf-8')
for a1 in allmanager:
   reviews_list1.append([nodekey1[i].firstChild.data,nodevalue1[i].firstChild.data])
   #reviews+=comments[i].firstChild.data
   f1.write("{0}:{1}".format(i,[nodekey1[i].firstChild.data,nodevalue1[i].firstChild.data]))
   i+=1
f1.close()

N=2
M=len(reviews_list1)
#-----------------------------------------------------------------------------------------------------------------------
list_mcg=[]
#url01_mcglist='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\mcglist.txt'

#f7=open(url01_mcglist,'w',encoding='utf-8')
doc = xml.dom.minidom.Document()
# 创建一个根节点Managers对象
root = doc.createElement('Managers')
# 设置根节点的属性
root.setAttribute('company', 'microsoft')
root.setAttribute('address', 'heu')
# 将根节点添加到文档对象中
doc.appendChild(root)

for i in range(M):
    time.sleep(1)
    print("休息了1秒")
    if (i+1)%30==0:
        time.sleep(60)
        print("休息了一分钟")
    strmcg=''
    url = "https://concept.research.microsoft.com/api/Concept/ScoreByProb?instance="
    str1 = reviews_list1[i][1]
    url += str1 + "&topK="
    str2 = str(N)
    url += str2
    try:
        content = urllib.request.urlopen(url).read()

    except UnicodeEncodeError:
        content = b'{}'
        continue
    except urllib.error.URLError:
        time.sleep(60)
        content=b'{}'
        print('mcg的网站累到了，让他歇一会儿1')
        continue
    except TimeoutError:
        time.sleep(120)
        content = b'{}'
        print('mcg的网站累到了，让他歇一会儿2')
        continue
        #time.sleep(120)
        #content = urllib.request.urlopen(url).read()
    aaa = str(content, encoding="utf-8")
    bbb = eval(aaa)
    value_list1 = list(bbb.items())
    nodeManager = doc.createElement('Manager')
    nodeManager.setAttribute('Number',str(i+NUM))
    for j in value_list1:
        nodeKey = doc.createElement('Key')
        # 给叶子节点name设置一个文本节点，用于显示文本内容
        nodeKey.appendChild(doc.createTextNode(str(j[0])))
        nodeValue = doc.createElement("Value")
        nodeValue.appendChild(doc.createTextNode(str(j[1])))
        # 将各叶子节点添加到父节点Manager中，
        # 最后将Manager添加到根节点Managers中
        nodeManager.appendChild(nodeKey)
        nodeManager.appendChild(nodeValue)
        root.appendChild(nodeManager)
    #Work2.write_xml.write_xml(value_list1)
    print('{0}:'.format(i),value_list1)
    strmcg+='第{0}个词'.format(i)
    strmcg+=str(value_list1)+'\n'
#    f7.write(strmcg)
    list_mcg.append(value_list1)

url01_mcgresult='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\mcgresult_bug.xml'
url02_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\mcgresult_bug.xml"
url03_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\mcgresult_bug.xml"
url03_mcgresult1="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\mcgresult_bug1.xml"
url03_mcgresult2="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\mcgresult_bug2.xml"
url03_mcgresult3="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\mcgresult_bug3.xml"



url04_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\mcgresult_bug.xml"
url04_mcgresult1="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\dict\\mcgresult_bug1.xml"
url04_mcgresult2="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\dict\\mcgresult_bug2.xml"

url05_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\mcgresult_bug.xml"
url06_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\mcgresult_bug.xml"
url07_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\mcgresult_bug.xml"
url07_mcgresult1="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\dict\\mcgresult_bug1.xml"
url07_mcgresult2="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\dict\\mcgresult_bug2.xml"

url08_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\mcgresult_bug.xml"
url08_mcgresult1="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\mcgresult_bug1.xml"
url08_mcgresult2="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\mcgresult_bug2.xml"
url08_mcgresult3="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\mcgresult_bug3.xml"
url08_mcgresult4="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\mcgresult_bug4.xml"



url09_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\mcgresult_bug.xml"
url10_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\mcgresult_bug.xml"
url11_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\mcgresult_bug.xml"
url12_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\mcgresult_bug.xml"
url13_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\mcgresult_bug.xml"
url14_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\mcgresult_bug.xml"
url15_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\mcgresult_bug.xml"
url16_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\mcgresult_bug.xml"
url17_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\mcgresult_bug.xml"

url01_mcgresult='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\mcgresult_feature.xml'
url02_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\mcgresult_feature.xml"

url03_mcgresult01="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\mcgresult_feature01.xml"
url03_mcgresult02="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\mcgresult_feature02.xml"
url03_mcgresult03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\mcgresult_feature03.xml"
url03_mcgresult04="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\mcgresult_feature04.xml"

url04_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\mcgresult_feature.xml"
url05_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\mcgresult_feature.xml"
url06_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\mcgresult_feature.xml"
url07_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\mcgresult_feature.xml"

fp = open(url03_mcgresult04, 'w')
doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
#f7.close()
print(list_mcg)
