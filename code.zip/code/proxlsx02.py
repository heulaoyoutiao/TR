from openpyxl import load_workbook
from openpyxl import Workbook

url01_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\scores1_tfidf\\fmeasure_f.xlsx'
url02_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\scores1_tfidf\\fmeasure_f2.xlsx'
url03_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\scores1_tfidf\\fmeasure_f3.xlsx'
url04_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\scores1_tfidf\\fmeasure_f4.xlsx'
url05_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\scores1_tfidf\\fmeasure_f5.xlsx'
url06_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\scores1_tfidf\\fmeasure_f6.xlsx'
url07_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\scores1_tfidf\\fmeasure_f7.xlsx'

'''
url08_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\scores4_bm25fext\\fmeasure4_b08.xlsx'
url09_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\Automattic_simplenote-android\scores4_bm25fext\\fmeasure4_b09.xlsx'
url10_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\chrislacy_TweetLanes\scores4_bm25fext\\fmeasure4_b10.xlsx'
url11_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\k9mail_k-9\scores4_bm25fext\\fmeasure4_b11.xlsx'
url12_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\OneBusAway_onebusaway-android\scores4_bm25fext\\fmeasure4_b12.xlsx'
url13_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\owncloud_android\scores4_bm25fext\\fmeasure4_b13.xlsx'
url14_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\sunlightlabs_congress-android\scores4_bm25fext\\fmeasure4_b14.xlsx'
url15_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\scores4_bm25fext\\fmeasure4_b15.xlsx'
url16_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\scores4_bm25fext\\fmeasure4_b16.xlsx'
url17_tfbug_fm='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\wordpress-mobile_WordPress-Android\scores4_bm25fext\\fmeasure4_b17.xlsx'
'''

wb=load_workbook(url01_tfbug_fm)
sheet = wb["Sheet"]
'''
for i in sheet["A"]:
  print(i.value, end=" ")
'''
list_tfbug_fm01=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm01[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url02_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm02=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm02[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url03_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm03=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm03[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url04_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm04=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm04[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url05_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm05=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm05[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url06_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm06=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm06[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url07_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm07=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm07[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value
'''
wb=load_workbook(url08_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm08=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm08[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url09_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm09=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm09[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url10_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm10=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm10[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url11_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm11=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm11[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url12_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm12=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm12[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url13_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm13=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm13[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url14_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm14=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm14[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url15_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm15=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm15[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url16_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm16=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm16[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value

wb=load_workbook(url17_tfbug_fm)
sheet = wb["Sheet"]
list_tfbug_fm17=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm17[i][j]=sheet['%s%d'%(chr(ord('B')+i),j+1)].value
'''
list_tfbug_fm18=[[0 for i in range(9)]for j in range(9)]
for i in range(9):
    for j in range(9):
        list_tfbug_fm01[i][j]=list_tfbug_fm01[i][j]*31
        list_tfbug_fm02[i][j] = list_tfbug_fm02[i][j] * 382
        list_tfbug_fm03[i][j] = list_tfbug_fm03[i][j] * 652
        list_tfbug_fm04[i][j] = list_tfbug_fm04[i][j] * 365
        list_tfbug_fm05[i][j] = list_tfbug_fm05[i][j] * 6
        list_tfbug_fm06[i][j] = list_tfbug_fm06[i][j] * 247
        list_tfbug_fm07[i][j] = list_tfbug_fm07[i][j] * 3090
        '''
        list_tfbug_fm08[i][j] = list_tfbug_fm08[i][j] * 366
        list_tfbug_fm09[i][j] = list_tfbug_fm09[i][j] * 44
        list_tfbug_fm10[i][j] = list_tfbug_fm10[i][j] * 22
        list_tfbug_fm11[i][j] = list_tfbug_fm11[i][j] * 468
        list_tfbug_fm12[i][j] = list_tfbug_fm12[i][j] * 30
        list_tfbug_fm13[i][j] = list_tfbug_fm13[i][j] * 303
        list_tfbug_fm14[i][j] = list_tfbug_fm14[i][j] * 526
        list_tfbug_fm15[i][j] = list_tfbug_fm15[i][j] * 101
        list_tfbug_fm16[i][j] = list_tfbug_fm16[i][j] * 195
        list_tfbug_fm17[i][j] = list_tfbug_fm17[i][j] * 346
'''
        list_tfbug_fm18[i][j]=list_tfbug_fm01[i][j]+list_tfbug_fm02[i][j]+list_tfbug_fm03[i][j]+list_tfbug_fm04[i][j]+list_tfbug_fm05[i][j]+list_tfbug_fm06[i][j]+list_tfbug_fm07[i][j]

        list_tfbug_fm18[i][j]=list_tfbug_fm18[i][j]/4773

wb1=Workbook()
booksheet1=wb1.active
for i in range(9):
    booksheet1["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet1['%s%d'%(chr(ord('B')+i),j+1)].value=list_tfbug_fm18[i][j]
wb1.save("E:\python_script\work_jcst\\bugReport\\variate\统计\\list_tfFea_fm.xlsx")
