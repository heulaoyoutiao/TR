#这个文件将要构建过渡矩阵
import numpy as np
from xml.dom import minidom
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
from gensim import corpora
import work_jcst.write_xml
import math

url01_rbd="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\report_bug_dict.xml"
url02_rbd="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\report_bug_dict.xml"
url03_rbd="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\report_bug_dict.xml"
url04_rbd="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\report_bug_dict.xml"
url05_rbd="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\report_bug_dict.xml"
url06_rbd="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\report_bug_dict.xml"
url07_rbd="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\report_bug_dict.xml"
url08_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\report_bug_dict.xml"
url09_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\report_bug_dict.xml"
url10_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\report_bug_dict.xml"
url11_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\report_bug_dict.xml"
url12_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\report_bug_dict.xml"
url13_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\report_bug_dict.xml"
url14_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\report_bug_dict.xml"
url15_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\report_bug_dict.xml"
url16_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\report_bug_dict.xml"
url17_rbd="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\report_bug_dict.xml"

url01_rbd="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\report_feature_dict.xml"
url02_rbd="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\report_feature_dict.xml"
url03_rbd="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\report_feature_dict.xml"
url04_rbd="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\report_feature_dict.xml"
url05_rbd="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\report_feature_dict.xml"
url06_rbd="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\report_feature_dict.xml"
url07_rbd="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\report_feature_dict.xml"

dom=minidom.parse(url14_rbd)
root=dom.documentElement
allmanager=root.getElementsByTagName('Manager')
nodekey1=root.getElementsByTagName('Key')
nodevalue1=root.getElementsByTagName('Value')

reviews_list1=[]
#reviews=''
i=0
for a1 in allmanager:
   reviews_list1.append([nodekey1[i].firstChild.data,nodevalue1[i].firstChild.data])
   #reviews+=comments[i].firstChild.data
   i+=1

#url01_num='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\corpus_list1.txt'
#fnum01=open(url01_num,'w',encoding='utf-8')
#for ele in reviews_list1:
#    fnum01.write(str(ele))
#fnum01.close()

url01_rt='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\nonebugreporttfidf.xml'
url02_rt="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\nonebugreporttfidf.xml"
url03_rt="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\nonebugreporttfidf.xml"
url04_rt="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\nonebugreporttfidf.xml"
url05_rt="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\nonebugreporttfidf.xml"
url06_rt="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\nonebugreporttfidf.xml"
url07_rt="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\nonebugreporttfidf.xml"
url08_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\nonebugreporttfidf.xml"
url09_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\nonebugreporttfidf.xml"
url10_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\nonebugreporttfidf.xml"
url11_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\nonebugreporttfidf.xml"
url12_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\nonebugreporttfidf.xml"
url13_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\nonebugreporttfidf.xml"
url14_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\nonebugreporttfidf.xml"
url15_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\nonebugreporttfidf.xml"
url16_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\nonebugreporttfidf.xml"
url17_rt="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\nonebugreporttfidf.xml"

url01_rt='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\nonefeaturereporttfidf.xml'
url02_rt="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\nonefeaturereporttfidf.xml"
url03_rt="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\nonefeaturereporttfidf.xml"
url04_rt="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\nonefeaturereporttfidf.xml"
url05_rt="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\nonefeaturereporttfidf.xml"
url06_rt="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\nonefeaturereporttfidf.xml"
url07_rt="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\nonefeaturereporttfidf.xml"

dom=minidom.parse(url14_rt)
root=dom.documentElement
allmanager=root.getElementsByTagName('Manager')
print('len(allmanager):{0}'.format(len(allmanager)))
report_msg_list=[[0 for number01 in range(len(reviews_list1))]for number01 in range(len(allmanager))]
reporttfidf=[]
i01=0
for a1 in allmanager:
    reporttfidf_each=[]
    i=int(a1.getAttribute("Number"))
    key1 = a1.getElementsByTagName('Key')
    #ulist=[]
    value1=a1.getElementsByTagName('Value')
    for j in range(len(key1)):
        num=int(key1[j].childNodes[0].data)
        #ulist.append([num,reviews_list1[num][1]])
        report_msg_list[i01][num]=[num,reviews_list1[num][1]]
        reporttfidf_each.append([key1[j].childNodes[0].data,value1[j].childNodes[0].data])
        #wcgresult_list[i][j]=([key1[j].childNodes[0].data,value1[j].childNodes[0].data])
        #allreport_mcg_raw[i][int(key1[j].childNodes[0].data)]=float(value1[j].childNodes[0].data)
    #report_msg_list.append(ulist)
    reporttfidf.append(reporttfidf_each)
    i01+=1
print('len(reporttfidf):{0}'.format(len(reporttfidf)))
#fnum02=open('E:\python_script\Work2\\txt\\report_msg_list.txt','w',encoding='utf-8')
#for ele in report_msg_list:
    #fnum02.write(str(ele)+'\n\n\n')
#fnum02.close()
#fnum03=open('E:\python_script\Work2\\txt\\reporttfidf.txt','w',encoding='utf-8')
#number04=0
#for ele01 in reporttfidf:
    #fnum03.write('第{0}个'.format(number04)+str(ele01)+'\n\n\n')
#    number04+=1
#fnum03.close()

#构建一个矩阵先存储每个词对应的mcg数据

url01_mcgresult='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\mcgresult_bug.xml'
url02_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\mcgresult_bug.xml"
url03_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\mcgresult_bug.xml"
url04_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\mcgresult_bug.xml"
url05_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\mcgresult_bug.xml"
url06_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\mcgresult_bug.xml"
url07_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\dict\\mcgresult_bug.xml"
url08_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\dict\\mcgresult_bug.xml"
url09_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\mcgresult_bug.xml"
url10_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\mcgresult_bug.xml"
url11_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\mcgresult_bug.xml"
url12_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\mcgresult_bug.xml"
url13_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\mcgresult_bug.xml"
url14_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\mcgresult_bug.xml"
url15_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\mcgresult_bug.xml"
url16_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\mcgresult_bug.xml"
url17_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\mcgresult_bug.xml"

url01_mcgresult='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\mcgresult_feature.xml'
url02_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\mcgresult_feature.xml"
url03_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict2\\mcgresult_feature.xml"
url04_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\mcgresult_feature.xml"
url05_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\mcgresult_feature.xml"
url06_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\mcgresult_feature.xml"
url07_mcgresult="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\mcgresult_feature.xml"

dom=minidom.parse(url14_mcgresult)
root=dom.documentElement
allmanager=root.getElementsByTagName('Manager')
nodekey1=root.getElementsByTagName('Key')
nodevalue1=root.getElementsByTagName('Value')
M=len(reviews_list1)
N=2
wcgresult_list=[[['heulaoyoutiao',0] for i in range(N)]for j in range(M)]

for a1 in allmanager:
    i=int(a1.getAttribute("Number"))

    key1 = a1.getElementsByTagName('Key')
    value1 = a1.getElementsByTagName('Value')
    for j in range(len(key1)):
        wcgresult_list[i][j]=([key1[j].childNodes[0].data,value1[j].childNodes[0].data])

wcgresult_fdlist=[]
for i in range(M):
    for j in range(N):
        wcgresult_fdlist.append(wcgresult_list[i][j][0])
wcgresult_fdlist_dict=corpora.Dictionary([wcgresult_fdlist])
wcgresult_fdlist_dictl=sorted(dict(wcgresult_fdlist_dict).items(),key=lambda item:item[0])
wcgresult_fdlist_dict=dict(wcgresult_fdlist_dict)

#--------------------------------------------------------

'''
r_m_l=[]#report的字典
for i in range(len(report_mcgresult_list)):
    report_mcgresult_fdlist = []  # 每一个report的字典
    for j in range(len(report_mcgresult_list[i])):
        for k in range(len(report_mcgresult_list[i][j])):
            report_mcgresult_fdlist.append(report_mcgresult_list[i][j][k][0])

    mcgresult_fdlist_dict=corpora.Dictionary([report_mcgresult_fdlist])
    mcgresult_fdlist_dictl=sorted(dict(mcgresult_fdlist_dict).items(),key=lambda item:item[0])
    mcgresult_fdlist_dict=dict(mcgresult_fdlist_dict)
    r_m_l.append(mcgresult_fdlist_dict)

fnum03 = open('E:\python_script\Work2\\txt\\r_m_l.txt', 'w', encoding='utf-8')
number03=0
for k in r_m_l:
    fnum03.write('第{0}个report字典：{1}\n'.format(number03,dict(k)))
    fnum03.write('\n')
    number03+=1
fnum03.close()
'''
#---------------------------------------------------------------------------------------------------------------
#扩充维数，使得每个report的（word，tfidf）对与review对应
exreporttfidf=[[0 for i in range(len(reviews_list1))]for j in range(len(reporttfidf))]
for number05 in range(len(reporttfidf)):
    for number06 in range(len(reporttfidf[number05])):
        number07=int(reporttfidf[number05][number06][0])
        exreporttfidf[number05][number07]=reporttfidf[number05][number06][1]

#---------------------------------------------------------------------------------------------------------------

'''
report_matrix=[]#所有report的过渡矩阵
for i in range(len(report_mcgresult_list)):
    nrk=len(reviews_list1)#过渡矩阵行数
    nck=len(wcgresult_fdlist_dict)#过渡矩阵列数
    kmatrix=[[0 for ki in range(nck)]for kj in range(nrk)]#每个report的过渡矩阵
    new_dict = {v:k for k,v in r_m_l[i].items()}
    for row in range(nrk):
        for col in range(2):
            wcgword=report_mcgresult_list[i][row][col][0]
            if wcgword=='heulaoyoutiao':
                continue
            else:
                value_k=new_dict.get(wcgword)
                kmatrix[row][value_k]=report_mcgresult_list[i][row][col][1]
    report_matrix.append(kmatrix)
fnum04 = open('E:\python_script\Work2\\txt\\report_matrix.txt', 'w', encoding='utf-8')
number03=0
for k in r_m_l:
    fnum04.write('第{0}个report矩阵：{1}\n'.format(number03,dict(k)))
    fnum04.write('\n')
    number03+=1
fnum04.close()
'''
#建立过渡矩阵
nrk=len(reviews_list1)#过渡矩阵行数
print('nrk:{0}'.format(nrk))
nck=len(wcgresult_fdlist_dict)#过渡矩阵列数
print('nck:{0}'.format(nck))
kmatrix=[[0 for ki in range(nck)]for kj in range(nrk)]
new_dict = {v:k for k,v in wcgresult_fdlist_dict.items()}
for row in range(nrk):
    for col in range(N):
        wcgword=wcgresult_list[row][col][0]
        if wcgword=='heulaoyoutiao':
            continue
        else:
            value_k=new_dict.get(wcgword)
            kmatrix[row][value_k]=wcgresult_list[row][col][1]

#计算出被mcg的过渡矩阵处理的review向量
url01="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\allbugreportfidf.xml"
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\allbugreportfidf.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\allbugreportfidf.xml"
url04="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\allbugreportfidf.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\allbugreportfidf.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\allbugreportfidf.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\allbugreportfidf.xml"
url08="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\allbugreportfidf.xml"
url09="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\allbugreportfidf.xml"
url10="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\allbugreportfidf.xml"
url11="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\allbugreportfidf.xml"
url12="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\allbugreportfidf.xml"
url13="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\allbugreportfidf.xml"
url14="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\allbugreportfidf.xml"
url15="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\allbugreportfidf.xml"
url16="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\allbugreportfidf.xml"
url17="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\allbugreportfidf.xml"

url01="E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\allfeaturereportfidf.xml"
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\allfeaturereportfidf.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\allfeaturereportfidf.xml"
url04="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\allfeaturereportfidf.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\allfeaturereportfidf.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\allfeaturereportfidf.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\allfeaturereportfidf.xml"

dom=minidom.parse(url14)
root=dom.documentElement
allmanager=root.getElementsByTagName('Manager')
nodekey1=root.getElementsByTagName('Key')
nodevalue1=root.getElementsByTagName('Value')
print(len(allmanager))
review_mcg_raw=[]
i=0
for a1 in allmanager:
    review_mcg_raw.append(float(nodevalue1[i].firstChild.data))
    i+=1
print(review_mcg_raw)
print(len(review_mcg_raw))
review_mcg_raw=np.array(review_mcg_raw,dtype=float)
kmatrix=np.array(kmatrix,dtype=float)
print(len(review_mcg_raw))
review_mcg = np.dot(review_mcg_raw, kmatrix)
#f007=open('E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\corpus_mcg.txt','w',encoding='utf-8')
#f007.write(str(review_mcg)+'\n')
#f007.write(str(len(review_mcg)))
#f007.close()
print(review_mcg)
print(len(review_mcg))


'''
dom=minidom.parse("E:\python_script\Work2\\reporttfidf.xml")
root=dom.documentElement
allmanager=root.getElementsByTagName('Manager')

#report_mcg_raw=[[0 for j in range(len(nodekey1))]for i in range(len(allmanager))]
allreport_mcg_raw=[]
number02=0
for a1 in allmanager:
    key1 = a1.getElementsByTagName('Key')
    value1 = a1.getElementsByTagName('Value')
    report_mcg_raw = [0 for j in range(len(reviews_list1))]

    for j in range(len(key1)):
        report_mcg_raw[int(key1[j].childNodes[0].data)]=float(value1[j].childNodes[0].data)

    allreport_mcg_raw.append(report_mcg_raw)

'''
#计算出被mcg的过渡矩阵处理的report向量
all_report_mcg=[]
for i in range(len(reporttfidf)):
    exreporttfidf[i]=np.array(exreporttfidf[i],dtype=float)

    report_mcg = np.dot(exreporttfidf[i], kmatrix)
    all_report_mcg.append(report_mcg)
#fnum05=open('E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\all_query_mcg.txt','w',encoding='utf-8')
#number09=0
#for number08 in all_report_mcg:
#    fnum05.write('第{0}个report的mcg向量:{1}\n\n\n'.format(number09,number08))
#    fnum05.write('第{0}个report的mcg向量长度{1}\n\n\n'.format(number09,len(number08)))
#    number09+=1
#fnum05.close()
#计算相似度
'''
f01=open('E:\python_script\Work2\\similarmcg.txt','w',encoding='utf-8')

f008=open('E:\python_script\Work2\\txt\mcg_cal\\neiji.txt','w',encoding='utf-8')
f009=open('E:\python_script\Work2\\txt\mcg_cal\\report_mo.txt','w',encoding='utf-8')
f010=open('E:\python_script\Work2\\txt\mcg_cal\\review_mo.txt','w',encoding='utf-8')
'''
count001=0
listmcg=[]
print('len(all_report_mcg):{0}'.format(len(all_report_mcg)))
for i in range(len(all_report_mcg)):
    #print(Work2.Similar1.similar_MCG(allreport_mcg_raw[i],review_mcg))
    #print('len all report mcg i ',len(all_report_mcg[i]))
    #sim = Work2.Similar1.similar_MCG(all_report_mcg[i], review_mcg)
#----------------------------------------------------------------------------------
    x = 0
    i1 = 0
    while i1 < len(review_mcg):
        x = x + all_report_mcg[i][i1] * review_mcg[i1]
        i1 = i1 + 1
    #f008.write('第{0}个report与review的内积：{1}'.format(i,x)+'\n\n')

    # 计算两个向量的模
    i1 = 0
    sq1 = 0
    while i1 < len(review_mcg):
        sq1 = sq1 + all_report_mcg[i][i1] * all_report_mcg[i][i1]  # pow(a,2)
        i1 = i1 + 1
    #f009.write('第{0}个report向量的模：{1}'.format(i,sq1)+'\n\n')

    i1 = 0
    sq2 = 0
    while i1< len(review_mcg):
        sq2 = sq2 + review_mcg[i1] * review_mcg[i1]
        i1 = i1 + 1
    #f010.write('review的模：{0}'.format(sq2)+'\n\n')
    # print(sq2)
    if sq1!=0 and sq2!=0:
        sim = float(x) / (math.sqrt(sq1) * math.sqrt(sq2))
    else:
        sim=0
    listmcg.append(sim)

url01='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_mcg_bug.xml'
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s2_mcg_bug.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s2_mcg_bug.xml"
url04="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s2_mcg_bug.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s2_mcg_bug.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s2_mcg_bug.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s2_mcg_bug.xml"
url08="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\s2_mcg_bug.xml"
url09="E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\s2_mcg_bug.xml"
url10="E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\s2_mcg_bug.xml"
url11="E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\s2_mcg_bug.xml"
url12="E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\s2_mcg_bug.xml"
url13="E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\s2_mcg_bug.xml"
url14="E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\s2_mcg_bug.xml"
url15="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\s2_mcg_bug.xml"
url16="E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\s2_mcg_bug.xml"
url17="E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\s2_mcg_bug.xml"

url01='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_mcg_feature.xml'
url02="E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s2_mcg_feature.xml"
url03="E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s2_mcg_feature.xml"
url04="E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s2_mcg_feature.xml"
url05="E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s2_mcg_feature.xml"
url06="E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s2_mcg_feature.xml"
url07="E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s2_mcg_feature.xml"

work_jcst.write_xml.write_xml2(listmcg,url14)

