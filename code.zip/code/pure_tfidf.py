from xml.dom import minidom
import nltk
from collections import defaultdict
from nltk.stem.porter import PorterStemmer
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
from gensim import corpora,models,similarities
from work_jcst import readReport
import work_jcst.write_xml
#读取的report路径
url01_bug='E:\python_script\work_jcst\\bugReport\\bugReport_bug\\AnimeNeko_Atarashii.xml'
url01_none='E:\python_script\work_jcst\\bugReport\\bugReport_none\\AnimeNeko_Atarashii.xml'
url01_feature='E:\python_script\work_jcst\\bugReport\\bugReport_feature\\AnimeNeko_Atarashii.xml'

url01_irrfeature='E:\python_script\work_jcst\\bugReport\\bugReport_irr\\forFeature\\AnimeNeko_Atarashii.xml'
#变量结果写入文本文档
urlrt01_feature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_feature.txt'
urlrt01_none='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_none.txt'
urlrt01_bug='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_bug.txt'

urlrt01_irrfeature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_irrfeature.txt'

bug_reports_feature=readReport.readReport(url01_feature)
bug_reports_none=readReport.readReport(url01_none)
bug_reports_bug=readReport.readReport(url01_bug)
bug_reports_irrfeature=readReport.readReport(url01_irrfeature)
#预处理：句子拆成词，词干化，去除停止词等
wordEngStop = nltk.corpus.stopwords.words('english')
english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '!', '@', '#', '%', '$', '*','=','abstract=', '{', '}','\'','\"','\\']
pattern=r"""(?x)                   # set flag to allow verbose regexps
              (?:[A-Z]\.)+           # abbreviations, e.g. U.S.A.
              |\d+(?:\.\d+)?%?       # numbers, incl. currency and percentages
              |\w+(?:[-']\w+)*       # words w/ optional internal hyphens/apostrophe
              |\.\.\.                # ellipsis
              |(?:[.,;"'?():-_`])    # special characters with meanings
            """
porter_stemmer = PorterStemmer()
#-------------------------------------------------------------------------------------------
#尚未标签的
texts_bug_reports_none_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_none]
texts_bug_reports_none_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                     if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_none]
#标签为feature
texts_bug_reports_feature_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_feature]
texts_bug_reports_feature_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                     if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_feature]

#标签为bug
texts_bug_reports_bug_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_bug]
texts_bug_reports_bug_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                     if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_bug]

texts_bug_reports_irrfeature_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_irrfeature]
texts_bug_reports_irrfeature_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                     if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_irrfeature]

#-------------------------------------------------------------------------------------------
bug_reports_none_processed=[[0,0,0]for number01 in range(len(bug_reports_none))]
bug_reports_bug_processed=[[0,0,0]for number01 in range(len(bug_reports_bug))]
bug_reports_feature_processed=[[0,0,0]for number01 in range(len(bug_reports_feature))]
bug_reports_irrfeature_processed=[[0,0,0]for number01 in range(len(bug_reports_irrfeature))]

num_brn=0
for document in bug_reports_none:
    bug_reports_none_processed[num_brn][0]=num_brn
    bug_reports_none_processed[num_brn][1]=texts_bug_reports_none_summary[num_brn]
    bug_reports_none_processed[num_brn][2] = texts_bug_reports_none_description[num_brn]
    num_brn+=1
print("bug_reports_none_processed:{0}".format(bug_reports_none_processed))
url01_bug_reports_none_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_none_processed.xml'
work_jcst.write_xml.write_xml4(bug_reports_none_processed,url01_bug_reports_none_processed)

num_brb=0
for document in bug_reports_bug:
    bug_reports_bug_processed[num_brb][0]=num_brb
    bug_reports_bug_processed[num_brb][1]=texts_bug_reports_bug_summary[num_brb]
    bug_reports_bug_processed[num_brb][2] = texts_bug_reports_bug_description[num_brb]
    num_brb+=1
print("bug_reports_bug_processed:{0}".format(bug_reports_bug_processed))
url01_bug_reports_bug_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_bug_processed.xml'
work_jcst.write_xml.write_xml4(bug_reports_bug_processed,url01_bug_reports_bug_processed)

num_brf=0
for document in bug_reports_feature:
    bug_reports_feature_processed[num_brf][0]=num_brf
    bug_reports_feature_processed[num_brf][1]=texts_bug_reports_feature_summary[num_brf]
    bug_reports_feature_processed[num_brf][2] = texts_bug_reports_feature_description[num_brf]
    num_brf+=1
print("bug_reports_feature_processed:{0}".format(bug_reports_feature_processed))
url01_bug_reports_feature_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_feature_processed.xml'
work_jcst.write_xml.write_xml4(bug_reports_feature_processed,url01_bug_reports_feature_processed)

num_brif=0
for document in bug_reports_irrfeature:
    bug_reports_irrfeature_processed[num_brif][0]=num_brif
    bug_reports_irrfeature_processed[num_brif][1]=texts_bug_reports_irrfeature_summary[num_brif]
    bug_reports_irrfeature_processed[num_brif][2] = texts_bug_reports_irrfeature_description[num_brif]
    num_brif+=1
print("bug_reports_feature_processed:{0}".format(bug_reports_irrfeature_processed))
url01_bug_reports_irrfeature_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_irrfeature_processed.xml'
work_jcst.write_xml.write_xml4(bug_reports_irrfeature_processed,url01_bug_reports_irrfeature_processed)

#-------------------------------------------------------------------------------------------
#frequency_summary = defaultdict(int)
#去掉discription中的词频低于1的词
frequency_none_description = defaultdict(int)
for text in bug_reports_none_processed:
    #for token_summary in text[1]:
    #   frequency_summary[token_summary] += 1
    for token_description in text[2]:
        frequency_none_description[token_description]+=1
#texts_summary=[[token for token in text[1] if frequency_summary[token] > 1]
#         for text in bug_reports_none_processed]
#print(texts_summary)

texts_none_description=[[token for token in text[2] if frequency_none_description[token] > 1]
         for text in bug_reports_none_processed]
print('texts_none_description:{0}'.format(texts_none_description))
#-----------------------------------------------
frequency_feature_description = defaultdict(int)
for text in bug_reports_feature_processed:
    #for token_summary in text[1]:
    #   frequency_summary[token_summary] += 1
    for token_description in text[2]:
        frequency_feature_description[token_description]+=1
#texts_summary=[[token for token in text[1] if frequency_summary[token] > 1]
#         for text in bug_reports_none_processed]
#print(texts_summary)

texts_feature_description=[[token for token in text[2] if frequency_feature_description[token] > 1]
         for text in bug_reports_feature_processed]
print('texts_feature_description:{0}'.format(texts_feature_description))
#-----------------------------------------------
frequency_bug_description = defaultdict(int)
for text in bug_reports_bug_processed:

    for token_description in text[2]:
        frequency_bug_description[token_description]+=1

texts_bug_description=[[token for token in text[2] if frequency_bug_description[token] > 1]
         for text in bug_reports_bug_processed]
print('texts_bug_description:{0}'.format(texts_bug_description))
#-----------------------------------------------
frequency_irrfeature_description = defaultdict(int)
for text in bug_reports_irrfeature_processed:

    for token_description in text[2]:
        frequency_irrfeature_description[token_description]+=1

texts_irrfeature_description=[[token for token in text[2] if frequency_irrfeature_description[token] > 1]
         for text in bug_reports_irrfeature_processed]
print('texts_irrfeature_description:{0}'.format(texts_irrfeature_description))

#---------------------------------------------------------------------------------------------------------------------
#[[序号,[词，词，...],[],...]]
textualIndexReport_none=[[0]for i in range(len(bug_reports_none_processed))]
numberIntegrate=0
for processedReport in bug_reports_none_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_none_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_none[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_none:{0}'.format(textualIndexReport_none))
print(len(textualIndexReport_none))
print(textualIndexReport_none[0][2])
url_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
work_jcst.write_xml.write_xml3(textualIndexReport_none,url_textualIndexReport_none)
#texts = [[token for token in text if frequency[token] > 1]
#         for text in texts]
#-------------------------------------------------------------------------
textualIndexReport_feature=[[0]for i in range(len(bug_reports_feature_processed))]
numberIntegrate=0
for processedReport in bug_reports_feature_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_feature_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_feature[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_feature:{0}'.format(textualIndexReport_feature))
print(len(textualIndexReport_feature))
url_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_feature.xml'
work_jcst.write_xml.write_xml3(textualIndexReport_feature,url_textualIndexReport_feature)
#-------------------------------------------------------------------------
textualIndexReport_bug=[[0]for i in range(len(bug_reports_bug_processed))]
numberIntegrate=0
for processedReport in bug_reports_bug_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_bug_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_bug[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_bug:{0}'.format(textualIndexReport_bug))
print(len(textualIndexReport_bug))
url_textualIndexReport_bug='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_bug.xml'
work_jcst.write_xml.write_xml3(textualIndexReport_bug,url_textualIndexReport_bug)
#-------------------------------------------------------------------------
textualIndexReport_irrfeature=[[0]for i in range(len(bug_reports_irrfeature_processed))]
numberIntegrate=0
for processedReport in bug_reports_irrfeature_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_irrfeature_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_irrfeature[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_irrfeature:{0}'.format(textualIndexReport_irrfeature))
print(len(textualIndexReport_irrfeature))
url_textualIndexReport_irrfeature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_irrfeature.xml'
work_jcst.write_xml.write_xml3(textualIndexReport_irrfeature,url_textualIndexReport_irrfeature)

#---------------------------------------------------------------------------------------------------------------------
dictionary=corpora.Dictionary(textualIndexReport_feature)
print(dictionary.token2id)
#feature_vec=dictionary.doc2bow(new_doc.lower().split())
corpus=[dictionary.doc2bow(text)for text in textualIndexReport_feature]
print('corpurs:{0}'.format(corpus))
tfidf=models.TfidfModel(corpus)
corpus_tfidf=tfidf[corpus]
for doc in corpus_tfidf:
	    print(doc)

index = similarities.MatrixSimilarity(corpus_tfidf)
query_bows = [dictionary.doc2bow(text) for text in textualIndexReport_none]

f4=open('E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_feature_none_similar01.txt','w',encoding='utf-8')

s2=[]
for i in range(len(query_bows)):
    query_tfidf = tfidf[query_bows[i]]
    sims = index[query_tfidf]
    s2_tfidf =0
    print('sims{0}'.format(sims))
    for num_sim in sims:
        s2_tfidf+=num_sim
    s2_tfidf/=len(sims)
    s2.append(s2_tfidf)
    sort_sims = sorted(enumerate(sims), key=lambda item: -item[1])
    print('sortsims{0}'.format(sort_sims))
    str4=''
    str4+="第{0}个标签为none的bugReport的结果: [S2:{1}]  ".format(i,s2_tfidf)

    for j in range(10):
        str4+=str(sort_sims[j])+' '
    str4+='\n'
    f4.write(str4)
f4.close()
print(s2)
print(len(s2))
url_feature_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_feature_none_similar.xml'
work_jcst.write_xml.write_xml2(s2,url_feature_none_sim)
#------------------------------------------------------------------------------------------
dictionary1=corpora.Dictionary(textualIndexReport_bug)
print(dictionary1.token2id)
#feature_vec=dictionary.doc2bow(new_doc.lower().split())
corpus1=[dictionary1.doc2bow(text)for text in textualIndexReport_bug]
print('corpurs1:{0}'.format(corpus1))
tfidf1=models.TfidfModel(corpus1)
corpus_tfidf1=tfidf1[corpus1]
for doc in corpus_tfidf1:
	print(doc)

index1 = similarities.MatrixSimilarity(corpus_tfidf1)
query_bows1 = [dictionary1.doc2bow(text) for text in textualIndexReport_none]

f4=open('E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bug_none_similar01.txt','w',encoding='utf-8')

s02=[]
for i in range(len(query_bows1)):
    query_tfidf1 = tfidf1[query_bows1[i]]
    sims1 = index1[query_tfidf1]
    s02_tfidf1 =0
    print('sims1{0}'.format(sims1))
    for num_sim1 in sims1:
        s02_tfidf1+=num_sim1
    s02_tfidf1/=len(sims1)
    s02.append(s02_tfidf1)
    sort_sims1 = sorted(enumerate(sims1), key=lambda item: -item[1])
    print('sortsims1{0}'.format(sort_sims1))
    str4=''
    str4+="第{0}个标签为none的bugReport的结果: [S2:{1}]  ".format(i,s02_tfidf1)

    for j in range(10):
        str4+=str(sort_sims1[j])+' '
    str4+='\n'
    f4.write(str4)
f4.close()
print(s02)
print(len(s02))
url_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bug_none_similar.xml'
work_jcst.write_xml.write_xml2(s02,url_bug_none_sim)
