#读取缺陷报告的summary,description
from xml.dom import minidom
import work_jcst.write_xml
#参数是两个文件路径，第一个是读取的文件，第二个是变量的写入路径。
def readReport(url01):
    dom=minidom.parse(url01)
    root1=dom.documentElement
    bugReports=root1.getElementsByTagName('description')
    aa=root1.getElementsByTagName('label')
    nodeSummary=root1.getElementsByTagName('summary')
    bug_reports=[]


    for i in range(len(aa)):
        bug_reports.append([i,nodeSummary[i].firstChild.data,bugReports[i].firstChild.data])

    return bug_reports

def readReport_none(url):
    list=[]
    dom = minidom.parse(url)
    root1 = dom.documentElement
    managers = root1.getElementsByTagName('Manager')
    num01=0
    for manager in managers:
        reportnodes=manager.getElementsByTagName('report')
        num02=0
        list2=[]
        for reportnode in reportnodes:
            list2.append(reportnode.firstChild.data)
            num02+=1
        list.append(list2)
        num01+=1
    return list

def readReport_none01(url):
    list=[]
    dom = minidom.parse(url)
    root1 = dom.documentElement
    managers = root1.getElementsByTagName('Manager')
    num01=0
    for manager in managers:
        reportnodes=manager.getElementsByTagName('report')
        num02=0

        for reportnode in reportnodes:
            list.append(reportnode.firstChild.data)
            num02+=1
        num01+=1
    return list


def readS(url):
    list=[]
    dom=minidom.parse(url)
    root1=dom.documentElement
    values=root1.getElementsByTagName('Value')
    for value in values:
        list.append(float(value.firstChild.data))
    return list
#url是surfreview链接，n是review数量
def read_bug_SURF(url,n,s):
    dom = minidom.parse(url)
    root = dom.documentElement
    # print(root.nodeName)
    sentence_types = root.getElementsByTagName('sentence_type')
    sentence_texts = root.getElementsByTagName('sentence_text')
    reviewNumber = root.getElementsByTagName('from_review')
    i = 0
    reviews = [0 for num01 in range(n)]
    for sentence_type in sentence_types:
        a = sentence_types[i].firstChild.data
        reviewNum = int(reviewNumber[i].firstChild.data)
        if a == s:
            reviews[reviewNum] = sentence_texts[i].firstChild.data
        i += 1

    pro_reviews = []
    for review in reviews:
        if review == 0:
            continue
        else:
            pro_reviews.append(review)
    return pro_reviews

def readSurfVecb(url):
    dom = minidom.parse(url)
    root = dom.documentElement
    # print(root.nodeName)
    sentence_types = root.getElementsByTagName('sentence_type')
    sentence_texts = root.getElementsByTagName('sentence_text')
    reviewNumber = root.getElementsByTagName('from_review')
    allreviews = root.getElementsByTagName('review')
    vec=[0 for i in range(len(allreviews))]
    for i,sentence_type in enumerate(sentence_types):
        a = sentence_type.firstChild.data
        reviewNum = int(reviewNumber[i].firstChild.data)
        if a == 'BUG':
            vec[reviewNum]=2
        elif a=='REQUEST':
            vec[reviewNum]=1
    return vec

def readSurfVecb3(url1,url2,url3):
    list=[]
    list.extend(readSurfVecb(url1))
    list.extend(readSurfVecb(url2))
    list.extend(readSurfVecb(url3))
    return list


def readSurfVecf(url):
    dom = minidom.parse(url)
    root = dom.documentElement
    # print(root.nodeName)
    sentence_types = root.getElementsByTagName('sentence_type')
    sentence_texts = root.getElementsByTagName('sentence_text')
    reviewNumber = root.getElementsByTagName('from_review')
    allreviews = root.getElementsByTagName('review')
    vec=[0 for i in range(len(allreviews))]
    for i,sentence_type in enumerate(sentence_types):
        a = sentence_type.firstChild.data
        reviewNum = int(reviewNumber[i].firstChild.data)
        if a == 'BUG':
            vec[reviewNum]=1

    return vec
def read_kind_SURF(url):
    dom = minidom.parse(url)
    root = dom.documentElement
    # print(root.nodeName)
    sentence_types = root.getElementsByTagName('sentence_type')
    sentence_texts = root.getElementsByTagName('sentence_text')
    reviewNumber = root.getElementsByTagName('from_review')


    l_b=[]
    l_f=[]
    i = 0
    for sentence_type in sentence_types:
        a = sentence_types[i].firstChild.data
        reviewNum = int(reviewNumber[i].firstChild.data)
        if a == 'BUG':
            l_b.append(reviewNum)
        if a=='REQUEST':
            l_f.append(reviewNum)
        i += 1
    l_b=list(set(l_b))
    l_f=list(set(l_f))
    numend=[l_b,l_f]
    return numend

def read_3kind_SURF(url1,url2,url3):
    numend1=read_kind_SURF(url1)
    numend2 = read_kind_SURF(url2)
    numend3 = read_kind_SURF(url3)
    l_b1=numend1[0]
    l_f1=numend1[1]
    l_b2 = numend2[0]
    l_f2 = numend2[1]
    l_b3 = numend3[0]
    l_f3 = numend3[1]
    for i in range(len(l_b2)):
        l_b2[i]+=1104
    for i in range(len(l_f2)):
        l_f2[i]+=1104
    for i in range(len(l_b3)):
        l_b3[i] += 2202
    for i in range(len(l_f3)):
        l_f3[i]+=2202
    l_b=l_b1+l_b2+l_b3
    l_f=l_f1+l_f2+l_f3
    return [l_b,l_f]

def read_rfp(url):
    list=[]
    dom = minidom.parse(url)
    root = dom.documentElement
    reports=root.getElementsByTagName('report')
    nodesummary = root.getElementsByTagName('summary')
    nodedescription = root.getElementsByTagName('description')
    for i in range(len(nodesummary)):
        list1=[]
        list2=[]
        tokens1=nodesummary[i].getElementsByTagName('token')
        tokens2=nodedescription[i].getElementsByTagName('token')
        for j in range(len(tokens1)):
            list1.append(tokens1[j].firstChild.data)
        for p in range(len(tokens2)):
            list2.append(tokens2[p].firstChild.data)
        list.append([list1,list2])
    return list

def readS1(url):
    list=[]
    dom=minidom.parse(url)
    root1=dom.documentElement
    managers=root1.getElementsByTagName('Manager')
    for manager in managers:
        keys=manager.getElementsByTagName('Key')
        values=manager.getElementsByTagName('Value')
        num=0
        list1=[]
        for key in keys:
            list1.append([key.firstChild.data,values[num].firstChild.data])

            num+=1
        list.append(list1)
    return list

if __name__=='__main__':
    url03_mcgresult2 = "E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\mcgresult_bug2.xml"
    list=readS1(url03_mcgresult2)
    print(list)
    print(len(list))
    url03_mcgresult21 = "E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\dict\\mcgresult_bug21.xml"
    work_jcst.write_xml.write_xmls1(list,url03_mcgresult21)