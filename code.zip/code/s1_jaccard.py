
import nltk
from collections import defaultdict
from nltk.stem.porter import PorterStemmer
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
from gensim import corpora,models,similarities
from xml.dom import minidom
import work_jcst.write_xml
#读取textualIndexReport_none
import work_jcst.readReport
'''
url_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
textualIndexReport_none=work_jcst.readReport.readReport_none(url_textualIndexReport_none)
print(textualIndexReport_none)


#处理reviews
urlreview01='E:\python_script\work_jcst\\reviews\\AnimeNeko_Atarashii.xml'
dom=minidom.parse(urlreview01)
root=dom.documentElement
#print(root.nodeName)
sentence_types=root.getElementsByTagName('sentence_type')
sentence_texts=root.getElementsByTagName('sentence_text')
reviewNumber=root.getElementsByTagName('from_review')
i=0
reviews=[0 for num01 in range(404)]
for sentence_type in sentence_types:
    a=sentence_types[i].firstChild.data
    reviewNum=int(reviewNumber[i].firstChild.data)
    if a == 'BUG':
        reviews[reviewNum]=sentence_texts[i].firstChild.data
    i+=1

pro_reviews=[]
for review in reviews:
    if review==0:
        continue
    else:
        pro_reviews.append(review)
print(reviews)
print(len(reviews))
print(pro_reviews)
print(len(pro_reviews))

i=0
f1=open('E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\reviews_bug.txt','w',encoding='utf-8')
for sentence in pro_reviews:
    f1.write("{0}:{1}".format(i, sentence+'\n'))
    i+=1
f1.close()

#预处理：句子拆成词，词干化，去除停止词等
wordEngStop = nltk.corpus.stopwords.words('english')
english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '!', '@', '#', '%', '$', '*','=','abstract=', '{', '}','\'','\"','\\']
pattern=r"""(?x)                   # set flag to allow verbose regexps
              (?:[A-Z]\.)+           # abbreviations, e.g. U.S.A.
              |\d+(?:\.\d+)?%?       # numbers, incl. currency and percentages
              |\w+(?:[-']\w+)*       # words w/ optional internal hyphens/apostrophe
              |\.\.\.                # ellipsis
              |(?:[.,;"'?():-_`])    # special characters with meanings
            """
porter_stemmer = PorterStemmer()

texts=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document.lower(), pattern)
        if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in pro_reviews]

frequency = defaultdict(int)
for text in texts:
    for token in text:
        frequency[token] += 1
texts = [[token for token in text if frequency[token] > 1]
         for text in texts]
f6=open('E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\Filted_bug_reviews.txt','w',encoding='utf-8')
for m1 in range(len(texts)):
    f6.write(str(m1)+str(texts[m1])+"\n")
f6.close()

reviewMerge=[]
for text in texts:
    for token in text:
        reviewMerge.append(token)
print(reviewMerge)

dictionary=corpora.Dictionary(texts)
corpus=[dictionary.doc2bow(text)for text in texts]

reviewMerge_vec=dictionary.doc2bow(reviewMerge)
print(reviewMerge_vec)

query_bows = [dictionary.doc2bow(text) for text in textualIndexReport_none]
print(query_bows)

s1_bug_review=[]
for query_bow in query_bows:
    n_report = 0
    sum_up = 0
    sum_down = 0
    for t in query_bow:
        n_report+=t[1]
        if reviewMerge_vec[t[0]][1]>=t[1]:
            sum_up+=t[1]
        else:
            sum_up+=reviewMerge_vec[t[0]][1]
    sum_down+=n_report+len(reviewMerge)
    s1_bug_review.append(sum_up/sum_down)
print(len(s1_bug_review))
print(s1_bug_review)
url_bug_review='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s1_bug_review.xml'
work_jcst.write_xml.write_xml2(s1_bug_review,url_bug_review)
'''
#url1是reports,url2是SURF后的review,url3 reviews_bug.txt ,url4 Filted_bug_reviews, url5 写入s1_bug_review
def c_jaccard(url1,url2,url5,url0):
    reports = work_jcst.readReport.readReport_none(url1)
    reviews=work_jcst.readReport.read_bug_SURF(url2,4466,'REQUEST')
    i = 0

    wordEngStop = nltk.corpus.stopwords.words('english')
    english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '!', '@', '#', '%', '$', '*', '=', 'abstract=',
                            '{', '}', '\'', '\"', '\\']
    pattern = r"""(?x)                   # set flag to allow verbose regexps
                  (?:[A-Z]\.)+           # abbreviations, e.g. U.S.A.
                  |\d+(?:\.\d+)?%?       # numbers, incl. currency and percentages
                  |\w+(?:[-']\w+)*       # words w/ optional internal hyphens/apostrophe
                  |\.\.\.                # ellipsis
                  |(?:[.,;"'?():-_`])    # special characters with meanings
                """
    porter_stemmer = PorterStemmer()
    texts = [[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document.lower(), pattern)
              if word not in wordEngStop + english_punctuations and word.isdigit() == False and '.' not in word and len(
            word) > 1] for document in reviews]
    frequency = defaultdict(int)
    for text in texts:
        for token in text:
            frequency[token] += 1
    texts = [[token for token in text if frequency[token] > 1]
             for text in texts]

    work_jcst.write_xml.write_xml3(texts,url0)

    reviewMerge = []
    for text in texts:
        for token in text:
            reviewMerge.append(token)
    dictionary = corpora.Dictionary(texts)
    reviewMerge_vec = dictionary.doc2bow(reviewMerge)
    query_bows = [dictionary.doc2bow(text) for text in reports]
    s1_bug_review = []
    for query_bow in query_bows:
        n_report = 0
        sum_up = 0
        sum_down = 0
        for t in query_bow:
            n_report += t[1]
            if reviewMerge_vec[t[0]][1] >= t[1]:
                sum_up += t[1]
            else:
                sum_up += reviewMerge_vec[t[0]][1]
        sum_down += n_report + len(reviewMerge)
        s1_bug_review.append(sum_up / sum_down)
    work_jcst.write_xml.write_xml2(s1_bug_review, url5)
    return s1_bug_review

url1='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\textualIndexReport_none.xml'
url2='E:\python_script\work_jcst\\reviews\\review_seke\\cgeo_cgeo.xml'


url5='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s1_bug_review.xml'
url9='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_bug_reviews.xml'


url8='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s1_feature_review.xml'
url10='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_feature_reviews.xml'

print(c_jaccard(url1,url2,url8,url10))
