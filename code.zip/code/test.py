from xml.dom import minidom
import nltk
from collections import defaultdict
from nltk.stem.porter import PorterStemmer
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
from gensim import corpora,models,similarities
from work_jcst import readReport
import work_jcst.write_xml
wordEngStop = nltk.corpus.stopwords.words('english')
english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '!', '@', '#', '%', '$', '*','=','abstract=', '{', '}','\'','\"','\\']
pattern=r"""(?x)                   # set flag to allow verbose regexps
              (?:[A-Z]\.)+           # abbreviations, e.g. U.S.A.
              |\d+(?:\.\d+)?%?       # numbers, incl. currency and percentages
              |\w+(?:[-']\w+)*       # words w/ optional internal hyphens/apostrophe
              |\.\.\.                # ellipsis
              |(?:[.,;"'?():-_`])    # special characters with meanings
              
            """
porter_stemmer = PorterStemmer()
documents = ["Human e z machine 3333334 interface for safd333 27.5 lab abc computer applications 314",
"A survey of user opinion of computer system response time",
"The EPS user interface management system",
"System and human system engineering testing of EPS",
"Relation of user perceived response time to error measurement",
"The generation of random binary unordered trees",
"The intersection graph of paths in trees",
"Graph minors IV Widths of trees and well quasi ordering",
"Graph minors A survey"]
texts_bug_reports_none_description1=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document.lower(), pattern)
                                     if word not in wordEngStop+english_punctuations ]for document in documents]

print(texts_bug_reports_none_description1)
texts_bug_reports_none_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document.lower(), pattern)
                                     if word not in wordEngStop+english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in documents]
print(texts_bug_reports_none_description)

import re

def isnumber(num):

    regex01 = re.compile(r"^(-?\d+)(\.\d*)?$")

    if re.match(regex01,num):

        return True

    else:

        return False

num01=27.5