from numpy import *
import numpy as np
from sklearn.linear_model import LogisticRegression

urltestRealSet01='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\testRealSet.npy'
urllabelSet01='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\labelSet.npy'
urltestSet01='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\testSet.npy'
urltrainSet01='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\trainSet.npy'

urltestRealSet02='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\testRealSet.npy'
urllabelSet02='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\labelSet.npy'
urltestSet02='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\testSet.npy'
urltrainSet02='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\trainSet.npy'

urltestRealSet03='F:\python_script\work_jcst\compare\cgeo_cgeo\\testRealSet.npy'
urllabelSet03='F:\python_script\work_jcst\compare\cgeo_cgeo\\labelSet.npy'
urltestSet03='F:\python_script\work_jcst\compare\cgeo_cgeo\\testSet.npy'
urltrainSet03='F:\python_script\work_jcst\compare\cgeo_cgeo\\trainSet.npy'

urltestSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\testSet.npy"
urltrainSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\trainSet.npy"
urllabelSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\labelSet.npy"
urltestRealSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\testRealSet.npy"

urltestSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\testSet.npy"
urltrainSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\trainSet.npy"
urllabelSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\labelSet.npy"
urltestRealSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\testRealSet.npy"

urltestSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\testSet.npy"
urltrainSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\trainSet.npy"
urllabelSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\labelSet.npy"
urltestRealSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\testRealSet.npy"

urltestSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\testSet.npy"
urltrainSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\trainSet.npy"
urllabelSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\labelSet.npy"
urltestRealSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\testRealSet.npy"

urltestSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\testSet.npy"
urltrainSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\trainSet.npy"
urllabelSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\labelSet.npy"
urltestRealSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\testRealSet.npy"

urltestSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\testSet.npy"
urltrainSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\trainSet.npy"
urllabelSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\labelSet.npy"
urltestRealSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\testRealSet.npy"

urltestSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\testSet.npy"
urltrainSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\trainSet.npy"
urllabelSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\labelSet.npy"
urltestRealSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\testRealSet.npy"

urltestSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\testSet.npy"
urltrainSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\trainSet.npy"
urllabelSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\labelSet.npy"
urltestRealSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\testRealSet.npy"

urltestSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\testSet.npy"
urltrainSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\trainSet.npy"
urllabelSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\labelSet.npy"
urltestRealSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\testRealSet.npy"

urltestSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\testSet.npy"
urltrainSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\trainSet.npy"
urllabelSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\labelSet.npy"
urltestRealSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\testRealSet.npy"

urltestSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\testSet.npy"
urltrainSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\trainSet.npy"
urllabelSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\labelSet.npy"
urltestRealSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\testRealSet.npy"

urltestSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\testSet.npy"
urltrainSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\trainSet.npy"
urllabelSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\labelSet.npy"
urltestRealSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\testRealSet.npy"

urltestSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\testSet.npy"
urltrainSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\trainSet.npy"
urllabelSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\labelSet.npy"
urltestRealSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\testRealSet.npy"

urltestSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\testSet.npy"
urltrainSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\trainSet.npy"
urllabelSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\labelSet.npy"
urltestRealSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\testRealSet.npy"

testRealSet=np.load(urltestRealSet03)
labelSet=np.load(urllabelSet03)
testSet=np.load(urltestSet03)
trainSet=np.load(urltrainSet03)

print(testRealSet)
print(labelSet)
print(testSet)
print(trainSet)


trainX = trainSet
trainY = labelSet

print('trainX:iris.data: {0}, type:{1}, size{2} '.format(trainX,type(trainX),len(trainX)))
print('trainY:iris.target: {0}, type:{1}, size{2}'.format(trainY,type(trainY),len(trainY)))
clf = LogisticRegression(penalty='l2', dual=False, tol=1e-4, C=1,
                         fit_intercept=True, intercept_scaling=1, class_weight=None,
                         random_state=None, solver='sag', max_iter=10000,
                         multi_class='ovr', verbose=0, warm_start=False, n_jobs=-1)

'''
    @param penalty: 指定正则化策略
    @param dual:  是否求解对偶形式
    @param C:  惩罚项系数的倒数，越大，正则化项越小
    @param fit_intercept:  是否拟合截距
    @param intercept_scaling:  当solver='liblinear'、fit_intercept=True时，会制造出一个恒为1的特征，权重为b，为了降低这个人造特征对正则化的影响，可以将其设为1
    @param class_weight:  可以是一个字典或'balanced'。字典：可以指定每一个分类的权重；'balanced'：可以指定每个分类的权重与该分类在训练集中的频率成反比
    @param max_iter:  最大迭代次数
    @param random_state:  一个整数或一个RandomState对象或None
    @param solver:  指定求解最优化问题的算法：
    'newton-cg':牛顿法；
    'lbfgs':拟牛顿法；
    'liblinear':使用liblinear;(适用于小数据集)
    'sag':使用Stochastic Average Gradient Descent算法(适用于大数据集)
    @param tol:  指定迭代收敛与否的阈值
    @param multi_class: 
    'ovr': 采用one-vs-rest策略
    'multi_class': 采用多类分类Logistic回归
    @param verbose: 是否开启迭代过程中输出日志
    @param warm_start:  是否使用前一次的训练结果继续训练
    @param n_jobs: 任务并行时指定使用的CPU数，-1表示使用所有可用的CPU

    @attribute coef_: 权重向量
    @attribute intercept_: 截距b
    @attribute n_iter_: 实际迭代次数

    @method fit(X,y[,sample_weight]): 训练模型
    @method predict(X): 预测
    @method predict_log_proba(X): 返回X预测为各类别的概率的对数
    @method predict_proba(X): 返回X预测为各类别的概率
    @method score(X,y[,sample_weight]): 计算在(X,y)上的预测的准确率
'''

clf.fit(trainX, trainY)

print("权值：" + str(clf.coef_))
print(("截距：" + str(clf.intercept_)))
print(("分数：" + str(clf.score(trainX, trainY))))
print(str(clf.predict(trainX)))
print(trainY)

clf.fit(testSet, testRealSet)

print("权值：" + str(clf.coef_))
print(("截距：" + str(clf.intercept_)))
print(("分数：" + str(clf.score(testSet, testRealSet))))
print(str(clf.predict(testSet)))
print('testRealSet{0}'.format(testRealSet))

prediceTS=clf.predict(testSet)

tp=0
for i,ele in enumerate(prediceTS):
    if ele==0 and ele==testRealSet[i]:
        tp+=1


fp=0
for i,ele in enumerate(prediceTS):
    if ele==0 and ele!=testRealSet[i]:
        fp+=1
tpfn=0
for ele in testRealSet:
    if ele==0:
        tpfn+=1

p=0
r=0
f1=0
try:
    p=tp/(tp+fp)
except ZeroDivisionError:
    print('tp+fp==0')
try:
    r=tp/tpfn
except ZeroDivisionError:
    print('tpfn==0')
try:
    f1=2*p*r/(p+r)
except ZeroDivisionError:
    print('p+r==0')

print('tp: {0}  fp: {1}  tp+fn: {2}'.format(tp,fp,tpfn))
print('p: {0}  r: {1}  f1: {2}'.format(p,r,f1))

tp1=0
for i,ele in enumerate(prediceTS):
    if ele==1 and ele==testRealSet[i]:
        tp1+=1


fp1=0
for i,ele in enumerate(prediceTS):
    if ele==1 and ele!=testRealSet[i]:
        fp1+=1
tpfn1=0
for ele in testRealSet:
    if ele==1:
        tpfn1+=1

p1=0
r1=0
f1_1=0
try:
    p1=tp1/(tp1+fp1)
except ZeroDivisionError:
    print('tp+fp==0')


try:
    r1=tp1/tpfn1
except ZeroDivisionError:
    print('tpfn1==0')
try:
    f1_1=2*p1*r1/(p1+r1)
except ZeroDivisionError:
    print('p+r==0')

print('tp1: {0}  fp1: {1}  tp+fn1: {2}'.format(tp1,fp1,tpfn1))
print('p1: {0}  r1: {1}  f1_1: {2}'.format(p1,r1,f1_1))
print("len(prediceTS): {0}".format(len(prediceTS)))

tp2=0
for i,ele in enumerate(prediceTS):
    if ele==2 and ele==testRealSet[i]:
        tp2+=1


fp2=0
for i,ele in enumerate(prediceTS):
    if ele==2 and ele!=testRealSet[i]:
        fp2+=1
tpfn2=0
for ele in testRealSet:
    if ele==2:
        tpfn2+=1

p2=0
r2=0
f1_2=0
try:
    p2=tp2/(tp2+fp2)
except ZeroDivisionError:
    print('tp+fp==0')


try:
    r2=tp2/tpfn2
except ZeroDivisionError:
    print('tpfn2==0')
try:
    f1_2=2*p2*r2/(p2+r2)
except ZeroDivisionError:
    print('p+r==0')

print('tp2: {0}  fp2: {1}  tp+fn2: {2}'.format(tp2,fp2,tpfn2))
print('p2: {0}  r2: {1}  f1_2: {2}'.format(p2,r2,f1_2))




#print('overall correct decision rate:{0}'.format((p+r+p1+r1+p2+r2)/6))
