import work_jcst.readReport
import work_jcst.write_xml
import work_jcst.func_prf
from openpyxl import Workbook
#s1 SURF得到的bug类型的review与没标签的report
url01_bug_review='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s1_bug_review.xml'

urlw01_b='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\seketfidf_b.xml'
urlw02_b='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\seketfidf_b.xml'
urlw03_b='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\seketfidf_b.xml'
urlw04_b='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\seketfidf_b.xml'
urlw05_b='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\seketfidf_b.xml'
urlw06_b='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\seketfidf_b.xml'
urlw07_b='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\seketfidf_b.xml'
urlw01_f='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\seketfidf_f.xml'
urlw02_f='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\seketfidf_f.xml'
urlw03_f='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\seketfidf_f.xml'
urlw04_f='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\seketfidf_f.xml'
urlw05_f='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\seketfidf_f.xml'
urlw06_f='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\seketfidf_f.xml'
urlw07_f='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\seketfidf_f.xml'



urlw08_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\seketfidf_b.xml'
urlw09_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\seketfidf_b.xml'
urlw10_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\seketfidf_b.xml'
urlw11_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\seketfidf_b.xml'
urlw12_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\seketfidf_b.xml'
urlw13_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\seketfidf_b.xml'
urlw14_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\seketfidf_b.xml'
urlw15_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\seketfidf_b.xml'
urlw16_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\seketfidf_b.xml'
urlw17_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\seketfidf_b.xml'

#s2_tfidf bug类型的report与没标签的
#url01_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\s2_bm25fext_bug.xml'
url01_bug_none_sim='E:\python_script\work_jcst\\bugReport\\tests\\s2_bm25fext_bug.xml'
url02_bug_review='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s1_bug_review.xml'


url02_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\s2_bug_none_similar.xml'

url03_bug_review='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s1_bug_review.xml'
url03_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\s2_bug_none_similar.xml'
url04_bug_review='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s1_bug_review.xml'
url04_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\s2_bug_none_similar.xml'
url05_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s1_bug_review.xml'
url05_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\s2_bug_none_similar.xml'
url06_bug_review='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s1_bug_review.xml'
url06_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\s2_bug_none_similar.xml'
url07_bug_review='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s1_bug_review.xml'
url07_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\s2_bug_none_similar.xml'

url08_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\\s1_bug_review.xml'
url08_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\\s2_bug_none_similar.xml'
url09_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\Automattic_simplenote-android\\s1_bug_review.xml'
#url09_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\Automattic_simplenote-android\\s2_bug_none_similar.xml'
url09_bug_none_sim='E:\python_script\work_jcst\\bugReport\\tests\\s2_bm25fext_bug2.xml'

url10_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\chrislacy_TweetLanes\\s1_bug_review.xml'
url10_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\chrislacy_TweetLanes\\s2_bug_none_similar.xml'
url11_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\k9mail_k-9\\s1_bug_review.xml'
url11_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\k9mail_k-9\\s2_bug_none_similar.xml'
url12_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\OneBusAway_onebusaway-android\\s1_bug_review.xml'
url12_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\OneBusAway_onebusaway-android\\s2_bug_none_similar.xml'
url13_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\owncloud_android\\s1_bug_review.xml'
url13_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\owncloud_android\\s2_bug_none_similar.xml'
url14_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\sunlightlabs_congress-android\\s1_bug_review.xml'
url14_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\sunlightlabs_congress-android\\s2_bug_none_similar.xml'
url15_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\\s1_bug_review.xml'
url15_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\\s2_bug_none_similar.xml'
url16_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\\s1_bug_review.xml'
url16_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\\s2_bug_none_similar.xml'
url17_bug_review='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\wordpress-mobile_WordPress-Android\\s1_bug_review.xml'
url17_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\wordpress-mobile_WordPress-Android\\s2_bug_none_similar.xml'


url008_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\\s2_mcg_bug.xml'
url009_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\Automattic_simplenote-android\\s2_mcg_bug.xml'
url010_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\chrislacy_TweetLanes\\s2_mcg_bug.xml'
url011_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\k9mail_k-9\\s2_mcg_bug.xml'
url012_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\OneBusAway_onebusaway-android\\s2_mcg_bug.xml'
url013_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\owncloud_android\\s2_mcg_bug.xml'
url014_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\sunlightlabs_congress-android\\s2_mcg_bug.xml'
url015_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\the-blue-alliance_the-blue-alliance-android\\s2_mcg_bug.xml'
url016_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\UweTrottmann_SeriesGuide\\s2_mcg_bug.xml'
url017_bug_none_sim='E:\python_script\work_jcst\\bugReport\\variate\\_purebug\wordpress-mobile_WordPress-Android\\s2_mcg_bug.xml'
#计算score
#url1是review,url2是report,url3记录结果
def calculate1(url1,url2,p):
    s1=work_jcst.readReport.readS(url1)
    s2=work_jcst.readReport.readS(url2)
    #print('s1{0}'.format(s1))
    #print('s2{0}'.format(s2))
    xmax1=s1[0]
    xmin1=s1[0]
    xmax2=s2[0]
    xmin2=s2[0]
    for s in s1:
        if s >= xmax1:
            xmax1 = s
        if s <= xmin1:
            xmin1 = s
    for s in s2:
        if s >= xmax2:
            xmax2 = s
        if s <= xmin2:
            xmin2 = s
    scores=[]
    for i in range(len(s1)):
        s1[i] = (s1[i] - xmin1) / (xmax1 - xmin1)
        s2[i]=(s2[i]-xmin2)/(xmax2-xmin2)
        scores.append(p*s1[i]+(1-p)*s2[i])
    return scores

list_numbigerthanthreshold_bug=[[0 for i in range(9)] for j in range(9)]
#list_numbigerthanthreshold_feature=[[0 for i in range(9)] for j in range(9)]
list_bt_bug=[[0 for i in range(9)] for j in range(9)]
#list_bt_feature=[[0 for i in range(9)] for j in range(9)]
########################################################################################
for i in range(1,10):
    scores1_bug=calculate1(urlw07_f,url07_bug_none_sim,1)
    for num02 in range(1,10):
        num03=num02/10
        sumbug=0
        m=0
        list01=[]
        for score in scores1_bug:
            if score > num03:
                sumbug+=1
                list01.append(m)
            m+=1
        list_numbigerthanthreshold_bug[i-1][num02-1]=sumbug
        list_bt_bug[i-1][num02-1]=list01
print('list_numbigerthanthreshold_bug{0}'.format(list_numbigerthanthreshold_bug))
#print(list_numbigerthanthreshold_feature)
print(list_bt_bug)
#print(list_bt_feature)
url01='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AnimeNeko_Atarashii.xml'
url02='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AntennaPod_AntennaPod.xml'
url03='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\cgeo_cgeo.xml'
url04='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\moezbhatti_qksms.xml'
url05='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\talklittle_reddit-is-fun.xml'
url06='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\TwidereProject_Twidere-Android.xml'
url071='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'
url072='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'
url073='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'

url08='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\ankidroid_Anki-Android.xml'
url09='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\Automattic_simplenote-android.xml'
url10='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\chrislacy_TweetLanes.xml'
url11='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\k9mail_k-9.xml'
url12='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\OneBusAway_onebusaway-android.xml'
url13='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\owncloud_android.xml'
url14='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\sunlightlabs_congress-android.xml'
url15='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\the-blue-alliance_the-blue-alliance-android.xml'
url16='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\UweTrottmann_SeriesGuide.xml'
url17='E:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\wordpress-mobile_WordPress-Android.xml'

#list01=work_jcst.readReport.read_kind_SURF(url06)
list01=work_jcst.readReport.read_3kind_SURF(url071,url072,url073)
l_b=list01[0]
l_f=list01[1]
print('l_b{0}'.format(l_b))
print('l_f{0}'.format(l_f))
#list_tp=work_jcst.func_prf.c_intersection(list01,list_bt_bug,list_bt_feature)
list_tp=work_jcst.func_prf.c_intersection1(list01,list_bt_bug)
list_tpb=list_tp[0]
list_tpf=list_tp[1]
print('list_tpb{0}'.format(list_tpb))
print('list_tpf{0}'.format(list_tpf))
#----------------------------------------------------------
#list_precision=work_jcst.func_prf.c_precision(list_tp,list_numbigerthanthreshold_bug,list_numbigerthanthreshold_feature)
list_precision=work_jcst.func_prf.c_precision(list_tp,list_numbigerthanthreshold_bug,list_numbigerthanthreshold_bug)

list_precision_b=list_precision[0]
list_precision_f=list_precision[1]
print(list_precision_b)
print(list_precision_f)

list_recall=work_jcst.func_prf.c_recall(list01,list_tp)
list_recall_b=list_recall[0]
list_recall_f=list_recall[1]
print('list_recall_b{0}'.format(list_recall_b))
print('list_recall_f{0}'.format(list_recall_f))

list_fmeasure=work_jcst.func_prf.c_fmeasure(list_precision,list_recall)
list_fmeasure_b=list_fmeasure[0]
list_fmeasure_f=list_fmeasure[1]
print(list_fmeasure_b)
print(len(list_fmeasure_b))
print(list_fmeasure_f)
print(len(list_fmeasure_f))

wb1=Workbook()
booksheet1=wb1.active
for i in range(9):
  booksheet1["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet1['%s%d'%(chr(ord('B')+i),j+1)].value=list_precision_b[i][j]
#AntennaPod_AntennaPod
#cgeo_cgeo
#moezbhatti_qksms
#talklittle_reddit-is-fun
#TwidereProject_Twidere-Android
#WhisperSystems_Signal-Android
#wb1.save("E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\scores4_bm25fext\\precision4_b01.xlsx")
url01_1='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\seke\\tfidf\\precision_b.xlsx'
url02_b='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\seke\\tfidf\\precision_b.xlsx'
url03_b='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\seke\\tfidf\\precision_b.xlsx'
url04_b='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\seke\\tfidf\\precision_b.xlsx'
url05_b='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\seke\\tfidf\\precision_b.xlsx'
url06_b='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\seke\\tfidf\\precision_b.xlsx'
url07_b='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\seke\\tfidf\\precision_b.xlsx'
url01_f='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\seke\\tfidf\\precision_f.xlsx'
url02_f='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\seke\\tfidf\\precision_f.xlsx'
url03_f='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\seke\\tfidf\\precision_f.xlsx'
url04_f='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\seke\\tfidf\\precision_f.xlsx'
url05_f='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\seke\\tfidf\\precision_f.xlsx'
url06_f='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\seke\\tfidf\\precision_f.xlsx'
url07_f='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\seke\\tfidf\\precision_f.xlsx'

url08_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\seke\\tfidf\\precision_b.xlsx'
url09_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\seke\\tfidf\\precision_b.xlsx'
url10_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\seke\\tfidf\\precision_b.xlsx'
url11_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\seke\\tfidf\\precision_b.xlsx'
url12_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\seke\\tfidf\\precision_b.xlsx'
url13_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\seke\\tfidf\\precision_b.xlsx'
url14_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\seke\\tfidf\\precision_b.xlsx'
url15_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\seke\\tfidf\\precision_b.xlsx'
url16_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\seke\\tfidf\\precision_b.xlsx'
url17_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\seke\\tfidf\\precision_b.xlsx'
wb1.save(url07_f)

#------------------------------------------------------------------------
wb2=Workbook()
booksheet2=wb2.active
for i in range(9):
  booksheet2["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet2['%s%d'%(chr(ord('B')+i),j+1)].value=list_recall_b[i][j]

#wb2.save("E:\python_script\work_jcst\\bugReport\\variate\\_purebug\\ankidroid_Anki-Android\scores4_bm25fext\\recall4_b01.xlsx")

url01_2='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\seke\\tfidf\\recall_b.xlsx'
url02_b='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\seke\\tfidf\\recall_b.xlsx'
url03_b='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\seke\\tfidf\\recall_b.xlsx'
url04_b='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\seke\\tfidf\\recall_b.xlsx'
url05_b='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\seke\\tfidf\\recall_b.xlsx'
url06_b='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\seke\\tfidf\\recall_b.xlsx'
url07_b='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\seke\\tfidf\\recall_b.xlsx'
url01_f='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\seke\\tfidf\\recall_f.xlsx'
url02_f='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\seke\\tfidf\\recall_f.xlsx'
url03_f='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\seke\\tfidf\\recall_f.xlsx'
url04_f='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\seke\\tfidf\\recall_f.xlsx'
url05_f='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\seke\\tfidf\\recall_f.xlsx'
url06_f='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\seke\\tfidf\\recall_f.xlsx'
url07_f='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\seke\\tfidf\\recall_f.xlsx'

url08_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\seke\\tfidf\\recall_b.xlsx'
url09_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\seke\\tfidf\\recall_b.xlsx'
url10_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\seke\\tfidf\\recall_b.xlsx'
url11_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\seke\\tfidf\\recall_b.xlsx'
url12_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\seke\\tfidf\\recall_b.xlsx'
url13_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\seke\\tfidf\\recall_b.xlsx'
url14_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\seke\\tfidf\\recall_b.xlsx'
url15_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\seke\\tfidf\\recall_b.xlsx'
url16_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\seke\\tfidf\\recall_b.xlsx'
url17_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\seke\\tfidf\\recall_b.xlsx'
wb2.save(url07_f)

#-----------------------------------------------------------------------------------------
wb3=Workbook()
booksheet3=wb3.active
for i in range(9):
  booksheet3["A%d" % (i+1)].value = (i + 1)/10
for i in range(9):
    for j in range(9):
        booksheet3['%s%d'%(chr(ord('B')+i),j+1)].value=list_fmeasure_b[i][j]

url01_3='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\seke\\tfidf\\fmeasure_b.xlsx'
url02_b='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\seke\\tfidf\\fmeasure_b.xlsx'
url03_b='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\seke\\tfidf\\fmeasure_b.xlsx'
url04_b='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\seke\\tfidf\\fmeasure_b.xlsx'
url05_b='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\seke\\tfidf\\fmeasure_b.xlsx'
url06_b='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\seke\\tfidf\\fmeasure_b.xlsx'
url07_b='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\seke\\tfidf\\fmeasure_b.xlsx'
url01_f='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\seke\\tfidf\\fmeasure_f.xlsx'
url02_f='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\seke\\tfidf\\fmeasure_f.xlsx'
url03_f='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\seke\\tfidf\\fmeasure_f.xlsx'
url04_f='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\seke\\tfidf\\fmeasure_f.xlsx'
url05_f='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\seke\\tfidf\\fmeasure_f.xlsx'
url06_f='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\seke\\tfidf\\fmeasure_f.xlsx'
url07_f='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\seke\\tfidf\\fmeasure_f.xlsx'

url08_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\seke\\tfidf\\fmeasure_b.xlsx'
url09_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\seke\\tfidf\\fmeasure_b.xlsx'
url10_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\seke\\tfidf\\fmeasure_b.xlsx'
url11_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\seke\\tfidf\\fmeasure_b.xlsx'
url12_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\seke\\tfidf\\fmeasure_b.xlsx'
url13_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\seke\\tfidf\\fmeasure_b.xlsx'
url14_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\seke\\tfidf\\fmeasure_b.xlsx'
url15_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\seke\\tfidf\\fmeasure_b.xlsx'
url16_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\seke\\tfidf\\fmeasure_b.xlsx'
url17_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\seke\\tfidf\\fmeasure_b.xlsx'

wb3.save(url07_f)
