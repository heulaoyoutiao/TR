
import nltk
from collections import defaultdict
from nltk.stem.porter import PorterStemmer
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
from gensim import corpora,models,similarities
from xml.dom import minidom
import work_jcst.write_xml
#读取textualIndexReport_none
import work_jcst.readReport

def c_fr(url2,url0,num01,str01):
    reviews=work_jcst.readReport.read_bug_SURF(url2,num01,str01)
    i = 0
    wordEngStop = nltk.corpus.stopwords.words('english')
    english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '!', '@', '#', '%', '$', '*', '=', 'abstract=',
                            '{', '}', '\'', '\"', '\\']
    pattern = r"""(?x)                   # set flag to allow verbose regexps
                  (?:[A-Z]\.)+           # abbreviations, e.g. U.S.A.
                  |\d+(?:\.\d+)?%?       # numbers, incl. currency and percentages
                  |\w+(?:[-']\w+)*       # words w/ optional internal hyphens/apostrophe
                  |\.\.\.                # ellipsis
                  |(?:[.,;"'?():-_`])    # special characters with meanings
                """
    porter_stemmer = PorterStemmer()
    texts = [[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document.lower(), pattern)
              if word not in wordEngStop + english_punctuations and word.isdigit() == False and '.' not in word and len(
            word) > 1] for document in reviews]
    frequency = defaultdict(int)
    for text in texts:
        for token in text:
            frequency[token] += 1
    texts = [[token for token in text if frequency[token] > 1]
             for text in texts]
    work_jcst.write_xml.write_xml3(texts,url0)


url03='E:\python_script\work_jcst\\reviews\\review_seke\\cgeo_cgeo.xml'
url03_b='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_bug_reviews.xml'
url03_f='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_feature_reviews.xml'
url01='E:\python_script\work_jcst\\reviews\\AnimeNeko_Atarashii.xml'
url01_b='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\Filted_bug_reviews.xml'
url01_f='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\Filted_feature_reviews.xml'
url02='E:\python_script\work_jcst\\reviews\\review_seke\\AntennaPod_AntennaPod.xml'
url02_b='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\Filted_bug_reviews.xml'
url02_f='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\Filted_feature_reviews.xml'
url04='E:\python_script\work_jcst\\reviews\\moezbhatti_qksms.xml'
url04_b='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\Filted_bug_reviews.xml'
url04_f='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\Filted_feature_reviews.xml'
url05='E:\python_script\work_jcst\\reviews\\talklittle_reddit-is-fun.xml'
url05_b='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\Filted_bug_reviews.xml'
url05_f='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\Filted_feature_reviews.xml'
url06='E:\python_script\work_jcst\\reviews\\review_seke\\TwidereProject_Twidere-Android.xml'
url06_b='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\Filted_bug_reviews.xml'
url06_f='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\Filted_feature_reviews.xml'
url07='E:\python_script\work_jcst\\reviews\\review_seke\\WhisperSystems_Signal-Android.xml'
url07_b='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\Filted_bug_reviews.xml'
url07_f='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\Filted_feature_reviews.xml'
url08='E:\python_script\work_jcst\\reviews\\ankidroid_Anki-Android.xml'
url08_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\Filted_bug_reviews.xml'
url09='E:\python_script\work_jcst\\reviews\\review_seke\\Automattic_simplenote-android.xml'
url09_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\Automattic_simplenote-android\\Filted_bug_reviews.xml'
url10='E:\python_script\work_jcst\\reviews\\review_seke\\chrislacy_TweetLanes.xml'
url10_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\chrislacy_TweetLanes\\Filted_bug_reviews.xml'
url11='E:\python_script\work_jcst\\reviews\\review_seke\\k9mail_k-9.xml'
url11_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\k9mail_k-9\\Filted_bug_reviews.xml'
url12='E:\python_script\work_jcst\\reviews\\review_seke\\OneBusAway_onebusaway-android.xml'
url12_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\OneBusAway_onebusaway-android\\Filted_bug_reviews.xml'
url13='E:\python_script\work_jcst\\reviews\\owncloud_android.xml'
url13_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\owncloud_android\\Filted_bug_reviews.xml'
url14='E:\python_script\work_jcst\\reviews\\sunlightlabs_congress-android.xml'
url14_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\sunlightlabs_congress-android\\Filted_bug_reviews.xml'
url15='E:\python_script\work_jcst\\reviews\\the-blue-alliance_the-blue-alliance-android.xml'
url15_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\Filted_bug_reviews.xml'
url16='E:\python_script\work_jcst\\reviews\\review_seke\\UweTrottmann_SeriesGuide.xml'
url16_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\Filted_bug_reviews.xml'
url17='E:\python_script\work_jcst\\reviews\\review_seke\\wordpress-mobile_WordPress-Android.xml'
url17_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\wordpress-mobile_WordPress-Android\\Filted_bug_reviews.xml'

str01='BUG'
str02='REQUEST'

c_fr(url01,url01_b,404,str01)
c_fr(url01,url01_f,404,str02)

c_fr(url02,url02_b,2082,str01)
c_fr(url02,url02_f,2082,str02)

c_fr(url04,url04_b,2633,str01)
c_fr(url04,url04_f,2633,str02)

c_fr(url05,url05_b,4480,str01)
c_fr(url05,url05_f,4480,str02)

c_fr(url06,url06_b,2061,str01)
c_fr(url06,url06_f,2061,str02)

c_fr(url07,url07_b,4443,str01)
c_fr(url07,url07_f,4443,str02)

c_fr(url08,url08_b,3636,str01)
c_fr(url09,url09_b,1394,str01)
c_fr(url10,url10_b,1471,str01)
c_fr(url11,url11_b,4456,str01)
c_fr(url12,url12_b,2103,str01)
c_fr(url13,url13_b,938,str01)
c_fr(url14,url14_b,160,str01)
c_fr(url15,url15_b,60,str01)
c_fr(url16,url16_b,4459,str01)
c_fr(url17,url17_b,4433,str01)