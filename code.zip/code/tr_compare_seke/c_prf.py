import work_jcst.func_prf
from openpyxl import Workbook
import work_jcst.readReport
import work_jcst.write_xml

urlw01='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\seketfidf.xml'

list_st=work_jcst.readReport.readS(urlw01)
print(list_st)
print(len(list_st))
def b(list01):
    xmax1=list01[0]
    xmin1=list01[0]
    for s in list01:
        if s >= xmax1:
            xmax1 = s
        if s <= xmin1:
            xmin1 = s
    for i in range(len(list01)):
        list01[i] = (list01[i] - xmin1) / (xmax1 - xmin1)

    return list01

print(b(list_st))
print(len(b(list_st)))