
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
from gensim import corpora,models,similarities
from Work2.Similar1 import MergeKeys

import work_jcst.readReport
import work_jcst.write_xml



url01_b='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\Filted_bug_reviews.xml'
url01_f='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\Filted_feature_reviews.xml'
url01='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_none.xml'


url02='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\textualIndexReport_none.xml'
url02_b='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\Filted_bug_reviews.xml'
url02_f='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\Filted_feature_reviews.xml'

url03='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\textualIndexReport_none.xml'
url03_b='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_bug_reviews.xml'
url03_f='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\Filted_feature_reviews.xml'

url04='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\textualIndexReport_none.xml'
url04_b='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\Filted_bug_reviews.xml'
url04_f='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\Filted_feature_reviews.xml'
url05='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\textualIndexReport_none.xml'
url05_b='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\Filted_bug_reviews.xml'
url05_f='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\Filted_feature_reviews.xml'
url06='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\textualIndexReport_none.xml'
url06_b='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\Filted_bug_reviews.xml'
url06_f='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\Filted_feature_reviews.xml'
url07='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\textualIndexReport_none.xml'
url07_b='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\Filted_bug_reviews.xml'
url07_f='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\Filted_feature_reviews.xml'
url08='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\textualIndexReport_none.xml'
url08_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\Filted_bug_reviews.xml'
url09='E:\python_script\work_jcst\\bugReport\\variate\_purebug\Automattic_simplenote-android\\textualIndexReport_none.xml'
url09_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\Automattic_simplenote-android\\Filted_bug_reviews.xml'
url10='E:\python_script\work_jcst\\bugReport\\variate\_purebug\chrislacy_TweetLanes\\textualIndexReport_none.xml'
url10_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\chrislacy_TweetLanes\\Filted_bug_reviews.xml'
url11='E:\python_script\work_jcst\\bugReport\\variate\_purebug\k9mail_k-9\\textualIndexReport_none.xml'
url11_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\k9mail_k-9\\Filted_bug_reviews.xml'
url12='E:\python_script\work_jcst\\bugReport\\variate\_purebug\OneBusAway_onebusaway-android\\textualIndexReport_none.xml'
url12_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\OneBusAway_onebusaway-android\\Filted_bug_reviews.xml'
url13='E:\python_script\work_jcst\\bugReport\\variate\_purebug\owncloud_android\\textualIndexReport_none.xml'
url13_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\owncloud_android\\Filted_bug_reviews.xml'
url14='E:\python_script\work_jcst\\bugReport\\variate\_purebug\sunlightlabs_congress-android\\textualIndexReport_none.xml'
url14_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\sunlightlabs_congress-android\\Filted_bug_reviews.xml'
url15='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_none.xml'
url15_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\Filted_bug_reviews.xml'
url16='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_none.xml'
url16_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\Filted_bug_reviews.xml'
url17='E:\python_script\work_jcst\\bugReport\\variate\_purebug\wordpress-mobile_WordPress-Android\\textualIndexReport_none.xml'
url17_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\wordpress-mobile_WordPress-Android\\Filted_bug_reviews.xml'

reviews=work_jcst.readReport.readReport_none(url07_f)
reports=work_jcst.readReport.readReport_none(url07)

print(reviews)
print(reports)

dictionary = corpora.Dictionary(reviews)
corpus = [dictionary.doc2bow(text) for text in reviews]
tfidf = models.TfidfModel(corpus)
corpus_tfidf = tfidf[corpus]
index = similarities.MatrixSimilarity(corpus_tfidf)
query_bows = [dictionary.doc2bow(text) for text in reports]

for i in range(len(query_bows)):
    query_tfidf = tfidf[query_bows[i]]
    sims = index[query_tfidf]
    sort_sims = sorted(enumerate(sims), key=lambda item: -item[1])

texts1=''
for sentence in reviews:
    for word in sentence:
        texts1+=word+' '
#print(texts1)
all_reviews=texts1.split()
all_reviews_vec=dictionary.doc2bow(all_reviews)
all_reviews_tfidf=tfidf[all_reviews_vec]


results=[]
for i in range(len(query_bows)):
    query_tfidf = tfidf[query_bows[i]]
    result=MergeKeys(query_tfidf,all_reviews_tfidf)
    results.append(result)

    str4=''
    str4+="第{0}个bugReport的结果: ".format(i)
    str4+=str(result)+' '
    str4+='\n'

print(results)
print(len(results))

urlw01_b='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\seketfidf_b.xml'
urlw01_f='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\seketfidf_f.xml'

urlw02_b='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\seketfidf_b.xml'
urlw02_f='E:\python_script\work_jcst\\bugReport\\variate\AntennaPod_AntennaPod\\seketfidf_f.xml'


urlw03_b='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\seketfidf_b.xml'
urlw03_f='E:\python_script\work_jcst\\bugReport\\variate\cgeo_cgeo\\seketfidf_f.xml'


urlw04_b='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\seketfidf_b.xml'
urlw04_f='E:\python_script\work_jcst\\bugReport\\variate\moezbhatti_qksms\\seketfidf_f.xml'

urlw05_b='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\seketfidf_b.xml'
urlw05_f='E:\python_script\work_jcst\\bugReport\\variate\\talklittle_reddit-is-fun\\seketfidf_f.xml'

urlw06_b='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\seketfidf_b.xml'
urlw06_f='E:\python_script\work_jcst\\bugReport\\variate\TwidereProject_Twidere-Android\\seketfidf_f.xml'

urlw07_b='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\seketfidf_b.xml'
urlw07_f='E:\python_script\work_jcst\\bugReport\\variate\WhisperSystems_Signal-Android\\seketfidf_f.xml'

urlw08_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\ankidroid_Anki-Android\\seketfidf_b.xml'

urlw09_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\Automattic_simplenote-android\\seketfidf_b.xml'

urlw10_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\chrislacy_TweetLanes\\seketfidf_b.xml'

urlw11_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\k9mail_k-9\\seketfidf_b.xml'

urlw12_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\OneBusAway_onebusaway-android\\seketfidf_b.xml'

urlw13_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\owncloud_android\\seketfidf_b.xml'

urlw14_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\sunlightlabs_congress-android\\seketfidf_b.xml'

urlw15_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\the-blue-alliance_the-blue-alliance-android\\seketfidf_b.xml'

urlw16_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\UweTrottmann_SeriesGuide\\seketfidf_b.xml'

urlw17_b='E:\python_script\work_jcst\\bugReport\\variate\_purebug\\wordpress-mobile_WordPress-Android\\seketfidf_b.xml'

work_jcst.write_xml.write_xml2(results,urlw07_f)

