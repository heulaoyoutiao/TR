#compare to Bug or Enhancement
import nltk
from collections import defaultdict
from nltk.stem.porter import PorterStemmer
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

from work_jcst import readReport
import work_jcst.write_xml
import work_jcst.funcCompare


#---------------------------------------------------------------------------------------------------------------------
url01_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\\AnimeNeko_Atarashii.xml'
url01_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\\AnimeNeko_Atarashii.xml'
url01_feature='F:\python_script\work_jcst\\bugReport\\bugReport_feature\\AnimeNeko_Atarashii.xml'
url01_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\AnimeNeko_Atarashii.xml'

url02_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\\AntennaPod_AntennaPod.xml'
url02_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\\AntennaPod_AntennaPod.xml'
url02_feature='F:\python_script\work_jcst\\bugReport\\bugReport_feature\\AntennaPod_AntennaPod.xml'
url02_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\AntennaPod_AntennaPod.xml'

url03_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\\cgeo_cgeo.xml'
url03_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\\cgeo_cgeo.xml'
url03_feature='F:\python_script\work_jcst\\bugReport\\bugReport_feature\\cgeo_cgeo.xml'
url03_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\cgeo_cgeo.xml'

url04_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\\moezbhatti_qksms.xml'
url04_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\\moezbhatti_qksms.xml'
url04_feature='F:\python_script\work_jcst\\bugReport\\bugReport_feature\\moezbhatti_qksms.xml'
url04_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\moezbhatti_qksms.xml'

url05_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\\talklittle_reddit-is-fun.xml'
url05_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\\talklittle_reddit-is-fun.xml'
url05_feature='F:\python_script\work_jcst\\bugReport\\bugReport_feature\\talklittle_reddit-is-fun.xml'
url05_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\talklittle_reddit-is-fun.xml'

url06_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\\TwidereProject_Twidere-Android.xml'
url06_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\\TwidereProject_Twidere-Android.xml'
url06_feature='F:\python_script\work_jcst\\bugReport\\bugReport_feature\\TwidereProject_Twidere-Android.xml'
url06_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\TwidereProject_Twidere-Android.xml'

url07_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\\WhisperSystems_Signal-Android.xml'
url07_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\\WhisperSystems_Signal-Android.xml'
url07_feature='F:\python_script\work_jcst\\bugReport\\bugReport_feature\\WhisperSystems_Signal-Android.xml'
url07_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\WhisperSystems_Signal-Android.xml'

url08_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\ankidroid_Anki-Android.xml'
url08_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\ankidroid_Anki-Android.xml'
url08_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\ankidroid_Anki-Android.xml'

url09_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\Automattic_simplenote-android.xml'
url09_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\Automattic_simplenote-android.xml'
url09_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\Automattic_simplenote-android.xml'

url10_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\chrislacy_TweetLanes.xml'
url10_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\chrislacy_TweetLanes.xml'
url10_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\chrislacy_TweetLanes.xml'

url11_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\k9mail_k-9.xml'
url11_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\k9mail_k-9.xml'
url11_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\k9mail_k-9.xml'

url12_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\OneBusAway_onebusaway-android.xml'
url12_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\OneBusAway_onebusaway-android.xml'
url12_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\OneBusAway_onebusaway-android.xml'

url13_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\owncloud_android.xml'
url13_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\owncloud_android.xml'
url13_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\owncloud_android.xml'

url14_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\sunlightlabs_congress-android.xml'
url14_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\sunlightlabs_congress-android.xml'
url14_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\sunlightlabs_congress-android.xml'

url15_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\the-blue-alliance_the-blue-alliance-android.xml'
url15_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\the-blue-alliance_the-blue-alliance-android.xml'
url15_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\the-blue-alliance_the-blue-alliance-android.xml'

url16_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\UweTrottmann_SeriesGuide.xml'
url16_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\UweTrottmann_SeriesGuide.xml'
url16_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\UweTrottmann_SeriesGuide.xml'

url17_bug='F:\python_script\work_jcst\\bugReport\\bugReport_bug\_purebug\\wordpress-mobile_WordPress-Android.xml'
url17_none='F:\python_script\work_jcst\\bugReport\\bugReport_none\_purebug\\wordpress-mobile_WordPress-Android.xml'
url17_nonBF='F:\python_script\work_jcst\\bugReport\\bugReport_noneBF\\wordpress-mobile_WordPress-Android.xml'

bug_reports_none=readReport.readReport(url17_none)
bug_reports_bug=readReport.readReport(url17_bug)
#bug_reports_feature=readReport.readReport(url07_feature)
bug_reports_nonBF=readReport.readReport(url17_nonBF)

english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '!', '@', '#', '%', '$', '*','=','abstract=', '{', '}','\'','\"','\\']
pattern=r"""(?x)                   # set flag to allow verbose regexps
              (?:[A-Z]\.)+           # abbreviations, e.g. U.S.A.
              |\d+(?:\.\d+)?%?       # numbers, incl. currency and percentages
              |\w+(?:[-']\w+)*       # words w/ optional internal hyphens/apostrophe
              |\.\.\.                # ellipsis
              |(?:[.,;"'?():-_`])    # special characters with meanings
            """
porter_stemmer = PorterStemmer()

texts_bug_reports_none_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_none]
texts_bug_reports_none_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_none]

texts_bug_reports_bug_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_bug]
texts_bug_reports_bug_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_bug]
'''
texts_bug_reports_feature_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_feature]
texts_bug_reports_feature_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_feature]
'''
texts_bug_reports_nonBF_summary=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[1].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_nonBF]
texts_bug_reports_nonBF_description=[[porter_stemmer.stem(word) for word in nltk.regexp_tokenize(document[2].lower(), pattern)
                                 if word not in english_punctuations and word.isdigit()==False and '.'not in word and len(word)>1]for document in bug_reports_nonBF]
#---------------------------------------------------------------------------------------------------------------------
bug_reports_none_processed=[[0,0,0]for number01 in range(len(bug_reports_none))]
bug_reports_bug_processed=[[0,0,0]for number01 in range(len(bug_reports_bug))]
#bug_reports_feature_processed=[[0,0,0]for number01 in range(len(bug_reports_feature))]
bug_reports_nonBF_processed=[[0,0,0]for number01 in range(len(bug_reports_nonBF))]
num_brn=0
for document in bug_reports_none:
    bug_reports_none_processed[num_brn][0]=num_brn
    bug_reports_none_processed[num_brn][1]=texts_bug_reports_none_summary[num_brn]
    bug_reports_none_processed[num_brn][2] = texts_bug_reports_none_description[num_brn]
    num_brn+=1
print("bug_reports_none_processed:{0}".format(bug_reports_none_processed))
url01_bug_reports_none_processed='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\bug_reports_none_processed.xml'
url02_bug_reports_none_processed='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\bug_reports_none_processed.xml'
url03_bug_reports_none_processed='F:\python_script\work_jcst\compare\cgeo_cgeo\\bug_reports_none_processed.xml'
url04_bug_reports_none_processed='F:\python_script\work_jcst\compare\moezbhatti_qksms\\bug_reports_none_processed.xml'
url05_bug_reports_none_processed='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\bug_reports_none_processed.xml'
url06_bug_reports_none_processed='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\bug_reports_none_processed.xml'
url07_bug_reports_none_processed='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\bug_reports_none_processed.xml'

url08_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\bug_reports_none_processed.xml'
url09_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\bug_reports_none_processed.xml'
url10_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\bug_reports_none_processed.xml'
url11_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\k9mail_k-9\\bug_reports_none_processed.xml'
url12_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\bug_reports_none_processed.xml'
url13_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\owncloud_android\\bug_reports_none_processed.xml'
url14_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\sunlightlabs_congress-android\\bug_reports_none_processed.xml'
url15_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\bug_reports_none_processed.xml'
url16_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\bug_reports_none_processed.xml'
url17_bug_reports_none_processed='F:\python_script\work_jcst\compare\_purebug\wordpress-mobile_WordPress-Android\\bug_reports_none_processed.xml'



work_jcst.write_xml.write_xml4(bug_reports_none_processed,url17_bug_reports_none_processed)

num_brb=0
for document in bug_reports_bug:
    bug_reports_bug_processed[num_brb][0]=num_brb
    bug_reports_bug_processed[num_brb][1]=texts_bug_reports_bug_summary[num_brb]
    bug_reports_bug_processed[num_brb][2] = texts_bug_reports_bug_description[num_brb]
    num_brb+=1
print("bug_reports_bug_processed:{0}".format(bug_reports_bug_processed))
url01_bug_reports_bug_processed='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\bug_reports_bug_processed.xml'
url02_bug_reports_bug_processed='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\bug_reports_bug_processed.xml'
url03_bug_reports_bug_processed='F:\python_script\work_jcst\compare\cgeo_cgeo\\bug_reports_bug_processed.xml'
url04_bug_reports_bug_processed='F:\python_script\work_jcst\compare\moezbhatti_qksms\\bug_reports_bug_processed.xml'
url05_bug_reports_bug_processed='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\bug_reports_bug_processed.xml'
url06_bug_reports_bug_processed='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\bug_reports_bug_processed.xml'
url07_bug_reports_bug_processed='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\bug_reports_bug_processed.xml'

url08_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\bug_reports_bug_processed.xml'
url09_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\bug_reports_bug_processed.xml'
url10_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\bug_reports_bug_processed.xml'
url11_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\k9mail_k-9\\bug_reports_bug_processed.xml'
url12_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\bug_reports_bug_processed.xml'
url13_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\owncloud_android\\bug_reports_bug_processed.xml'
url14_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\sunlightlabs_congress-android\\bug_reports_bug_processed.xml'
url15_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\bug_reports_bug_processed.xml'
url16_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\bug_reports_bug_processed.xml'
url17_bug_reports_bug_processed='F:\python_script\work_jcst\compare\_purebug\wordpress-mobile_WordPress-Android\\bug_reports_bug_processed.xml'

work_jcst.write_xml.write_xml4(bug_reports_bug_processed,url17_bug_reports_bug_processed)
'''
num_brb=0
for document in bug_reports_feature:
    bug_reports_feature_processed[num_brb][0]=num_brb
    bug_reports_feature_processed[num_brb][1]=texts_bug_reports_feature_summary[num_brb]
    bug_reports_feature_processed[num_brb][2] = texts_bug_reports_feature_description[num_brb]
    num_brb+=1
print("bug_reports_feature_processed:{0}".format(bug_reports_feature_processed))
url01_bug_reports_feature_processed='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\bug_reports_feature_processed.xml'
url02_bug_reports_feature_processed='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\bug_reports_feature_processed.xml'
url03_bug_reports_feature_processed='F:\python_script\work_jcst\compare\cgeo_cgeo\\bug_reports_feature_processed.xml'
url04_bug_reports_feature_processed='F:\python_script\work_jcst\compare\moezbhatti_qksms\\bug_reports_feature_processed.xml'
url05_bug_reports_feature_processed='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\bug_reports_feature_processed.xml'
url06_bug_reports_feature_processed='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\bug_reports_feature_processed.xml'
url07_bug_reports_feature_processed='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\bug_reports_feature_processed.xml'


work_jcst.write_xml.write_xml4(bug_reports_feature_processed,url07_bug_reports_feature_processed)
'''
num_brn=0
for document in bug_reports_nonBF:
    bug_reports_nonBF_processed[num_brn][0]=num_brn
    bug_reports_nonBF_processed[num_brn][1]=texts_bug_reports_nonBF_summary[num_brn]
    bug_reports_nonBF_processed[num_brn][2] = texts_bug_reports_nonBF_description[num_brn]
    num_brn+=1
print("bug_reports_nonBF_processed:{0}".format(bug_reports_nonBF_processed))
url01_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\bug_reports_nonBF_processed.xml'
url02_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\bug_reports_nonBF_processed.xml'
url03_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\cgeo_cgeo\\bug_reports_nonBF_processed.xml'
url04_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\moezbhatti_qksms\\bug_reports_nonBF_processed.xml'
url05_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\bug_reports_nonBF_processed.xml'
url06_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\bug_reports_nonBF_processed.xml'
url07_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\bug_reports_nonBF_processed.xml'

url08_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\bug_reports_nonBF_processed.xml'
url09_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\bug_reports_nonBF_processed.xml'
url10_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\bug_reports_nonBF_processed.xml'
url11_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\k9mail_k-9\\bug_reports_nonBF_processed.xml'
url12_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\bug_reports_nonBF_processed.xml'
url13_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\owncloud_android\\bug_reports_nonBF_processed.xml'
url14_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\sunlightlabs_congress-android\\bug_reports_nonBF_processed.xml'
url15_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\bug_reports_nonBF_processed.xml'
url16_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\bug_reports_nonBF_processed.xml'
url17_bug_reports_nonBF_processed='F:\python_script\work_jcst\compare\_purebug\wordpress-mobile_WordPress-Android\\bug_reports_nonBF_processed.xml'

work_jcst.write_xml.write_xml4(bug_reports_nonBF_processed,url17_bug_reports_nonBF_processed)
#---------------------------------------------------------------------------------------------------------------------
frequency_none_description = defaultdict(int)
for text in bug_reports_none_processed:
    for token_description in text[2]:
        frequency_none_description[token_description]+=1

texts_none_description=[[token for token in text[2] if frequency_none_description[token] > 1]
         for text in bug_reports_none_processed]
print('texts_none_description:{0}'.format(texts_none_description))

frequency_bug_description = defaultdict(int)
for text in bug_reports_bug_processed:

    for token_description in text[2]:
        frequency_bug_description[token_description]+=1

texts_bug_description=[[token for token in text[2] if frequency_bug_description[token] > 1]
         for text in bug_reports_bug_processed]
print('texts_bug_description:{0}'.format(texts_bug_description))
'''
frequency_feature_description = defaultdict(int)
for text in bug_reports_feature_processed:

    for token_description in text[2]:
        frequency_feature_description[token_description]+=1

texts_feature_description=[[token for token in text[2] if frequency_feature_description[token] > 1]
         for text in bug_reports_feature_processed]
print('texts_feature_description:{0}'.format(texts_feature_description))
'''
frequency_nonBF_description = defaultdict(int)
for text in bug_reports_nonBF_processed:
    for token_description in text[2]:
        frequency_nonBF_description[token_description]+=1

texts_nonBF_description=[[token for token in text[2] if frequency_nonBF_description[token] > 1]
         for text in bug_reports_nonBF_processed]
print('texts_nonBF_description:{0}'.format(texts_nonBF_description))
#---------------------------------------------------------------------------------------------------------------------
textualIndexReport_none=[[0]for i in range(len(bug_reports_none_processed))]
numberIntegrate=0
for processedReport in bug_reports_none_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_none_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_none[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_none:{0}'.format(textualIndexReport_none))
print(len(textualIndexReport_none))
print(textualIndexReport_none[0][2])
url01_textualIndexReport_none='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
url02_textualIndexReport_none='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_none.xml'
url03_textualIndexReport_none='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_none.xml'
url04_textualIndexReport_none='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_none.xml'
url05_textualIndexReport_none='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_none.xml'
url06_textualIndexReport_none='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_none.xml'
url07_textualIndexReport_none='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_none.xml'

url08_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\textualIndexReport_none.xml'
url09_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\textualIndexReport_none.xml'
url10_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\textualIndexReport_none.xml'
url11_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\k9mail_k-9\\textualIndexReport_none.xml'
url12_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\textualIndexReport_none.xml'
url13_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\owncloud_android\\textualIndexReport_none.xml'
url14_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\sunlightlabs_congress-android\\textualIndexReport_none.xml'
url15_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_none.xml'
url16_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_none.xml'
url17_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\textualIndexReport_none.xml'
work_jcst.write_xml.write_xml3(textualIndexReport_none,url17_textualIndexReport_none)

textualIndexReport_bug=[[0]for i in range(len(bug_reports_bug_processed))]
numberIntegrate=0
for processedReport in bug_reports_bug_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_bug_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_bug[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_bug:{0}'.format(textualIndexReport_bug))
print(len(textualIndexReport_bug))
url01_textualIndexReport_bug='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_bug.xml'
url02_textualIndexReport_bug='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_bug.xml'
url03_textualIndexReport_bug='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_bug.xml'
url04_textualIndexReport_bug='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_bug.xml'
url05_textualIndexReport_bug='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_bug.xml'
url06_textualIndexReport_bug='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_bug.xml'
url07_textualIndexReport_bug='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_bug.xml'

url08_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\textualIndexReport_bug.xml'
url09_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\textualIndexReport_bug.xml'
url10_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\textualIndexReport_bug.xml'
url11_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\k9mail_k-9\\textualIndexReport_bug.xml'
url12_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\textualIndexReport_bug.xml'
url13_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\owncloud_android\\textualIndexReport_bug.xml'
url14_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\sunlightlabs_congress-android\\textualIndexReport_bug.xml'
url15_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_bug.xml'
url16_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_bug.xml'
url17_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\textualIndexReport_bug.xml'
work_jcst.write_xml.write_xml3(textualIndexReport_bug,url17_textualIndexReport_bug)
'''
textualIndexReport_feature=[[0]for i in range(len(bug_reports_feature_processed))]
numberIntegrate=0
for processedReport in bug_reports_feature_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_feature_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_feature[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_feature:{0}'.format(textualIndexReport_feature))
print(len(textualIndexReport_feature))
url01_textualIndexReport_feature='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_feature.xml'
url02_textualIndexReport_feature='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_feature.xml'
url03_textualIndexReport_feature='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_feature.xml'
url04_textualIndexReport_feature='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_feature.xml'
url05_textualIndexReport_feature='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_feature.xml'
url06_textualIndexReport_feature='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_feature.xml'
url07_textualIndexReport_feature='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_feature.xml'


work_jcst.write_xml.write_xml3(textualIndexReport_feature,url07_textualIndexReport_feature)
'''

textualIndexReport_nonBF=[[0]for i in range(len(bug_reports_nonBF_processed))]
numberIntegrate=0
for processedReport in bug_reports_nonBF_processed:
    textualReport = []
    for token_summary in processedReport[1]:
        textualReport.append(token_summary)
    for token_description in texts_nonBF_description[numberIntegrate]:
        textualReport.append(token_description)
    textualIndexReport_nonBF[numberIntegrate]=textualReport
    numberIntegrate+=1
print('textualIndexReport_nonBF:{0}'.format(textualIndexReport_nonBF))
print(len(textualIndexReport_nonBF))
print(textualIndexReport_nonBF[0][2])
url01_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_nonBF.xml'
url02_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_nonBF.xml'
url03_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_nonBF.xml'
url04_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_nonBF.xml'
url05_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_nonBF.xml'
url06_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_nonBF.xml'
url07_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_nonBF.xml'

url08_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\textualIndexReport_nonBF.xml'
url09_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\textualIndexReport_nonBF.xml'
url10_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\textualIndexReport_nonBF.xml'
url11_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\k9mail_k-9\\textualIndexReport_nonBF.xml'
url12_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\textualIndexReport_nonBF.xml'
url13_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\owncloud_android\\textualIndexReport_nonBF.xml'
url14_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\sunlightlabs_congress-android\\textualIndexReport_nonBF.xml'
url15_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_nonBF.xml'
url16_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_nonBF.xml'
url17_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\textualIndexReport_nonBF.xml'
work_jcst.write_xml.write_xml3(textualIndexReport_nonBF,url17_textualIndexReport_nonBF)
#---------------------------------------------------------------------------------------------------------------------








