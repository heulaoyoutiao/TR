#我需要找出确定bug, feature, nonBF 的特征（word），先算下词频吧。
from work_jcst import readReport
from collections import defaultdict
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import work_jcst.funcCompare
url01_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_nonBF.xml'
url01_textualIndexReport_none='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
url01_textualIndexReport_bug='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_bug.xml'
url01_textualIndexReport_feature='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_feature.xml'

url02_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_nonBF.xml'
url02_textualIndexReport_none='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_none.xml'
url02_textualIndexReport_bug='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_bug.xml'
url02_textualIndexReport_feature='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_feature.xml'

url04_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_nonBF.xml'
url04_textualIndexReport_none='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_none.xml'
url04_textualIndexReport_bug='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_bug.xml'
url04_textualIndexReport_feature='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_feature.xml'

textualIndexReport_nonBF=work_jcst.readReport.readReport_none(url02_textualIndexReport_nonBF)
textualIndexReport_none=work_jcst.readReport.readReport_none(url02_textualIndexReport_none)
textualIndexReport_bug=work_jcst.readReport.readReport_none(url02_textualIndexReport_bug)
textualIndexReport_feature=work_jcst.readReport.readReport_none(url02_textualIndexReport_feature)


#textualIndexReport_nonBF2=work_jcst.readReport.readReport_none01(url_textualIndexReport_nonBF)

#print(textualIndexReport_nonBF1)
#print(len(textualIndexReport_nonBF1))
#print('##############')
#print(textualIndexReport_nonBF2)
#print(len(textualIndexReport_nonBF2))

x=textualIndexReport_nonBF
y=textualIndexReport_none
z=textualIndexReport_bug
k=textualIndexReport_feature





frequency=defaultdict(int)
for text in x:
    for token in text:
        frequency[token]+=1

df1=sorted(frequency.items(),key=lambda x:x[1],reverse=True)


frequency=defaultdict(int)
for text in y:
    for token in text:
        frequency[token]+=1

df2=sorted(frequency.items(),key=lambda x:x[1],reverse=True)


frequency=defaultdict(int)
for text in z:
    for token in text:
        frequency[token]+=1

df3=sorted(frequency.items(),key=lambda x:x[1],reverse=True)


frequency=defaultdict(int)
for text in k:
    for token in text:
        frequency[token]+=1

df4=sorted(frequency.items(),key=lambda x:x[1],reverse=True)
print(type(df4))
print(len(df4))
print(df4)
print(frequency.items())
dict1={}
for text in k:
    for token in text:
        if dict1.__contains__(token)==False:
            dict1[token]=0
        dict1[token]+=1
df=sorted(dict1.items(),key=lambda x:x[1],reverse=True)
print(type(df))
print(len(df))
print(df)
print(dict1.items())

txturl01_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\wordFrequency\\nonBF.txt'
txturl01_textualIndexReport_none='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\wordFrequency\\none.txt'
txturl01_textualIndexReport_bug='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\wordFrequency\\bug.txt'
txturl01_textualIndexReport_feature='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\wordFrequency\\feature.txt'

txturl02_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\nonBF.txt'
txturl02_textualIndexReport_none='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\none.txt'
txturl02_textualIndexReport_bug='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\bug.txt'
txturl02_textualIndexReport_feature='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\feature.txt'

txturl04_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\cgeo_cgeo\wordFrequency\\nonBF.txt'
txturl04_textualIndexReport_none='F:\python_script\work_jcst\compare\cgeo_cgeo\wordFrequency\\none.txt'
txturl04_textualIndexReport_bug='F:\python_script\work_jcst\compare\cgeo_cgeo\wordFrequency\\bug.txt'
txturl04_textualIndexReport_feature='F:\python_script\work_jcst\compare\cgeo_cgeo\wordFrequency\\feature.txt'

f4=open(txturl01_textualIndexReport_nonBF,'w',encoding='utf-8')
f4.write(str(df1))
f4.close()

f4=open(txturl01_textualIndexReport_none,'w',encoding='utf-8')
f4.write(str(df2))
f4.close()

f4=open(txturl01_textualIndexReport_bug,'w',encoding='utf-8')
f4.write(str(df3))
f4.close()

f4=open(txturl02_textualIndexReport_feature,'w',encoding='utf-8')
f4.write(str(df4))
f4.close()