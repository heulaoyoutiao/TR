from work_jcst import readReport

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
import numpy as np
import work_jcst.funcCompare

url01_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_nonBF.xml'
url01_textualIndexReport_none='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
url01_textualIndexReport_bug='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_bug.xml'
url01_textualIndexReport_feature='F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\textualIndexReport_feature.xml'

url02_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_nonBF.xml'
url02_textualIndexReport_none='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_none.xml'
url02_textualIndexReport_bug='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_bug.xml'
url02_textualIndexReport_feature='F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\textualIndexReport_feature.xml'

url03_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_nonBF.xml'
url03_textualIndexReport_none='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_none.xml'
url03_textualIndexReport_bug='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_bug.xml'
url03_textualIndexReport_feature='F:\python_script\work_jcst\compare\cgeo_cgeo\\textualIndexReport_feature.xml'

url04_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_nonBF.xml'
url04_textualIndexReport_none='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_none.xml'
url04_textualIndexReport_bug='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_bug.xml'
url04_textualIndexReport_feature='F:\python_script\work_jcst\compare\moezbhatti_qksms\\textualIndexReport_feature.xml'

url05_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_nonBF.xml'
url05_textualIndexReport_none='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_none.xml'
url05_textualIndexReport_bug='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_bug.xml'
url05_textualIndexReport_feature='F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\textualIndexReport_feature.xml'

url06_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_nonBF.xml'
url06_textualIndexReport_none='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_none.xml'
url06_textualIndexReport_bug='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_bug.xml'
url06_textualIndexReport_feature='F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\textualIndexReport_feature.xml'

url07_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_nonBF.xml'
url07_textualIndexReport_none='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_none.xml'
url07_textualIndexReport_bug='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_bug.xml'
url07_textualIndexReport_feature='F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\textualIndexReport_feature.xml'

url08_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\textualIndexReport_nonBF.xml'
url08_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\textualIndexReport_none.xml'
url08_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\textualIndexReport_bug.xml'

url09_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\textualIndexReport_nonBF.xml'
url09_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\textualIndexReport_none.xml'
url09_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\Automattic_simplenote-android\\textualIndexReport_bug.xml'

url10_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\textualIndexReport_nonBF.xml'
url10_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\textualIndexReport_none.xml'
url10_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\chrislacy_TweetLanes\\textualIndexReport_bug.xml'

url11_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\\_purebug\\k9mail_k-9\\textualIndexReport_nonBF.xml'
url11_textualIndexReport_none='F:\python_script\work_jcst\compare\\_purebug\\k9mail_k-9\\textualIndexReport_none.xml'
url11_textualIndexReport_bug='F:\python_script\work_jcst\compare\\_purebug\\k9mail_k-9\\textualIndexReport_bug.xml'

url12_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\textualIndexReport_nonBF.xml'
url12_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\textualIndexReport_none.xml'
url12_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\textualIndexReport_bug.xml'

url13_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\\_purebug\\owncloud_android\\textualIndexReport_nonBF.xml'
url13_textualIndexReport_none='F:\python_script\work_jcst\compare\\_purebug\\owncloud_android\\textualIndexReport_none.xml'
url13_textualIndexReport_bug='F:\python_script\work_jcst\compare\\_purebug\\owncloud_android\\textualIndexReport_bug.xml'

url14_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\\_purebug\\sunlightlabs_congress-android\\textualIndexReport_nonBF.xml'
url14_textualIndexReport_none='F:\python_script\work_jcst\compare\\_purebug\\sunlightlabs_congress-android\\textualIndexReport_none.xml'
url14_textualIndexReport_bug='F:\python_script\work_jcst\compare\\_purebug\\sunlightlabs_congress-android\\textualIndexReport_bug.xml'

url15_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_nonBF.xml'
url15_textualIndexReport_none='F:\python_script\work_jcst\compare\\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_none.xml'
url15_textualIndexReport_bug='F:\python_script\work_jcst\compare\\_purebug\\the-blue-alliance_the-blue-alliance-android\\textualIndexReport_bug.xml'

url16_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_nonBF.xml'
url16_textualIndexReport_none='F:\python_script\work_jcst\compare\\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_none.xml'
url16_textualIndexReport_bug='F:\python_script\work_jcst\compare\\_purebug\\UweTrottmann_SeriesGuide\\textualIndexReport_bug.xml'

url17_textualIndexReport_nonBF='F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\textualIndexReport_nonBF.xml'
url17_textualIndexReport_none='F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\textualIndexReport_none.xml'
url17_textualIndexReport_bug='F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\textualIndexReport_bug.xml'

textualIndexReport_nonBF=work_jcst.readReport.readReport_none(url07_textualIndexReport_nonBF)
textualIndexReport_none=work_jcst.readReport.readReport_none(url07_textualIndexReport_none)
textualIndexReport_bug=work_jcst.readReport.readReport_none(url07_textualIndexReport_bug)
textualIndexReport_feature=work_jcst.readReport.readReport_none(url07_textualIndexReport_feature)

str1="crash  error  but  npe  not  except  fail  doe  when  correct  provid  termin  other  invalid  record  work  "
str2=" tell intend excess"
str3=str1+str2

trainnonBF=work_jcst.funcCompare.cv1(str3,textualIndexReport_nonBF)
trainnone=work_jcst.funcCompare.cv1(str3,textualIndexReport_none)
trainbug=work_jcst.funcCompare.cv1(str3,textualIndexReport_bug)
trainfeature=work_jcst.funcCompare.cv1(str3,textualIndexReport_feature)

urltestSet01="F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\testSet.npy"
urltrainSet01="F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\trainSet.npy"
urllabelSet01="F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\labelSet.npy"
urltestRealSet01="F:\python_script\work_jcst\compare\AnimeNeko_Atarashii\\testRealSet.npy"

urltestSet02="F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\testSet.npy"
urltrainSet02="F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\trainSet.npy"
urllabelSet02="F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\labelSet.npy"
urltestRealSet02="F:\python_script\work_jcst\compare\AntennaPod_AntennaPod\\testRealSet.npy"

urltestSet03="F:\python_script\work_jcst\compare\cgeo_cgeo\\testSet.npy"
urltrainSet03="F:\python_script\work_jcst\compare\cgeo_cgeo\\trainSet.npy"
urllabelSet03="F:\python_script\work_jcst\compare\cgeo_cgeo\\labelSet.npy"
urltestRealSet03="F:\python_script\work_jcst\compare\cgeo_cgeo\\testRealSet.npy"

urltestSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\testSet.npy"
urltrainSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\trainSet.npy"
urllabelSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\labelSet.npy"
urltestRealSet04="F:\python_script\work_jcst\compare\moezbhatti_qksms\\testRealSet.npy"

urltestSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\testSet.npy"
urltrainSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\trainSet.npy"
urllabelSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\labelSet.npy"
urltestRealSet05="F:\python_script\work_jcst\compare\\talklittle_reddit-is-fun\\testRealSet.npy"

urltestSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\testSet.npy"
urltrainSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\trainSet.npy"
urllabelSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\labelSet.npy"
urltestRealSet06="F:\python_script\work_jcst\compare\TwidereProject_Twidere-Android\\testRealSet.npy"

urltestSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\testSet.npy"
urltrainSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\trainSet.npy"
urllabelSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\labelSet.npy"
urltestRealSet07="F:\python_script\work_jcst\compare\WhisperSystems_Signal-Android\\testRealSet.npy"

urltestSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\testSet.npy"
urltrainSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\trainSet.npy"
urllabelSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\labelSet.npy"
urltestRealSet08="F:\python_script\work_jcst\compare\_purebug\\ankidroid_Anki-Android\\testRealSet.npy"

urltestSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\testSet.npy"
urltrainSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\trainSet.npy"
urllabelSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\labelSet.npy"
urltestRealSet09="F:\python_script\work_jcst\compare\_purebug\\Automattic_simplenote-android\\testRealSet.npy"

urltestSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\testSet.npy"
urltrainSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\trainSet.npy"
urllabelSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\labelSet.npy"
urltestRealSet10="F:\python_script\work_jcst\compare\_purebug\\chrislacy_TweetLanes\\testRealSet.npy"

urltestSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\testSet.npy"
urltrainSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\trainSet.npy"
urllabelSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\labelSet.npy"
urltestRealSet11="F:\python_script\work_jcst\compare\_purebug\\k9mail_k-9\\testRealSet.npy"

urltestSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\testSet.npy"
urltrainSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\trainSet.npy"
urllabelSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\labelSet.npy"
urltestRealSet12="F:\python_script\work_jcst\compare\_purebug\\OneBusAway_onebusaway-android\\testRealSet.npy"

urltestSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\testSet.npy"
urltrainSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\trainSet.npy"
urllabelSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\labelSet.npy"
urltestRealSet13="F:\python_script\work_jcst\compare\_purebug\\owncloud_android\\testRealSet.npy"

urltestSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\testSet.npy"
urltrainSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\trainSet.npy"
urllabelSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\labelSet.npy"
urltestRealSet14="F:\python_script\work_jcst\compare\_purebug\\sunlightlabs_congress-android\\testRealSet.npy"

urltestSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\testSet.npy"
urltrainSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\trainSet.npy"
urllabelSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\labelSet.npy"
urltestRealSet15="F:\python_script\work_jcst\compare\_purebug\\the-blue-alliance_the-blue-alliance-android\\testRealSet.npy"

urltestSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\testSet.npy"
urltrainSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\trainSet.npy"
urllabelSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\labelSet.npy"
urltestRealSet16="F:\python_script\work_jcst\compare\_purebug\\UweTrottmann_SeriesGuide\\testRealSet.npy"

urltestSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\testSet.npy"
urltrainSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\trainSet.npy"
urllabelSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\labelSet.npy"
urltestRealSet17="F:\python_script\work_jcst\compare\_purebug\\wordpress-mobile_WordPress-Android\\testRealSet.npy"

testSet=np.array(trainnone)
print(testSet)

np.save(urltestSet07, testSet)
#****************
trainSet=[]
trainSet.extend(trainnonBF)
trainSet.extend(trainbug)
trainSet.extend(trainfeature)
print(trainSet)
print(len(trainSet))

trainSet=np.array(trainSet)
print('trainSet{0}'.format(trainSet))
np.save(urltrainSet07, trainSet)
#****************
labelSet=[]
listNonBF=[0 for i in range(len(textualIndexReport_nonBF))]
listBug=[2 for j in range(len(textualIndexReport_bug))]
listFeature=[1 for i in range(len(textualIndexReport_feature))]

labelSet.extend(listNonBF)
labelSet.extend(listBug)
labelSet.extend(listFeature)
print('labelset{0}'.format(labelSet))
print(len(labelSet))

labelSet=np.array(labelSet)
print(labelSet)
np.save(urllabelSet07, labelSet)
#****************

url01_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AnimeNeko_Atarashii.xml'
url02_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\AntennaPod_AntennaPod.xml'
url03_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\cgeo_cgeo.xml'
url04_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\moezbhatti_qksms.xml'
url05_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\talklittle_reddit-is-fun.xml'
url06_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\TwidereProject_Twidere-Android.xml'
url07_SurfVec1='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android1.xml'
url07_SurfVec2='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android2.xml'
url07_SurfVec3='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\\WhisperSystems_Signal-Android3.xml'
url08_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\ankidroid_Anki-Android.xml'
url09_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\Automattic_simplenote-android.xml'
url10_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\chrislacy_TweetLanes.xml'
url11_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\k9mail_k-9.xml'
url12_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\OneBusAway_onebusaway-android.xml'
url13_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\owncloud_android.xml'
url14_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\sunlightlabs_congress-android.xml'
url15_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\the-blue-alliance_the-blue-alliance-android.xml'
url16_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\UweTrottmann_SeriesGuide.xml'
url17_SurfVec='F:\python_script\work_jcst\\bugReport\\bugReport_none\surf\_purebug\\wordpress-mobile_WordPress-Android.xml'

surfVec=work_jcst.readReport.readSurfVecb3(url07_SurfVec1,url07_SurfVec2,url07_SurfVec3)
#surfVec=work_jcst.readReport.readSurfVecb(url06_SurfVec)
#****************
testRealSet=np.array(surfVec)
np.save(urltestRealSet07, testRealSet)
#****************