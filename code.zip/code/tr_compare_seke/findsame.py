str1="should complet better method bad button would add anim with  list crash  error  but  npe  not  except  fail  doe  when  correct  provid  termin  other  invalid  record  work "
a = ['futuretask', 'activitythread', 'asynctask', 'method', 'crash', 'error', 'threadpoolexecutor', 'but', 'would', 'add', 'with', 'list', 'should', 'os', 'support', 'chang', 'api', 'issu', 'io', 'applic', 'complet', 'handl', 'build', 'action', 'progress', 'cover', 'updat']
a=str1.split()
print(len(a))
b = set(a)
for each_b in b:
    count = 0
    for each_a in a:
        if each_b == each_a:
            count += 1
    print(each_b, ": ", count)
