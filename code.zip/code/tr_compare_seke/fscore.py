def f(p,r):
    return 2*p*r/(p+r)


p=29.73
r=80.77
print(f(p,r))
