
import math
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')
import work_jcst.readReport
import work_jcst.bm25f_ex_01
from work_jcst.bm25f_ex_01 import idf
from work_jcst.bm25f_ex_01 import tf_d
from work_jcst.bm25f_ex_01 import tf_q
url01_textualIndexReport_none='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_none.xml'
textualIndexReport_none=work_jcst.readReport.readReport_none(url01_textualIndexReport_none)
url01_textualIndexReport_feature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_feature.xml'
textualIndexReport_feature=work_jcst.readReport.readReport_none(url01_textualIndexReport_feature)

url01_textualIndexReport_irrfeature='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\textualIndexReport_irrfeature.xml'
textualIndexReport_irrfeature=work_jcst.readReport.readReport_none(url01_textualIndexReport_irrfeature)

url01_bug_reports_none_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_none_processed.xml'
bug_reports_none_processed=work_jcst.readReport.read_rfp(url01_bug_reports_none_processed)
url01_bug_reports_feature_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_feature_processed.xml'
bug_reports_feature_processed=work_jcst.readReport.read_rfp(url01_bug_reports_feature_processed)
url01_bug_reports_irrfeature_processed='E:\python_script\work_jcst\\bugReport\\variate\AnimeNeko_Atarashii\\bug_reports_irrfeature_processed.xml'
bug_reports_irrfeature_processed=work_jcst.readReport.read_rfp(url01_bug_reports_irrfeature_processed)

##constructing a traing set from a repository
def constructingTS(bug_reports_none_processed,bug_reports_feature_processed):
    list01=[]
    for num01 in range(len(bug_reports_none_processed)):
        for num02 in range(len(bug_reports_feature_processed)):
            for num03 in range(30):
                list01.append([num01,num02,num03])
    return list01

def y(textualIndexReport_none, textualIndexReport_irrfeature, bug_reports_irrfeature_processed, bug_reports_none_processed,bug_reports_feature_processed,textualIndexReport_feature):
    list01=constructingTS(bug_reports_none_processed,bug_reports_feature_processed)
    list02=work_jcst.bm25f_ex_01.bm25fext(textualIndexReport_none, textualIndexReport_feature, bug_reports_feature_processed, bug_reports_none_processed)
    list03=work_jcst.bm25f_ex_01.bm25fext(textualIndexReport_none, textualIndexReport_irrfeature, bug_reports_irrfeature_processed, bug_reports_none_processed)

#RNC=log(1+e^Y) where Y=sim(irr,q)-sim(rel,q)

'''
def f(x):
    return x**3 + 2 * x - 3

def error(x):
    return (f(x) - 0)**2

def gradient_descent(x):
    delta=0.00000001
    rate=0.001
    derivative = (error(x + delta) - error(x)) / delta
    return x - rate * derivative

x = 0.8
for i in range(300):
    x = gradient_descent(x)
    print('x = {0:6f}, f(x) = {1:6f}'.format(x, f(x)))

'''
def f(idf,tfd,tfq,k1,k3,b1,b2,w1,w2):
    idf*(tfd/(k1+tfd))*((k3+1)*tfq/(k3+tfq))
