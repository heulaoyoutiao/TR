import xml.dom.minidom
def write_xml(doc1,url):

    #在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    #创建一个根节点Managers对象
    root = doc.createElement('Managers')
    #设置根节点的属性
    root.setAttribute('author', 'heulaoyoutiao')
    root.setAttribute('address', 'heu')
    #将根节点添加到文档对象中
    doc.appendChild(root)
    j=0
    for i in doc1 :
        nodeManager = doc.createElement('Manager')
        nodeManager.setAttribute('Number',str(j))
        nodeKey = doc.createElement('Key')
        #给叶子节点name设置一个文本节点，用于显示文本内容
        nodeKey.appendChild(doc.createTextNode(str(i[0])))

        nodeValue = doc.createElement("Value")
        nodeValue.appendChild(doc.createTextNode(str(i[1])))

        #将各叶子节点添加到父节点Manager中，
        #最后将Manager添加到根节点Managers中
        nodeManager.appendChild(nodeKey)
        nodeManager.appendChild(nodeValue)

        root.appendChild(nodeManager)
        j+=1
    #开始写xml文档
    fp = open(url, 'w')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
def write_xml1(doc1,url):

    #在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    #创建一个根节点Managers对象
    root = doc.createElement('Managers')
    #设置根节点的属性
    root.setAttribute('company', 'microsoft')
    root.setAttribute('address', 'heu')
    #将根节点添加到文档对象中
    doc.appendChild(root)
    for i in doc1 :
      nodeManager = doc.createElement('Manager')
      nodeKey = doc.createElement('Key')
      #给叶子节点name设置一个文本节点，用于显示文本内容
      nodeKey.appendChild(doc.createTextNode(str(i[0])))

      nodeValue = doc.createElement("Value")
      nodeValue.appendChild(doc.createTextNode(str(i[1])))

      #将各叶子节点添加到父节点Manager中，
      #最后将Manager添加到根节点Managers中
      nodeManager.appendChild(nodeKey)
      nodeManager.appendChild(nodeValue)

      root.appendChild(nodeManager)
    #开始写xml文档
    fp = open(url, 'w')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
#e.g. similarity between feature and none
def write_xml2(list1,url):

    #在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    #创建一个根节点Managers对象
    root = doc.createElement('Managers')
    #设置根节点的属性
    root.setAttribute('organization', 'Harbin Engineering University')
    root.setAttribute('author', 'heulaoyoutiao')
    #将根节点添加到文档对象中
    doc.appendChild(root)
    for i in range(len(list1)) :
      nodeManager = doc.createElement('Manager')
      nodeKey = doc.createElement('Key')
      #给叶子节点name设置一个文本节点，用于显示文本内容
      nodeKey.appendChild(doc.createTextNode(str(i)))

      nodeValue = doc.createElement("Value")
      nodeValue.appendChild(doc.createTextNode(str(list1[i])))

      #将各叶子节点添加到父节点Manager中，
      #最后将Manager添加到根节点Managers中
      nodeManager.appendChild(nodeKey)
      nodeManager.appendChild(nodeValue)

      root.appendChild(nodeManager)
    #开始写xml文档
    fp = open(url, 'w')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
#persistent report words
def write_xml3(doc1,url):
    #在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    #创建一个根节点Managers对象
    root = doc.createElement('Managers')
    #设置根节点的属性
    root.setAttribute('author', 'heulaoyoutiao')
    root.setAttribute('address', 'heu')
    #将根节点添加到文档对象中
    doc.appendChild(root)
    j=0
    for i in doc1 :
        nodeManager = doc.createElement('Manager')
        nodeManager.setAttribute('Number',str(j))

        #给叶子节点name设置一个文本节点，用于显示文本内容
        num02=0
        #nodelabels01=[0 for num03 in range(len(i[0]))]
        for instant01 in i:
            nodelabel=doc.createElement('report')
            nodelabel.setAttribute('number',str(num02))

            nodelabel.appendChild(doc.createTextNode(str(instant01)))


            nodeManager.appendChild(nodelabel)

            num02+=1
        #nodeKey.appendChild(doc.createTextNode(str(i[0])))


        #将各叶子节点添加到父节点Manager中，
        #最后将Manager添加到根节点Managers中

        root.appendChild(nodeManager)
        j+=1
    #开始写xml文档
    fp = open(url, 'w',encoding='utf-8')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
'''
def write_xml4(doc1,url):
    # 在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    # 创建一个根节点Managers对象
    root = doc.createElement('Managers')
    # 设置根节点的属性
    root.setAttribute('author', 'heulaoyoutiao')
    root.setAttribute('address', 'heu')
    # 将根节点添加到文档对象中
    doc.appendChild(root)
    j = 0
    for i in range(len(doc1)):
        nodeManager = doc.createElement('report')
        nodeManager.setAttribute('Number', str(j))

        # 给叶子节点name设置一个文本节点，用于显示文本内容
        num02 = 0
        # nodelabels01=[0 for num03 in range(len(i[0]))]
        for instant01 in len(doc1[i]):
            num03=0
            nodesummary=doc.createElement('summary')
            for token in instant01[1]:
                nodetoken=doc.createElement('token')
                nodetoken.setAttribute('number', str(num03))
                nodetoken.appendChild(doc.createTextNode(token))
                nodesummary.appendChild(nodetoken)
                num03+=1
            nodedescription=doc.createElement('description')
            num04=0
            for token in instant01[2]:
                nodetoken=doc.createElement('token')
                nodetoken.setAttribute('number',str(num04))
                nodetoken.appendChild(doc.createTextNode(token))
                nodedescription.appendChild(nodetoken)
                num04+=1
            nodeManager.appendChild(nodesummary)
            nodeManager.appendChild(nodedescription)
            num02 += 1
        # nodeKey.appendChild(doc.createTextNode(str(i[0])))

        # 将各叶子节点添加到父节点Manager中，
        # 最后将Manager添加到根节点Managers中

        root.appendChild(nodeManager)
        j += 1
    # 开始写xml文档
    fp = open(url, 'w', encoding='utf-8')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
'''
def write_xml4(doc1,url):
    # 在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    # 创建一个根节点Managers对象
    root = doc.createElement('Managers')
    # 设置根节点的属性
    root.setAttribute('author', 'heulaoyoutiao')
    root.setAttribute('address', 'heu')
    # 将根节点添加到文档对象中
    doc.appendChild(root)
    j = 0
    for i in range(len(doc1)):
        nodeManager = doc.createElement('report')
        nodeManager.setAttribute('Number', str(j))

        # 给叶子节点name设置一个文本节点，用于显示文本内容

        # nodelabels01=[0 for num03 in range(len(i[0]))]


        nodesummary=doc.createElement('summary')
        num03=0
        for token in doc1[i][1]:
            nodetoken=doc.createElement('token')
            nodetoken.setAttribute('number', str(num03))
            nodetoken.appendChild(doc.createTextNode(token))
            nodesummary.appendChild(nodetoken)
            num03+=1
        nodedescription=doc.createElement('description')
        num04=0
        for token in doc1[i][2]:
            nodetoken=doc.createElement('token')
            nodetoken.setAttribute('number',str(num04))
            nodetoken.appendChild(doc.createTextNode(token))
            nodedescription.appendChild(nodetoken)
            num04+=1
        nodeManager.appendChild(nodesummary)
        nodeManager.appendChild(nodedescription)

        # nodeKey.appendChild(doc.createTextNode(str(i[0])))

        # 将各叶子节点添加到父节点Manager中，
        # 最后将Manager添加到根节点Managers中

        root.appendChild(nodeManager)
        j += 1
    # 开始写xml文档
    fp = open(url, 'w', encoding='utf-8')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")

def write_xmls1(doc1,url):
    # 在内存中创建一个空的文档
    doc = xml.dom.minidom.Document()
    # 创建一个根节点Managers对象
    root = doc.createElement('Managers')
    # 设置根节点的属性
    root.setAttribute('author', 'heulaoyoutiao')
    root.setAttribute('address', 'heu')
    # 将根节点添加到文档对象中
    doc.appendChild(root)
    j = 0
    for manager in doc1:
        nodeManager = doc.createElement('Manager')
        nodeManager.setAttribute('Number', str(j+1007))
        for i in range(len(manager)):
            nodesummary=doc.createElement('Key')
            nodesummary.appendChild(doc.createTextNode(manager[i][0]))
            nodedescription=doc.createElement('Value')
            nodedescription.appendChild(doc.createTextNode(manager[i][1]))
            nodeManager.appendChild(nodesummary)
            nodeManager.appendChild(nodedescription)
        j += 1
    # 开始写xml文档
    fp = open(url, 'w', encoding='utf-8')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")